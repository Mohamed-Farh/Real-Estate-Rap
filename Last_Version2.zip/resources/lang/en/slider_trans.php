<?php

return [

    'title_page' => 'Slider',
    'List_slider' => 'List Slider',
    'add_slider' => 'Add Slider',
    'edit_slider'=> 'edit_slider',
    'delete_slider'=> 'Delete Slider',
    'Warning_slider'=> 'Are Sure Of The Deleting Process ?',
    'visible_slider'=> 'Are Sure You Want This Photo Appear In The Homepage Slider ?',
    'unvisible_slider'=> 'Are Sure You Want This Photo Disappear From The Homepage Slider ?',
    'stage_name_ar' => 'stage_name_ar',
    'stage_name_en' => 'stage_name_en',
    'Notes' => 'Notes',
    'submit' => 'Submit',
    'Name'=>'Name',
    'Processes'=>'Processes',
    'delete_slider_Error'=>'The Slider cannot be deleted because there are classes attached to it',
    'Edit'=>'Edit',

    'exists'=>'This field already exists',
    'Delete'=>'Delete',
    'Close' => 'Close',

    'name_ar'=>'Name In Arabic',
    'name_en'=>'Name In English',

];
