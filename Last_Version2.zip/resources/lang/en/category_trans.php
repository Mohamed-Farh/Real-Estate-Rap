<?php

return [

    'title_page' => 'Categories',
    'List_category' => 'List Category',
    'add_category' => 'Add Category',
    'edit_category'=> 'Edit Category',
    'delete_category'=> 'delete_category',
    'Warning_category'=> 'Are Sure Of The Deleting Process ?',
    'stage_name_ar' => 'stage_name_ar',
    'stage_name_en' => 'stage_name_en',
    'Notes' => 'Notes',
    'submit' => 'Submit',
    'Name'=>'Name',
    'Processes'=>'Processes',
    'delete_category_Error'=>'The Category Cannot Be Deleted Because There Are Properties Attached To It',
    'Edit'=>'Edit',

    'exists'=>'This field already exists',
    'Delete'=>'Delete',
    'Close' => 'Close',

    'name_ar'=>'Name In Arabic',
    'name_en'=>'Name In English',

];
