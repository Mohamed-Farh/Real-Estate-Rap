<?php

return [

    'title_page' => 'social',
    'List_social' => 'List social',
    'add_social' => 'Add social',
    'edit_social'=> 'Edit Social',
    'delete_social'=> 'Delete Social',
    'Warning_social'=> 'Are Sure Of The Deleting Process ?',
    'visible_social'=> 'Are Sure You Want This  Appear In The Homepage social ?',
    'unvisible_social'=> 'Are Sure You Want This Disappear From The Homepage social ?',
    'stage_name_ar' => 'stage_name_ar',
    'stage_name_en' => 'stage_name_en',
    'Notes' => 'Notes',
    'submit' => 'Submit',
    'Name'=>'Name',
    'Type'=>'Type',
    'Status'=>'Visible',
    'Processes'=>'Processes',
    'delete_social_Error'=>'The social cannot be deleted because there are classes attached to it',
    'Edit'=>'Edit',

    'exists'=>'This field already exists',
    'Delete'=>'Delete',
    'Close' => 'Close',

    'name_ar'=>'Name In Arabic',
    'name_en'=>'Name In English',

    '0'=>'--Please Select--',
    'Customers Service'=>'Customers Service',
    'Inquiries'=>'Inquiries',
    'Facebook'=>'Facebook',
    'Recruitment'=>'Recruitment',
    'Accounts'=>'Accounts',

];
