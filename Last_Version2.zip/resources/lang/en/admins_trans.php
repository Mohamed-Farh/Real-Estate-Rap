<?php

return [

    'title_page' => 'Admins',
    'List_user' => 'Admin List',
    'add_user' => 'Add Admin',
    'edit_user'=> 'Edit Admin',
    'delete_user'=> 'Delete Admin',
    'Warning_user'=> 'Are Sure Of The Deleting Process Of This Admin ?',
    'stage_name_ar' => 'stage_name_ar',
    'stage_name_en' => 'stage_name_en',
    'Notes' => 'Notes',
    'submit' => 'Submit',
    'Name'=>'Name',
    'Processes'=>'Processes',
    'delete_user_Error'=>'The Admin cannot be deleted because there are classes attached to it',
    'Edit'=>'Edit',

    'exists'=>'This Admin Already Exists',
    'Delete'=>'Delete',
    'Close' => 'Close',

    'Name'=>'Name',
    'name'=>'Name In English *',
    'name_ar'=>'Name In Arabic',
    'email'=>'E-Mail',
    'password'=>'Password',
    'confirm_password'=>'Confirm Password',
    'created_at'=>'Create Date',


];
