<?php

return [

    'title_page' => 'Features',
    'List_feature' => 'List Feature',
    'add_feature' => 'Add Feature',
    'edit_feature'=> 'edit_feature',
    'delete_feature'=> 'delete_feature',
    'Warning_feature'=> 'Are Sure Of The Deleting Process ?',
    'stage_name_ar' => 'stage_name_ar',
    'stage_name_en' => 'stage_name_en',
    'Notes' => 'Notes',
    'submit' => 'Submit',
    'Name'=>'Name',
    'Processes'=>'Processes',
    'delete_feature_Error'=>'This Feature Cannot Be Deleted Because There Are Properties Attached To It',
    'Edit'=>'Edit',

    'exists'=>'This field already exists',
    'Delete'=>'Delete',
    'Close' => 'Close',

    'name_ar'=>'Name In Arabic',
    'name_en'=>'Name In English',

    'feature_id'=>'Features',

];
