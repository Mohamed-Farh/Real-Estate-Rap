<?php

return [

    'title_page' => 'Gallery',
    'List_gallery' => 'List Gallery',
    'add_gallery' => 'Add Gallery',
    'edit_gallery'=> 'edit_gallery',
    'delete_gallery'=> 'delete_gallery',
    'Warning_gallery'=> 'Are Sure Of The Deleting Process ?',
    'visible_gallery'=> 'Are Sure You Want This Photo Appear In The Gallery Blog Page ?',
    'unvisible_gallery'=> 'Are Sure You Want This Photo Disappear In The Gallery Blog Page ?',
    'stage_name_ar' => 'stage_name_ar',
    'stage_name_en' => 'stage_name_en',
    'Notes' => 'Notes',
    'submit' => 'Submit',
    'Name'=>'Name',
    'Processes'=>'Processes',
    'delete_gallery_Error'=>'The Gallery cannot be deleted because there are classes attached to it',
    'Edit'=>'Edit',

    'exists'=>'This field already exists',
    'Delete'=>'Delete',
    'Close' => 'Close',

    'name_ar'=>'Name In Arabic',
    'name_en'=>'Name In English',

];
