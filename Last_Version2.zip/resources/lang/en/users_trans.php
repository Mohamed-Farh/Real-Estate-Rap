<?php

return [

    'title_page' => 'Users',
    'List_user' => 'User List',
    'add_user' => 'Add User',
    'edit_user'=> 'Edit User',
    'delete_user'=> 'Delete User',
    'Warning_user'=> 'Are Sure Of The Deleting Process Of This User?',
    'stage_name_ar' => 'stage_name_ar',
    'stage_name_en' => 'stage_name_en',
    'Notes' => 'Notes',
    'submit' => 'Submit',

    'Processes'=>'Processes',
    'delete_user_Error'=>'The User cannot be deleted because there are classes attached to it',
    'Edit'=>'Edit',
    'exists'=>'This User Already Exists',
    'Delete'=>'Delete',
    'Close' => 'Close',

    'Name'=>'Name',
    'name'=>'Name In English *',
    'name_ar'=>'Name In Arabic',
    'email'=>'E-Mail',
    'password'=>'Password',
    'confirm_password'=>'Confirm Password',
    'created_at'=>'Create Date',

];
