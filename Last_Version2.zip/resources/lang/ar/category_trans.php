<?php

return [

    'title_page' => 'نوع العقار',
    'List_category' => 'أنواع العقارات',
    'add_category' => 'اضافة نوع عقار',
    'edit_category'=> 'تعديل نوع عقار',
    'delete_category'=> 'حذف نوع عقار',
    'Warning_category'=> 'هل انت متاكد من عملية الحذف ؟',
    'stage_name_ar' => 'اسم نوع العقار بالعربية',
    'stage_name_en' => 'اسم نوع العقار بالانجليزية',
    'Notes' => 'ملاحظات',
    'submit' => 'حفظ البيانات',
    'Name'=>'الأســم',
    'Processes'=>'العمليات',
    'delete_category_Error'=>'لايمكن حذف نوع العقار بسبب وجود عقارات تابعة لها',
    'Edit'=>'تعديل',
    'exists'=>'نوع العقار موجودة مسبقا',
    'Delete'=>'حذف',
    'Close' => 'اغلاق',

    'name_ar' => ' نوع العقار بالعربية',
    'name_en' => ' نوع العقار بالانجليزية',

];
