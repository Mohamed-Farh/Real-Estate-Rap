<?php

return [

    'title_page' => 'المستخدمين',
    'List_user' => 'قائمة المستخدمين',
    'add_user' => 'اضافة مستخدم',
    'edit_user'=> 'تعديل مستخدم',
    'delete_user'=> 'حذف مستخدم',
    'Warning_user'=> 'هل انت متأكد من عملبة حذف هذا المستخدم ؟',
    'stage_name_ar' => 'stage_name_ar',
    'stage_name_en' => 'stage_name_en',
    'Notes' => 'ملاحظات',
    'submit' => 'حفظ البيانات',

    'Processes'=>'العمليات',
    'delete_user_Error'=>'لايمكن حذف هذا المستخدم بسبب وجود صفوف تابعة له',
    'Edit'=>'تعديل',
    'exists'=>'هذا المستخدم موجود بالفعل',
    'Delete'=>'حذف',
    'Close' => 'اغلاق',

    'Name'=>'الأسـم',
    'name'=>'اسم المستخدم بالإنجليزية *',
    'name_ar'=>'اسم المستخدم بالعربية',
    'email'=>'البريد الإلكتروني',
    'password'=>'كلمة المرور',
    'confirm_password'=>'تأكيد كلمة المرور',
    'created_at'=>'تاريخ إضافته',




];
