<?php

return [

    'title_page' => 'الأدمـن',
    'List_user' => 'قائمة الأدمـن',
    'add_user' => 'اضافة أدمـن',
    'edit_user'=> 'تعديل أدمـن',
    'delete_user'=> 'حذف أدمـن',
    'Warning_user'=> 'هل انت متأكد من عملبة حذف هذا الأدمـن ؟',
    'stage_name_ar' => 'stage_name_ar',
    'stage_name_en' => 'stage_name_en',
    'Notes' => 'ملاحظات',
    'submit' => 'حفظ البيانات',
    'Name'=>'Name',
    'Processes'=>'العمليات',
    'delete_user_Error'=>'لايمكن حذف هذا الأدمن بسبب وجود صفوف تابعة له',
    'Edit'=>'تعديل',

    'exists'=>'هذا الأدمـن موجود بالفعل',
    'Delete'=>'حذف',
    'Close' => 'اغلاق',

    'Name'=>'الاســم',
    'name'=>'الاسـم بالانجليزية *',
    'name_ar'=>'الاسـم بالعربية',
    'email'=>'البريد الالكتروني',
    'password'=>'كلمة المرور',
    'confirm_password'=>'تأكيد كلمة المرور',
    'created_at'=>'تاريخ اضافته',

];
