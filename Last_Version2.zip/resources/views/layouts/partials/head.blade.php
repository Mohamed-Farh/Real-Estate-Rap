<meta charset="utf-8" />
<meta name="viewport" content="width=device-width,initial-scale=1,shrink-to-fit=no" />

<title>
    raptors
</title>
<link rel="stylesheet" href='{{asset('app-assets/fontawesome/css/all.min.css')}}'>
<link rel="stylesheet" href="{{asset('app-assets/css/bootstrap.css')}}">
<link href="https://cdn.rawgit.com/michalsnik/aos/2.1.1/dist/aos.css" rel="stylesheet">
{{-- <link href="{{asset('app-assets/css/stylesheet.css')}}" rel="stylesheet"> --}}
<link rel="stylesheet" href="{{asset('app-assets/css/swiper-bundle.min.css')}}" />

<!--- Style css -->
@if(App::getLocale() == 'en')
<link href="{{asset('app-assets/css/style.css')}}" rel="stylesheet">
@else
<link href="{{asset('app-assets/css/stylesheet.css')}}" rel="stylesheet">
@endif


