         <!--start footer-->
         <div class="footer">
             <div class="footer-bg-color-2 footer-bottom-light-border">
                 <div class="container">
                     <div class="row justify-content-center text-center">
                         <div class="col py-4">
                             <a class="logo" href="/home"><img src="<?php echo e(asset('app-assets/images/logo.png')); ?>" style="height: 70px;"></a>

                         </div>

                     </div>

                 </div>

             </div>
             <div class="footer-bg-color-2 footer-bottom-light-border">
                 <div class="container">
                     <div class="row justify-content-center text-center py-_x pt-5 pb-5">
                         <div class="col-md-4 text-center mb-4 mb-md-0">
                             <a>
                                 <i class="fas fa-map-marker-alt text-9 text-color-light mb-3 mt-2"></i>
                                 <p class="mb-0">
                                     <strong><?php echo e(trans('front_trans.address')); ?></strong>
                                     <span class="d-block text-2 p-relative bottom-3 Font_01 text-3 mt-2  Font_Clean">
                                        <?php echo e(trans('front_trans.Cairo- Alrehab City')); ?>

                                     </span>
                                 </p>

                             </a>

                         </div>
                         <div class="col-md-4 text-center mb-4 mb-md-0">
                             <a>
                                 <i class="fas fa-clock text-9 text-color-light mb-3 mt-2"></i>
                                 <p class="mb-0">
                                     <strong><?php echo e(trans('front_trans.times_of_work')); ?></strong>
                                     <span class="d-block text-2 p-relative bottom-3 Font_01 text-3 mt-2  Font_Clean">
                                         <?php echo e(trans('front_trans.Daily from 10 am - 6 pm')); ?>

                                     </span>

                                 </p>
                             </a>

                         </div>
                         <div class="col-md-4 text-center mb-4 mb-md-0">
                             <a>
                                 <i class="fas fa-phone-volume text-9 text-color-light mb-3 mt-2"></i>
                                 <p class="mb-0">
                                     <strong><?php echo e(trans('front_trans.contactus')); ?></strong>>
                                    <?php $customers = \App\Models\Social::where('type', 'Customers Service')->get(); ?>
                                        <?php $__currentLoopData = $customers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $customer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php if($customer->status == '1'): ?>
                                                <span class="d-block text-2 p-relative bottom-3 Font_01 text-3 mt-2  Font_Clean">
                                                    <?php echo e($customer->name); ?>

                                                </span>
                                            <?php endif; ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                 </p>
                             </a>

                         </div>

                     </div>

                 </div>

             </div>
             <div class="footer-copyright">
                 <div class="container pt-3 pb-1 py-2">
                     <div class="row">

                        <?php
                            $Twitters    = \App\Models\Social::where('type', 'Twitter')->get();
                            $Facebooks   = \App\Models\Social::where('type', 'Facebook')->get();
                            $Instagrams  = \App\Models\Social::where('type', 'Instagram')->get();
                            $G_Mails     = \App\Models\Social::where('type', 'G_Mail')->get();

                            $Yahoos      = \App\Models\Social::where('type', 'Yahoo')->get();
                            $Telegrams   = \App\Models\Social::where('type', 'Telegram')->get();
                            $Linkeds     = \App\Models\Social::where('type', 'Linked')->get();


                        ?>

                         <div class="col text-center">
                            <?php $__currentLoopData = $Facebooks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $Facebook): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <a href="<?php echo e($Facebook->name); ?>"><i class="fab fa-facebook"></i></a>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php $__currentLoopData = $Instagrams; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $Instagram): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <a href="<?php echo e($Instagram->name); ?>"><i class="fab fa-instagram"></i></a>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php $__currentLoopData = $Twitters; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $Twitter): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <a href="<?php echo e($Twitter->name); ?>"><i class="fab fa-twitter"></i></a>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                            <?php $__currentLoopData = $G_Mails; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $G_Mail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <a href="<?php echo e($G_Mail->name); ?>"><i class="fab fa-gmail"></i></a>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php $__currentLoopData = $Linkeds; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $Linked): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <a href="<?php echo e($Linked->name); ?>"><i class="fab fa-linkedin"></i></a>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php $__currentLoopData = $Yahoos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $Yahoo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <a href="<?php echo e($Yahoo->name); ?>"><i class="fab fa-yahoo"></i></a>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php $__currentLoopData = $Telegrams; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $Telegram): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <a href="<?php echo e($Telegram->name); ?>"><i class="fab fa-telegram"></i></a>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>






                             <p><?php echo e(trans('front_trans.All rights reserved © 2004 - 2021 Raptose Real Estate Investments')); ?></p>
                         </div>



                     </div>

                 </div>

             </div>

         </div>

         </div>
         <!--end footer-->
<?php /**PATH C:\Users\4FARH\OneDrive\Desktop\World\resources\views/layouts/partials/footer.blade.php ENDPATH**/ ?>