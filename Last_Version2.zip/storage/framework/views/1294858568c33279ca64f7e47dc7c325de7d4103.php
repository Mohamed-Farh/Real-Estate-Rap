<!-- Footer opened -->

<!-- Footer closed -->
<?php /**PATH /home/dbsc4c7x1fsq/last_v/resources/views/layouts/footer.blade.php ENDPATH**/ ?>