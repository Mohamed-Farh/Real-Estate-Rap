<?php $__env->startSection('css'); ?>
    <?php echo toastr_css(); ?>


<?php $__env->startSection('title'); ?>
    <?php echo e(trans('front_trans.company_jobs')); ?>

<?php $__env->stopSection(); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('page-header'); ?>
<!-- breadcrumb -->
<?php $__env->startSection('PageTitle'); ?>
    <?php echo e(trans('front_trans.company_jobs')); ?>

<?php $__env->stopSection(); ?>
<!-- breadcrumb -->
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<!-- row -->
<div class="row">

<div class="col-xl-12 mb-30">
    <div class="card card-statistics h-100">
        <div class="card-body">

            <?php if($errors->any()): ?>
                <div class="alert alert-danger">
                    <ul>
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><?php echo e($error); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
            <?php endif; ?>

            <button type="button" class="button x-small" data-toggle="modal" data-target="#exampleModal">
                <?php echo e(trans('front_trans.add')); ?>

            </button>
            <br><br>

            <div class="table-responsive">
                <table id="datatable" class="table  table-hover table-sm table-bordered p-0" data-page-length="50"
                    style="text-align: center">
                    <thead>
                        <tr>
                            <th>#</th>
                            <th><?php echo e(trans('feature_trans.name_ar')); ?></th>
                            <th><?php echo e(trans('feature_trans.name_en')); ?></th>
                            <th><?php echo e(trans('main_trans.type')); ?></th>
                            <th><?php echo e(trans('main_trans.visible')); ?></th>
                            <th><?php echo e(trans('social_trans.Processes')); ?></th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $i = 0; ?>
                        <?php $__currentLoopData = $company_jobs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $company_job): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <?php $i++; ?>
                                <td><?php echo e($i); ?></td>
                                <td><?php echo e($company_job->title_ar); ?></td>
                                <td><?php echo e($company_job->title_en); ?></td>
                                <td><?php echo e($company_job->type); ?></td>
                                <td>
                                    <?php if($company_job->status == '1'): ?>
                                        <button type="button" class="btn btn-primary" data-toggle="modal"
                                        data-target="#vis<?php echo e($company_job->id); ?>"
                                        title="<?php echo e(trans('social_trans.Delete')); ?>"><i class="fa fa-eye-slash"></i> Un Visible </button>
                                    <?php elseif($company_job->status == '0'): ?>
                                        <button type="button" class="btn btn-primary" data-toggle="modal"
                                        data-target="#vis<?php echo e($company_job->id); ?>"
                                        title="<?php echo e(trans('social_trans.Delete')); ?>"><i class="fa fa-eye"></i> Visible </button>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <button type="button" class="btn btn-info btn-sm" data-toggle="modal"
                                        data-target="#edit<?php echo e($company_job->id); ?>"
                                        title="<?php echo e(trans('social_trans.Edit')); ?>"><i
                                            class="fa fa-edit"></i></button>

                                    <button type="button" class="btn btn-danger btn-sm" data-toggle="modal"
                                        data-target="#delete<?php echo e($company_job->id); ?>"
                                        title="<?php echo e(trans('social_trans.Delete')); ?>"><i
                                            class="fa fa-trash"></i></button>
                                </td>
                            </tr>

                            <!-- edit_modal_social -->
                            <div class="modal fade" id="edit<?php echo e($company_job->id); ?>" tabindex="-1" role="dialog"
                                aria-labelledby="exampleModalLabel" aria-hidden="true">
                                <div class="modal-dialog" role="document">
                                    <div class="modal-content">
                                        <div class="modal-header">
                                            <h5 style="font-family: 'Cairo', sans-serif;" class="modal-title"
                                                id="exampleModalLabel">
                                                <?php echo e(trans('front_trans.edit')); ?>

                                            </h5>
                                            <button type="button" class="close" data-dismiss="modal"
                                                aria-label="Close">
                                                <span aria-hidden="true">&times;</span>
                                            </button>
                                        </div>
                                        <div class="modal-body">
                                            <!-- add_form -->
                                            <form action="<?php echo e(route('company_jobs.update', 'test')); ?>" method="post">
                                                <?php echo e(method_field('patch')); ?>

                                                <?php echo csrf_field(); ?>
                                                <input id="id" type="hidden" name="id" class="form-control"
                                                    value="<?php echo e($company_job->id); ?>">
                                                    <div class="form-group  small_space">
                                                        <div class="col">
                                                            <label for="title_ar" class="mr-sm-2"><?php echo e(trans('feature_trans.name_ar')); ?> :</label>
                                                            <input type="text" class="form-control" name="title_ar" value="<?php echo e($company_job->title_ar); ?>">
                                                        </div>
                                                    </div>
                                                    <div class="form-group  small_space">
                                                        <div class="col">
                                                            <label for="title_en" class="mr-sm-2"><?php echo e(trans('feature_trans.name_en')); ?> :</label>
                                                            <input type="text" class="form-control" name="title_en" value="<?php echo e($company_job->title_en); ?>">
                                                        </div>
                                                    </div>
                                                <div class="form-group">
                                                    <div class="col">
                                                        <label class="mr-sm-2" for="type"><?php echo e(trans('main_trans.type')); ?></label>
                                                        <select name="type" required class="form-control">
                                                            <option value="0"               <?php if($company_job->type == "0")            echo "selected"; ?> >  --Please Select--   </option>
                                                            <option value="Annoncement"     <?php if($company_job->type == "Annoncement")  echo "selected"; ?> >       Annoncement    </option>
                                                            <option value="Job Title"       <?php if($company_job->type == "Job Title")    echo "selected"; ?> >       Job Title      </option>
                                                            <option value="Job E-Mail"      <?php if($company_job->type == "Job E-Mail")   echo "selected"; ?> >       Job E-Mail     </option>
                                                        </select>
                                                    </div>
                                                </div>

                                                <div class="modal-footer">
                                                    <button type="button" class="btn btn-secondary"
                                                        data-dismiss="modal"><?php echo e(trans('front_trans.close')); ?></button>
                                                    <button type="submit"
                                                        class="btn btn-success"><?php echo e(trans('front_trans.submit')); ?></button>
                                                </div>
                                            </form>

                                        </div>
                                    </div>
                                </div>
                            </div>


                            <!-- Make_Visible -->
                            <div class="modal fade" id="vis<?php echo e($company_job->id); ?>" tabindex="-1" role="dialog"
                                aria-labelledby="exampleModalLabel" aria-hidden="true">
                                <div class="modal-dialog" role="document">
                                    <div class="modal-content">
                                        <div class="modal-header">
                                            <h5 style="font-family: 'Cairo', sans-serif;" class="modal-title"
                                                id="exampleModalLabel">
                                                <?php echo e(trans('social_trans.edit_social')); ?>

                                            </h5>
                                            <button type="button" class="close" data-dismiss="modal"
                                                aria-label="Close">
                                                <span aria-hidden="true">&times;</span>
                                            </button>
                                        </div>
                                        <div class="modal-body">
                                            <!-- add_form -->
                                            <form action="<?php echo e(route('visible', 'test')); ?>" method="post">
                                                <?php echo e(method_field('post')); ?>

                                                <?php echo csrf_field(); ?>
                                                    <?php if($company_job->status == '1'): ?>
                                                        <?php echo e(trans('social_trans.unvisible_social')); ?>

                                                    <?php elseif($company_job->status == '0'): ?>
                                                        <?php echo e(trans('social_trans.visible_social')); ?>

                                                    <?php endif; ?>
                                                <input id="id" type="hidden" name="id" class="form-control"
                                                    value="<?php echo e($company_job->id); ?>">
                                                <div class="modal-footer">
                                                    <button type="button" class="btn btn-danger"
                                                        data-dismiss="modal"><?php echo e(trans('social_trans.Close')); ?></button>
                                                    <button type="submit"
                                                        class="btn btn-info"><?php echo e(trans('social_trans.submit')); ?></button>
                                                </div>
                                            </form>
                                        </div>
                                    </div>
                                </div>
                            </div>


                            <!-- delete_modal_social -->
                            <div class="modal fade" id="delete<?php echo e($company_job->id); ?>" tabindex="-1" role="dialog"
                                aria-labelledby="exampleModalLabel" aria-hidden="true">
                                <div class="modal-dialog" role="document">
                                    <div class="modal-content">
                                        <div class="modal-header">
                                            <h5 style="font-family: 'Cairo', sans-serif;" class="modal-title"
                                                id="exampleModalLabel">
                                                <?php echo e(trans('front_trans.delete')); ?>

                                            </h5>
                                            <button type="button" class="close" data-dismiss="modal"
                                                aria-label="Close">
                                                <span aria-hidden="true">&times;</span>
                                            </button>
                                        </div>
                                        <div class="modal-body">
                                            <form action="<?php echo e(route('company_jobs.destroy', 'test')); ?>" method="post">
                                                <?php echo e(method_field('Delete')); ?>

                                                <?php echo csrf_field(); ?>
                                                <?php echo e(trans('social_trans.Warning_social')); ?>

                                                <input id="id" type="hidden" name="id" class="form-control"
                                                    value="<?php echo e($company_job->id); ?>">
                                                <div class="modal-footer">
                                                    <button type="button" class="btn btn-secondary"
                                                        data-dismiss="modal"><?php echo e(trans('social_trans.Close')); ?></button>
                                                    <button type="submit"
                                                        class="btn btn-danger"><?php echo e(trans('front_trans.Delete')); ?></button>
                                                </div>
                                            </form>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </table>
            </div>
        </div>
    </div>
</div>


<!-- add_modal_social -->
<div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
    aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 style="font-family: 'Cairo', sans-serif;" class="modal-title" id="exampleModalLabel">
                    <?php echo e(trans('front_trans.add')); ?>

                </h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <!-- add_form -->
                <form action="<?php echo e(route('company_jobs.store')); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <div class="form-group  small_space">
                        <div class="col">
                            <label for="title_ar" class="mr-sm-2"><?php echo e(trans('feature_trans.name_ar')); ?> :</label>
                            <input type="text" class="form-control" name="title_ar">
                        </div>
                    </div>
                    <div class="form-group  small_space">
                        <div class="col">
                            <label for="title_en" class="mr-sm-2"><?php echo e(trans('feature_trans.name_en')); ?> :</label>
                            <input type="text" class="form-control" name="title_en">
                        </div>
                    </div>
                    <div class="form-group small_space  small_space_select">
                        <div class="col">
                            <label class="mr-sm-2" for="type"><?php echo e(trans('main_trans.type')); ?> : </label>
                            <select name="type" required class="form-control">
                                <option value="0">            <?php echo e(trans('social_trans.0')); ?>             </option>
                                <option value="Annoncement">  <?php echo e(trans('front_trans.annoce')); ?>         </option>
                                <option value="Job Title">    <?php echo e(trans('front_trans.job_title')); ?>      </option>
                                <option value="Job E-Mail">   <?php echo e(trans('front_trans.job_email')); ?>      </option>
                            </select>
                        </div>
                    </div>

                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary"
                            data-dismiss="modal"><?php echo e(trans('social_trans.Close')); ?></button>
                        <button type="submit"
                            class="btn btn-success"><?php echo e(trans('social_trans.submit')); ?></button>
                    </div>
                </form>

            </div>
        </div>
    </div>

</div>

<!-- row closed -->
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
<?php echo toastr_js(); ?>
<?php echo app('toastr')->render(); ?>


<script type="text/javascript">
    $(document).ready(function() {
                $('.summernote').summernote({
                    tabSize: 2,
                    height: 200,
                });
                $("#summernote").code()
                    .replace(/<\/p>/gi, "\n")
                    .replace(/<br\// ** end_phptag ** //gi, "\n")
                        .replace(/<\/?[^>]+(>|$)/g, "");
                    });

</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\4FARH\OneDrive\Desktop\(M-F) Real Estate\resources\views/pages/admin/company_jobs/index.blade.php ENDPATH**/ ?>