<!DOCTYPE html>
<html lang="zxx" class="no-js">

<head>
    <?php echo $__env->make('layouts.partials.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</head>

<body>
    <?php echo $__env->make('layouts.partials.nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="row">
        <div class="col-12">
            <?php echo $__env->make('layouts.partials.flash', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
    </div>


    <!--start title-->
    <div class="title-nav py-4 make_right_ar">
        <div class="container">
            <h2><?php echo e(trans('contactus_trans.main_title')); ?></h2>
        </div>
    </div>
    <!--end title-->
    <!--start lines-->
    <div class="line">
        <div class="line2 line-2-about">
        </div>
    </div>
    <!--end lines-->

    <?php
    $customers = \App\Models\Social::where('type', 'Customers Service')->get();
    $inquiries = \App\Models\Social::where('type', 'Inquiries')->get();
    $accounts = \App\Models\Social::where('type', 'Accounts')->get();
    $recruitments = \App\Models\Social::where('type', 'Recruitment')->get();
    ?>

    <!--start contactus section-->
    <div class="contact-us-section1 py-4">
        <div class="container">
            <div class="row">
                
                <div class="col-xs-12 col-sm-12 col-md-6 col-lg-6 make_right_ar">
                    <h1><?php echo e(trans('front_trans.company_location')); ?></h1>
                    <div class="line line-4"></div>
                    <a>
                        <p><i
                                class="fas fa-map-marker-alt text-9 text-color-light mb-3 mt-2"></i><?php echo e(trans('contactus_trans.address')); ?>

                        </p>
                        <p class="mb-0">
                            <span class="d-block text-2 p-relative bottom-3 Font_01 text-3 mt-2  Font_Clean">
                                هذا النص هو مثال لنص يمكن أن يستبدل في نفس المساحة
                            </span>
                        </p>
                    </a>
                    <a>
                        <p><i
                                class="fas fa-phone-volume text-9 text-color-light mb-3 mt-2"></i><?php echo e(trans('contactus_trans.customers_service')); ?>

                        </p>
                        <p class="mb-0">
                            <span class="d-block text-2 p-relative bottom-3 Font_01 text-3 mt-2  Font_Clean">
                                <?php $__currentLoopData = $customers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $customer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if($customer->status == '1'): ?>
                                        <?php echo e($customer->name); ?>

                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </span>
                        </p>
                    </a>
                    <a>
                        <p><i class="fas fa-info-circle text-9 text-color-light mb-3 mt-2"></i>
                            <?php echo e(trans('contactus_trans.inquiries')); ?></p>
                        <p class="mb-0">
                            <?php $__currentLoopData = $inquiries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $inquirie): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if($inquirie->status == '1'): ?>
                                    <span class="d-block text-2 p-relative bottom-3 Font_01 text-3 mt-2  Font_Clean">
                                        <?php echo e($inquirie->name); ?>

                                    </span>
                                <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </p>
                    </a>
                    <a>
                        <p><i class="fas fa-calculator text-9 text-color-light mb-3 mt-2"></i>
                            <?php echo e(trans('contactus_trans.accounts')); ?></p>
                        <p class="mb-0">
                            <?php $__currentLoopData = $accounts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $account): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if($account->status == '1'): ?>
                                    <span class="d-block text-2 p-relative bottom-3 Font_01 text-3 mt-2  Font_Clean">
                                        <?php echo e($account->name); ?>

                                    </span>
                                <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </p>
                    </a>
                    <a>
                        <p><i class="fas fa-user text-9 text-color-light mb-3 mt-2"></i>
                            <?php echo e(trans('contactus_trans.recruitment')); ?></p>
                        <p class="mb-0">
                            <?php $__currentLoopData = $recruitments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $recruitment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if($recruitment->status == '1'): ?>
                                    <span class="d-block text-2 p-relative bottom-3 Font_01 text-3 mt-2  Font_Clean">
                                        <?php echo e($recruitment->name); ?>

                                    </span>
                                <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </p>
                    </a>
                </div>
                


                <div class="col-xs-12 col-sm-12 col-md-6 col-lg-6 text-right contactus">
                    <h1><?php echo e(trans('contactus_trans.main_title')); ?></h1>
                    <div class="line line-4"></div>

                    <?php echo Form::open(['route' => 'contactus/send_message', 'method' => 'post', 'id' => 'contact-form']); ?>

                    <div class="contact-form-text">
                        <?php echo Form::text('name', old('name'), ['placeholder' => trans('contactus_trans.Name')]); ?>


                        <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><span class="text-danger"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="contact-form-text">
                        <?php echo Form::email('email', old('email'), ['placeholder' => trans('contactus_trans.email')]); ?>

                        <?php echo Form::text('mobile', old('mobile'), ['placeholder' => trans('front_trans.mobile')]); ?>

                    </div>
                    <div class="contact-form-text">
                        <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><span class="text-danger"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        <?php $__errorArgs = ['mobile'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><span class="text-danger"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="contact-form-text">
                        <?php echo Form::text('subject', old('subject'), ['placeholder' => trans('contactus_trans.subject')]); ?>

                        <?php $__errorArgs = ['subject'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><span class="text-danger"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="contact-form-text">
                        <?php echo Form::textarea('message', old('message'), ['placeholder' => trans('contactus_trans.message')]); ?>

                        <?php $__errorArgs = ['message'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><span class="text-danger"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="text-center">
                        <?php echo Form::button(trans('contactus_trans.send_message'), ['type' => 'submit']); ?>

                    </div>
                    <?php echo Form::close(); ?>

                </div>



            </div>

        </div>

    </div>

    </div>
    <!--end contactus section-->
    <!--start map section-->
    <div class="map-section ">
        <iframe
            src="https://www.google.com/maps/embed?pb=!1m14!1m12!1m3!1d27348.384310895814!2d31.38428015!3d31.038839499999995!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!5e0!3m2!1sen!2seg!4v1623335886089!5m2!1sen!2seg"
            width="100%" height="450" style="border:0;" allowfullscreen="" loading="lazy"></iframe>


    </div>
    <!--end map section-->

    <?php echo $__env->make('layouts.partials.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('layouts.partials.footer-scripts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

</body>

</html>
<?php /**PATH C:\Users\4FARH\OneDrive\Desktop\World\resources\views/includes/sitepages/contactus.blade.php ENDPATH**/ ?>