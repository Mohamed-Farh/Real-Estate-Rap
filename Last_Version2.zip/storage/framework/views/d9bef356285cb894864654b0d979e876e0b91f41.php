<?php $__env->startSection('css'); ?>
    <?php echo toastr_css(); ?>


<?php $__env->startSection('title'); ?>
    <?php echo e(trans('gallery_trans.title_page')); ?>

<?php $__env->stopSection(); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('page-header'); ?>
<!-- breadcrumb -->
<?php $__env->startSection('PageTitle'); ?>
<?php echo e(trans('gallery_trans.title_page')); ?>

<?php $__env->stopSection(); ?>
<!-- breadcrumb -->
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<!-- row -->
<div class="row">

<div class="col-xl-12 mb-30">
    <div class="card card-statistics h-100">
        <div class="card-body">

            <?php if($errors->any()): ?>
                <div class="alert alert-danger">
                    <ul>
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><?php echo e($error); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
            <?php endif; ?>

            <button type="button" class="button x-small" data-toggle="modal" data-target="#exampleModal">
                <?php echo e(trans('gallery_trans.add_gallery')); ?>

            </button>
            <br><br>


                <div class="row">
                    <?php $__currentLoopData = $galleries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $gallery): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($gallery->type == '0'): ?>
                            <div class="col-xs-12 col-sm-6 col-md-4 col-lg-4">
                                <div class="card" style="width:100%; margin-bottom: 25px;">
                                    <img class="card-img-top" src="<?php echo e(Url($gallery->path)); ?>" alt="Card image cap" style="width:100%; height:252px;">
                                    <div class="card-body"  style="text-align: -webkit-center;">

                                        <?php if($gallery->status == '0'): ?>
                                            <button type="button" class="btn btn-primary" data-toggle="modal"
                                            data-target="#edit<?php echo e($gallery->id); ?>"
                                            title="<?php echo e(trans('gallery_trans.Delete')); ?>"><i class="fa fa-eye-slash"></i> Un Visible </button>
                                        <?php elseif($gallery->status == '1'): ?>
                                            <button type="button" class="btn btn-primary" data-toggle="modal"
                                            data-target="#edit<?php echo e($gallery->id); ?>"
                                            title="<?php echo e(trans('gallery_trans.Delete')); ?>"><i class="fa fa-eye"></i> Visible </button>
                                        <?php endif; ?>

                                        <button type="button" class="btn btn-danger" data-toggle="modal"
                                                data-target="#delete<?php echo e($gallery->id); ?>"
                                                title="<?php echo e(trans('gallery_trans.Delete')); ?>"><i class="fa fa-trash"></i> Delete </button>
                                    </div>
                                </div>
                            </div>



                            <!-- Make_Image_Visible -->
                            <div class="modal fade" id="edit<?php echo e($gallery->id); ?>" tabindex="-1" role="dialog"
                                aria-labelledby="exampleModalLabel" aria-hidden="true">
                                <div class="modal-dialog" role="document">
                                    <div class="modal-content">
                                        <div class="modal-header">
                                            <h5 style="font-family: 'Cairo', sans-serif;" class="modal-title"
                                                id="exampleModalLabel">
                                                <?php echo e(trans('gallery_trans.edit_gallery')); ?>

                                            </h5>
                                            <button type="button" class="close" data-dismiss="modal"
                                                aria-label="Close">
                                                <span aria-hidden="true">&times;</span>
                                            </button>
                                        </div>
                                        <div class="modal-body">
                                            <!-- add_form -->
                                            <form action="<?php echo e(route('galleries.update', 'test')); ?>" method="post">
                                                <?php echo e(method_field('patch')); ?>

                                                <?php echo csrf_field(); ?>
                                                    <?php if($gallery->status == '1'): ?>
                                                        <?php echo e(trans('gallery_trans.unvisible_gallery')); ?>

                                                    <?php elseif($gallery->status == '0'): ?>
                                                        <?php echo e(trans('gallery_trans.visible_gallery')); ?>

                                                    <?php endif; ?>
                                                <input id="id" type="hidden" name="id" class="form-control"
                                                    value="<?php echo e($gallery->id); ?>">
                                                <div class="modal-footer">
                                                    <button type="button" class="btn btn-danger"
                                                        data-dismiss="modal"><?php echo e(trans('gallery_trans.Close')); ?></button>
                                                    <button type="submit"
                                                        class="btn btn-info"><?php echo e(trans('gallery_trans.submit')); ?></button>
                                                </div>
                                            </form>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <!-- delete_modal_gallery -->
                            <div class="modal fade" id="delete<?php echo e($gallery->id); ?>" tabindex="-1" role="dialog"
                                aria-labelledby="exampleModalLabel" aria-hidden="true">
                                <div class="modal-dialog" role="document">
                                    <div class="modal-content">
                                        <div class="modal-header">
                                            <h5 style="font-family: 'Cairo', sans-serif;" class="modal-title"
                                                id="exampleModalLabel">
                                                <?php echo e(trans('gallery_trans.delete_gallery')); ?>

                                            </h5>
                                            <button type="button" class="close" data-dismiss="modal"
                                                aria-label="Close">
                                                <span aria-hidden="true">&times;</span>
                                            </button>
                                        </div>
                                        <div class="modal-body">
                                            <form action="<?php echo e(route('galleries.destroy', 'test')); ?>" method="post">
                                                <?php echo e(method_field('Delete')); ?>

                                                <?php echo csrf_field(); ?>
                                                <?php echo e(trans('gallery_trans.Warning_gallery')); ?>

                                                <input id="id" type="hidden" name="id" class="form-control"
                                                    value="<?php echo e($gallery->id); ?>">
                                                <div class="modal-footer">
                                                    <button type="button" class="btn btn-secondary"
                                                        data-dismiss="modal"><?php echo e(trans('gallery_trans.Close')); ?></button>
                                                    <button type="submit"
                                                        class="btn btn-danger"><?php echo e(trans('front_trans.Delete')); ?></button>
                                                </div>
                                            </form>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>

            <div class="m-t-30 m-b-60 center">
                <?php echo e($galleries->links()); ?>

            </div>
        </div>
    </div>
</div>


<!-- add_modal_gallery -->
<div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
    aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content gallery">
            <div class="modal-header">
                <h5 style="font-family: 'Cairo', sans-serif;" class="modal-title" id="exampleModalLabel">
                    <?php echo e(trans('gallery_trans.add_gallery')); ?>

                </h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <!-- add_form -->
                <form action="<?php echo e(route('galleries.store')); ?>" method="POST" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <input type="hidden" name="type" value="0" id="type">
                    <div class="form-group">
                        <input type="file" name="files[]" id="post-images" multiple class="file-input-overview"
                            accept="image/*">
                        <?php if($errors->has('files')): ?>
                            <?php $__currentLoopData = $errors->get('files'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($error); ?></strong>
                                </span>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>
                    </div>

                    <div class="form-group">
                        <button type="submit" class="btn btn-success">Save</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

</div>

<!-- row closed -->
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
<?php echo toastr_js(); ?>
<?php echo app('toastr')->render(); ?>


<script type="text/javascript">
    $(document).ready(function() {
                $('.summernote').summernote({
                    tabSize: 2,
                    height: 200,
                });
                $("#summernote").code()
                    .replace(/<\/p>/gi, "\n")
                    .replace(/<br\// ** end_phptag ** //gi, "\n")
                        .replace(/<\/?[^>]+(>|$)/g, "");
                    });

</script>

<script>
    $(function() {
        $('.summernote').summernote({
            tabSize: 2,
            height: 200,
            toolbar: [
                ['style', ['style']],
                ['font', ['bold', 'underline', 'clear']],
                ['color', ['color']],
                ['para', ['ul', 'ol', 'paragraph']],
                ['table', ['table']],
                ['insert', ['link', 'picture', 'video']],
                ['view', ['fullscreen', 'codeview', 'help']]
            ]
        });
        $('#post-images').fileinput({
            theme: "fas",
            maxFileCount: 10,
            allowedFileTypes: ['image'],
            showCancel: true,
            showRemove: false,
            showUpload: false,
            overwriteInitial: false,
        });
    });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/dbsc4c7x1fsq/a_raptors_egypt/resources/views/pages/admin/galleries/index.blade.php ENDPATH**/ ?>