<?php $__env->startSection('css'); ?>
    <?php echo toastr_css(); ?>
<?php $__env->startSection('title'); ?>
    <?php echo e(trans('front_trans.aboutus')); ?>

<?php $__env->stopSection(); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('page-header'); ?>
<!-- breadcrumb -->
<?php $__env->startSection('PageTitle'); ?>
    <?php echo e(trans('front_trans.aboutus')); ?>

<?php $__env->stopSection(); ?>
<!-- breadcrumb -->
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

<!-- row -->
<div class="row">
    <?php if($errors->any()): ?>
        <div class="error"><?php echo e($errors->first('Name')); ?></div>
    <?php endif; ?>

    <div class="col-xl-12 mb-30">
        <div class="card card-statistics h-100">
            <div class="card-body">

                <?php if($errors->any()): ?>
                    <div class="alert alert-danger">
                        <ul>
                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li><?php echo e($error); ?></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </div>
                <?php endif; ?>

                <button type="button" class="button x-small back_property">
                    <a href="<?php echo e(route('aboutus.index')); ?>"><?php echo e(trans('front_trans.return')); ?></a>
                </button>
                <br><br>

                <div class="card-body">

                    <?php echo Form::open(['route' => 'aboutus.store', 'method' => 'post' ]); ?>

                    
                    <div class="row beauty_top">
                        <h2 class="help"><?php echo e(trans('front_trans.aboutus')); ?></h2>
                        <div class="col-12">
                            <div class="form-group">
                                <?php echo Form::label('aboutus_ar', trans('front_trans.aboutus_ar') ); ?>

                                <?php echo Form::textarea('aboutus_ar', old('aboutus_ar'), ['class' => 'form-control summernote']); ?>

                                <?php $__errorArgs = ['aboutus_ar'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><span class="text-danger"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                        <div class="col-12">
                            <div class="form-group">
                                <?php echo Form::label('aboutus_en', trans('front_trans.aboutus_en') ); ?>

                                <?php echo Form::textarea('aboutus_en', old('aboutus_en'), ['class' => 'form-control summernote']); ?>

                                <?php $__errorArgs = ['aboutus_en'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><span class="text-danger"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                        <br><br><br><br>
                    </div>
                    
                    <div class="row beauty">
                        <h2 class="help"><?php echo e(trans('front_trans.numbers')); ?></h2>
                            <div class="col-6">
                                <div class="form-group">
                                    <?php echo Form::label('experience_year', trans('front_trans.experience_year') ); ?>

                                    <?php echo Form::text('experience_year', old('experience_year'), ['class' => 'form-control']); ?>

                                    <?php $__errorArgs = ['experience_year'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><span class="text-danger"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
                            <div class="col-6">
                                <div class="form-group">
                                    <?php echo Form::label('previous_project', trans('front_trans.previous_project') ); ?>

                                    <?php echo Form::text('previous_project', old('previous_project'), ['class' => 'form-control']); ?>

                                    <?php $__errorArgs = ['previous_project'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><span class="text-danger"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
                            <div class="col-6">
                                <div class="form-group">
                                    <?php echo Form::label('under_construction', trans('front_trans.under_construction') ); ?>

                                    <?php echo Form::text('under_construction', old('under_construction'), ['class' => 'form-control']); ?>

                                    <?php $__errorArgs = ['under_construction'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><span class="text-danger"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
                            <div class="col-6">
                                <div class="form-group">
                                    <?php echo Form::label('client', trans('front_trans.client') ); ?>

                                    <?php echo Form::text('client', old('client'), ['class' => 'form-control']); ?>

                                    <?php $__errorArgs = ['client'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><span class="text-danger"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
                    </div>

                    
                    <div class="row beauty">
                        <h2 class="help"><?php echo e(trans('front_trans.message')); ?></h2>
                        <div class="col-12">
                            <div class="form-group">
                                <?php echo Form::label('message_ar', trans('front_trans.message_ar') ); ?>

                                <?php echo Form::textarea('message_ar', old('message_ar'), ['class' => 'form-control summernote']); ?>

                                <?php $__errorArgs = ['message_ar'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><span class="text-danger"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                        <div class="col-12">
                            <div class="form-group">
                                <?php echo Form::label('message_en', trans('front_trans.message_en') ); ?>

                                <?php echo Form::textarea('message_en', old('message_en'), ['class' => 'form-control summernote']); ?>

                                <?php $__errorArgs = ['message_en'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><span class="text-danger"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                    </div>

                    
                    <div class="row beauty">
                        <h2 class="help"><?php echo e(trans('front_trans.vision')); ?></h2>
                        <div class="col-12">
                            <div class="form-group">
                                <?php echo Form::label('vision_ar', trans('front_trans.vision_ar') ); ?>

                                <?php echo Form::textarea('vision_ar', old('vision_ar'), ['class' => 'form-control summernote']); ?>

                                <?php $__errorArgs = ['vision_ar'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><span class="text-danger"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                        <div class="col-12">
                            <div class="form-group">
                                <?php echo Form::label('vision_en', trans('front_trans.vision_en') ); ?>

                                <?php echo Form::textarea('vision_en', old('vision_en'), ['class' => 'form-control summernote']); ?>

                                <?php $__errorArgs = ['vision_en'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><span class="text-danger"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                    </div>

                    
                    <div class="row beauty">
                        <h2 class="help"><?php echo e(trans('front_trans.whyus')); ?></h2>
                        <div class="col-12">
                            <div class="form-group">
                                <?php echo Form::label('whyus_ar', trans('front_trans.whyus_ar') ); ?>

                                <?php echo Form::textarea('whyus_ar', old('whyus_ar'), ['class' => 'form-control summernote']); ?>

                                <?php $__errorArgs = ['whyus_ar'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><span class="text-danger"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                        <div class="col-12">
                            <div class="form-group">
                                <?php echo Form::label('whyus_en', trans('front_trans.whyus_en') ); ?>

                                <?php echo Form::textarea('whyus_en', old('whyus_en'), ['class' => 'form-control summernote']); ?>

                                <?php $__errorArgs = ['whyus_en'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><span class="text-danger"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                    </div>

                    <div class="form-group pt-4">
                        <?php echo Form::submit( trans('front_trans.submit') , ['class' => 'btn btn-primary']); ?>

                    </div>
                    <?php echo Form::close(); ?>

                </div>
            </div>
        </div>
    </div>

</div>

<!-- row closed -->
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
<?php echo toastr_js(); ?>
<?php echo app('toastr')->render(); ?>
    <script>
        $(function () {
            // $('.summernote').summernote({
            //     tabSize: 2,
            //     height: 200,
            //     toolbar: [
            //         ['style', ['style']],
            //         ['font', ['bold', 'underline', 'clear']],
            //         ['color', ['color']],
            //         ['para', ['ul', 'ol', 'paragraph']],
            //         ['table', ['table']],
            //         ['insert', ['link', 'picture', 'video']],
            //         ['view', ['fullscreen', 'codeview', 'help']]
            //     ]
            // });
            $('#post-images').fileinput({
                theme: "fas",
                maxFileCount: 10,
                allowedFileTypes: ['image'],
                showCancel: true,
                showRemove: false,
                showUpload: false,
                overwriteInitial: false,

            });

        });
    </script>
     <script type="text/javascript">
        $(document).ready(function() {
          $('.summernote').summernote({
                tabSize: 2,
                height: 200,
            });
        });
    </script>
<?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\4FARH\OneDrive\Desktop\World\resources\views/pages/admin/aboutus/create.blade.php ENDPATH**/ ?>