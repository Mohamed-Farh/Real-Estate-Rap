<?php $__env->startSection('css'); ?>
    <?php echo toastr_css(); ?>


<?php $__env->startSection('title'); ?>
    <?php echo e(trans('feature_trans.title_page')); ?>

<?php $__env->stopSection(); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('page-header'); ?>
<!-- breadcrumb -->
<?php $__env->startSection('PageTitle'); ?>
<?php echo e(trans('feature_trans.title_page')); ?>

<?php $__env->stopSection(); ?>
<!-- breadcrumb -->
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<!-- row -->
<div class="row">

<div class="col-xl-12 mb-30">
    <div class="card card-statistics h-100">
        <div class="card-body">

            <?php if($errors->any()): ?>
                <div class="alert alert-danger">
                    <ul>
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><?php echo e($error); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
            <?php endif; ?>

            <button type="button" class="button x-small" data-toggle="modal" data-target="#exampleModal">
                <?php echo e(trans('feature_trans.add_feature')); ?>

            </button>
            <br><br>

            <div class="table-responsive">
                <table id="datatable" class="table  table-hover table-sm table-bordered p-0" data-page-length="50"
                    style="text-align: center">
                    <thead>
                        <tr>
                            <th>#</th>
                            <th><?php echo e(trans('main_trans.name-ar')); ?></th>
                            <th><?php echo e(trans('main_trans.name-en')); ?></th>
                            <th><?php echo e(trans('feature_trans.Notes')); ?></th>
                            <th><?php echo e(trans('feature_trans.Processes')); ?></th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $i = 0; ?>
                        <?php $__currentLoopData = $features; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $feature): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <?php $i++; ?>
                                    <td><?php echo e($i); ?></td>
                                    <td><?php echo e($feature->name_ar); ?></td>
                                    <td><?php echo e($feature->name_en); ?></td>
                                    <td><?php echo e($feature->Notes); ?></td>

                                    <td>
                                        <button type="button" class="btn btn-info btn-sm" data-toggle="modal"
                                            data-target="#edit<?php echo e($feature->id); ?>"
                                            title="<?php echo e(trans('feature_trans.Edit')); ?>"><i
                                                class="fa fa-edit"></i></button>

                                        <button type="button" class="btn btn-danger btn-sm" data-toggle="modal"
                                            data-target="#delete<?php echo e($feature->id); ?>"
                                            title="<?php echo e(trans('feature_trans.Delete')); ?>"><i
                                                class="fa fa-trash"></i></button>
                                    </td>
                            </tr>

                            <!-- edit_modal_feature -->
                            <div class="modal fade" id="edit<?php echo e($feature->id); ?>" tabindex="-1" role="dialog"
                                aria-labelledby="exampleModalLabel" aria-hidden="true">
                                <div class="modal-dialog" role="document">
                                    <div class="modal-content">
                                        <div class="modal-header">
                                            <h5 style="font-family: 'Cairo', sans-serif;" class="modal-title"
                                                id="exampleModalLabel">
                                                <?php echo e(trans('feature_trans.edit_feature')); ?>

                                            </h5>
                                            <button type="button" class="close" data-dismiss="modal"
                                                aria-label="Close">
                                                <span aria-hidden="true">&times;</span>
                                            </button>
                                        </div>
                                        <div class="modal-body">
                                            <!-- add_form -->
                                            <form action="<?php echo e(route('features.update', 'test')); ?>" method="post">
                                                <?php echo e(method_field('patch')); ?>

                                                <?php echo csrf_field(); ?>
                                                <div class="row">
                                                    <div class="col-12 small_space">
                                                        <label for="name-ar"
                                                            class="mr-sm-2"><?php echo e(trans('feature_trans.name_ar')); ?>

                                                            :</label>
                                                        <input id="name-ar" type="text" name="name_ar"
                                                            class="form-control" value="<?php echo e($feature->name_ar); ?>"
                                                            required>

                                                        <input id="id" type="hidden" name="id" class="form-control"
                                                            value="<?php echo e($feature->id); ?>">
                                                    </div>
                                                    <div class="col-12 small_space">
                                                        <label for="name_en"
                                                            class="mr-sm-2"><?php echo e(trans('feature_trans.name_en')); ?>

                                                            :</label>
                                                        <input type="text" class="form-control" name="name_en"
                                                            value="<?php echo e($feature->name_en); ?>" required>
                                                    </div>
                                                </div>

                                                <div class="form-group small_space">
                                                    <label for="exampleFormControlTextarea1"><?php echo e(trans('category_trans.Notes')); ?>:</label>
                                                    <textarea class="summernote" name="Notes" id="exampleFormControlTextarea1"
                                                    rows="3"><?php echo e($feature->Notes); ?></textarea>
                                                </div>
                                                <br><br>

                                                <div class="modal-footer">
                                                    <button type="button" class="btn btn-secondary"
                                                        data-dismiss="modal"><?php echo e(trans('feature_trans.Close')); ?></button>
                                                    <button type="submit"
                                                        class="btn btn-success"><?php echo e(trans('feature_trans.submit')); ?></button>
                                                </div>
                                            </form>

                                        </div>
                                    </div>
                                </div>
                            </div>

                            <!-- delete_modal_feature -->
                            <div class="modal fade" id="delete<?php echo e($feature->id); ?>" tabindex="-1" role="dialog"
                                aria-labelledby="exampleModalLabel" aria-hidden="true">
                                <div class="modal-dialog" role="document">
                                    <div class="modal-content">
                                        <div class="modal-header">
                                            <h5 style="font-family: 'Cairo', sans-serif;" class="modal-title"
                                                id="exampleModalLabel">
                                                <?php echo e(trans('feature_trans.delete_feature')); ?>

                                            </h5>
                                            <button type="button" class="close" data-dismiss="modal"
                                                aria-label="Close">
                                                <span aria-hidden="true">&times;</span>
                                            </button>
                                        </div>
                                        <div class="modal-body">
                                            <form action="<?php echo e(route('features.destroy', 'test')); ?>" method="post">
                                                <?php echo e(method_field('Delete')); ?>

                                                <?php echo csrf_field(); ?>
                                                <?php echo e(trans('feature_trans.Warning_feature')); ?>

                                                <input id="id" type="hidden" name="id" class="form-control"
                                                    value="<?php echo e($feature->id); ?>">
                                                <div class="modal-footer">
                                                    <button type="button" class="btn btn-secondary"
                                                        data-dismiss="modal"><?php echo e(trans('feature_trans.Close')); ?></button>
                                                    <button type="submit"
                                                        class="btn btn-danger"><?php echo e(trans('front_trans.Delete')); ?></button>
                                                </div>
                                            </form>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </table>
            </div>
        </div>
    </div>
</div>


<!-- add_modal_feature -->
<div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
    aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 style="font-family: 'Cairo', sans-serif;" class="modal-title" id="exampleModalLabel">
                    <?php echo e(trans('feature_trans.add_feature')); ?>

                </h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <!-- add_form -->
                <form action="<?php echo e(route('features.store')); ?>" method="POST">
                    <?php echo csrf_field(); ?>

                    <?php if(App::getLocale() == 'en'): ?>
                        <div class="form-group">
                            <div class="col-12">
                                <label for="name_en" class="mr-sm-2"><?php echo e(trans('feature_trans.name_en')); ?>

                                    :</label>
                                <input type="text" class="form-control" name="name_en">
                            </div>
                        </div>
                        <div class="form-group">
                            <div class="col-12">
                                <label for="name-ar" class="mr-sm-2"><?php echo e(trans('feature_trans.name_ar')); ?>

                                    :</label>
                                <input id="name-ar" type="text" name="name_ar" class="form-control">
                            </div>
                        </div>
                    <?php else: ?>
                        <div class="form-group">
                            <div class="col-12">
                                <label for="name-ar" class="mr-sm-2"><?php echo e(trans('feature_trans.name_ar')); ?>

                                    :</label>
                                <input id="name-ar" type="text" name="name_ar" class="form-control">
                            </div>
                        </div>
                        <div class="form-group">
                            <div class="col-12">
                                <label for="name_en" class="mr-sm-2"><?php echo e(trans('feature_trans.name_en')); ?>

                                    :</label>
                                <input type="text" class="form-control" name="name_en">
                            </div>
                        </div>
                    <?php endif; ?>

                    <div class="form-group">
                        <label for="exampleFormControlTextarea1"><?php echo e(trans('feature_trans.Notes')); ?>

                            :</label>
                        <textarea class="form-control" name="Notes" id="exampleFormControlTextarea1"
                            rows="3"></textarea>
                    </div>

                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary"
                            data-dismiss="modal"><?php echo e(trans('feature_trans.Close')); ?></button>
                        <button type="submit"
                            class="btn btn-success"><?php echo e(trans('feature_trans.submit')); ?></button>
                    </div>
                </form>

            </div>
        </div>
    </div>

</div>

<!-- row closed -->
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
<?php echo toastr_js(); ?>
<?php echo app('toastr')->render(); ?>

<script type="text/javascript">
    $(document).ready(function() {
      $('.summernote').summernote({
            tabSize: 2,
            height: 100,
        });
        $("#summernote").code()
                .replace(/<\/p>/gi, "\n")
                .replace(/<br\/?>/gi, "\n")
                .replace(/<\/?[^>]+(>|$)/g, "");
    });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\4FARH\OneDrive\Desktop\(M-F) Real Estate\resources\views/pages/admin/features/index.blade.php ENDPATH**/ ?>