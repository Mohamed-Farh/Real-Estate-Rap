<meta charset="utf-8" />
<meta name="viewport" content="width=device-width,initial-scale=1,shrink-to-fit=no" />

<title>
    raptors
</title>
<link rel="stylesheet" href='<?php echo e(asset('app-assets/fontawesome/css/all.min.css')); ?>'>
<link rel="stylesheet" href="<?php echo e(asset('app-assets/css/bootstrap.css')); ?>">
<link href="https://cdn.rawgit.com/michalsnik/aos/2.1.1/dist/aos.css" rel="stylesheet">

<link rel="stylesheet" href="<?php echo e(asset('app-assets/css/swiper-bundle.min.css')); ?>" />

<!--- Style css -->
<?php if(App::getLocale() == 'en'): ?>
<link href="<?php echo e(asset('app-assets/css/style.css')); ?>" rel="stylesheet">
<?php else: ?>
<link href="<?php echo e(asset('app-assets/css/stylesheet.css')); ?>" rel="stylesheet">
<?php endif; ?>


<?php /**PATH C:\Users\4FARH\OneDrive\Desktop\Real-Estate Last Version\resources\views/layouts/partials/head.blade.php ENDPATH**/ ?>