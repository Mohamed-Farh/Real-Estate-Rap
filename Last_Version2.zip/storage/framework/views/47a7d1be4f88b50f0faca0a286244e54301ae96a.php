<?php $__env->startSection('css'); ?>
    <?php echo toastr_css(); ?>
<?php $__env->startSection('title'); ?>
    <?php echo e(trans('admins_trans.title_page')); ?>

<?php $__env->stopSection(); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('page-header'); ?>
<!-- breadcrumb -->
<?php $__env->startSection('PageTitle'); ?>
    <?php echo e(trans('main_trans.Admin')); ?>

<?php $__env->stopSection(); ?>
<!-- breadcrumb -->
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<!-- row -->
<div class="row">


<?php if($errors->any()): ?>
    <div class="error"><?php echo e($errors->first('Name')); ?></div>
<?php endif; ?>



<div class="col-xl-12 mb-30">
    <div class="card card-statistics h-100">
        <div class="card-body">

            <?php if($errors->any()): ?>
                <div class="alert alert-danger">
                    <ul>
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><?php echo e($error); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
            <?php endif; ?>

            <button type="button" class="button x-small" data-toggle="modal" data-target="#exampleModal">
                <?php echo e(trans('admins_trans.add_user')); ?>

            </button>
            <br><br>

            <div class="table-responsive">
                <table id="datatable" class="table  table-hover table-sm table-bordered p-0" data-page-length="50"
                    style="text-align: center">
                    <thead>
                        <tr>
                            <th>#</th>
                            <th><?php echo e(trans('admins_trans.Name')); ?></th>
                            <th><?php echo e(trans('admins_trans.email')); ?></th>
                            <th><?php echo e(trans('admins_trans.created_at')); ?></th>
                            <th><?php echo e(trans('admins_trans.Processes')); ?></th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $i = 0; ?>
                        <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <?php $i++; ?>
                                <td><?php echo e($i); ?></td>

                                <?php if(App::getLocale() == 'en'): ?>
                                    <?php if($user->name !=''): ?>
                                        <td><?php echo e($user->name); ?></td>
                                    <?php else: ?>
                                        <td><?php echo e($user->name_ar); ?></td>
                                    <?php endif; ?>
                                <?php else: ?>
                                    <?php if($user->name_ar !=''): ?>
                                        <td><?php echo e($user->name_ar); ?></td>
                                    <?php else: ?>
                                        <td><?php echo e($user->name); ?></td>
                                    <?php endif; ?>
                                <?php endif; ?>

                                <td><?php echo e($user->email); ?></td>
                                <td><?php echo e($user->created_at->diffForHumans()); ?></td>
                                <td class="aaa">
                                    <button type="button" class="btn btn-info btn-sm given_edit" data-toggle="modal"
                                        data-target="#edit<?php echo e($user->id); ?>"
                                        title="<?php echo e(trans('admins_trans.Edit')); ?>"><i class="fa fa-edit"></i></button>

                                    <?php if($user->id != auth()->id()): ?>
                                        <form action="<?php echo e(route('admins.destroy', 'test')); ?>" method="post">
                                            <?php echo e(method_field('Delete')); ?>

                                            <?php echo csrf_field(); ?>
                                            <input id="id" type="hidden" name="id" class="form-control"
                                                value="<?php echo e($user->id); ?>">

                                            <?php if(App::getLocale() == 'en'): ?>
                                                <button type="button" class="btn btn-danger btn-sm given"
                                            onclick="confirm('<?php echo e(__("Are You Sure You Want To Delete This Admin ?")); ?>') ? this.parentElement.submit() : ''"><i class="fa fa-trash"></i></button>
                                            <?php else: ?>
                                                <button type="button" class="btn btn-danger btn-sm given_ar"
                                            onclick="confirm('<?php echo e(__("هل انت متأكد من عملبة الحذف ؟")); ?>') ? this.parentElement.submit() : ''"><i class="fa fa-trash"></i></button>
                                            <?php endif; ?>
                                        </form>
                                    <?php endif; ?>
                                </td>
                            </tr>

                            <!-- edit_modal_user -->
                            <div class="modal fade" id="edit<?php echo e($user->id); ?>" tabindex="-1" role="dialog"
                                aria-labelledby="exampleModalLabel" aria-hidden="true">
                                <div class="modal-dialog" role="document">
                                    <div class="modal-content">
                                        <div class="modal-header">
                                            <h5 style="font-family: 'Cairo', sans-serif;" class="modal-title"
                                                id="exampleModalLabel">
                                                <?php echo e(trans('admins_trans.edit_user')); ?>

                                            </h5>
                                            <button type="button" class="close" data-dismiss="modal"
                                                aria-label="Close">
                                                <span aria-hidden="true">&times;</span>
                                            </button>
                                        </div>
                                        <div class="modal-body">
                                            <!-- add_form -->
                                            <form action="<?php echo e(route('admins.update', 'test')); ?>" method="post">
                                                <?php echo e(method_field('patch')); ?>

                                                <?php echo csrf_field(); ?>
                                                <div class="row">
                                                    <div class="col">
                                                        <div class="col-md-12">
                                                            <label for="name" class="mr-sm-2 space_top"><?php echo e(trans('admins_trans.name')); ?> :</label>
                                                            <input id="name" type="text" name="name" class="form-control" value="<?php echo e($user->name); ?>" required>
                                                            <input id="id" type="hidden" name="id" class="form-control"
                                                                value="<?php echo e($user->id); ?>">
                                                        </div>

                                                        <div class="col-md-12">
                                                            <label for="name_ar" class="mr-sm-2 space_top"><?php echo e(trans('admins_trans.name_ar')); ?> :</label>
                                                            <input id="name_ar" type="text" name="name_ar" class="form-control" value="<?php echo e($user->name_ar); ?>" required>
                                                        </div>

                                                        <div class="col-md-12">
                                                            <label for="email" class="mr-sm-2 space_top"><?php echo e(trans('admins_trans.email')); ?> :</label>
                                                            <input type="email" class="form-control" name="email" value="<?php echo e($user->email); ?>">
                                                        </div>

                                                        <div class="col-md-12">
                                                            <label for="password" class="mr-sm-2 space_top"><?php echo e(trans('admins_trans.password')); ?> :</label>
                                                            <input type="password" class="form-control" name="password" value="">
                                                        </div>

                                                        <div class="col-md-12">
                                                            <label class="mr-sm-2 space_top" for="input-password-confirmation"><?php echo e(trans('admins_trans.confirm_password')); ?> :</label>
                                                            <input type="password" name="password_confirmation" id="input-password-confirmation" class="form-control" value="">
                                                        </div>
                                                <br><br>

                                                <div class="modal-footer">
                                                    <button type="button" class="btn btn-secondary"
                                                        data-dismiss="modal"><?php echo e(trans('admins_trans.Close')); ?></button>
                                                    <button type="submit"
                                                        class="btn btn-success"><?php echo e(trans('admins_trans.submit')); ?></button>
                                                </div>
                                            </form>

                                        </div>
                                    </div>
                                </div>
                            </div>


                            <!-- delete_modal_user -->
                            


                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </table>
                    </div>
                </div>
            </div>
        </div>


<!-- add_modal_user -->
<div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
    aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 style="font-family: 'Cairo', sans-serif;" class="modal-title" id="exampleModalLabel">
                    <?php echo e(trans('admins_trans.add_user')); ?>

                </h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <!-- add_form -->
                <form action="<?php echo e(route('admins.store')); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <input type="hidden" name="admin" value="1" id="admin">
                    <div class="row">
                        <div class="col-md-12">
                            <label for="name" class="mr-sm-2 space_top"><?php echo e(trans('admins_trans.name')); ?> :</label>
                            <input id="name" type="text" name="name" class="form-control" value="<?php echo e(old('name')); ?>" required autocomplete="name" autofocus>
                        </div>

                        <div class="col-md-12">
                            <label for="name_ar" class="mr-sm-2 space_top"><?php echo e(trans('admins_trans.name_ar')); ?> :</label>
                            <input id="name_ar" type="text" name="name_ar" class="form-control" value="<?php echo e(old('name')); ?>" autocomplete="name" autofocus>
                        </div>

                        <div class="col-md-12">
                            <label for="email" class="mr-sm-2 space_top"><?php echo e(trans('admins_trans.email')); ?> :</label>
                            <input type="email" class="form-control" name="email" value="<?php echo e(old('email')); ?>" required autocomplete="email">
                        </div>

                        <div class="col-md-12 make-space">
                            <label for="password" class="mr-sm-2 space_top"><?php echo e(trans('admins_trans.password')); ?> :</label>
                            <input type="password" class="form-control" name="password" required autocomplete="new-password">
                        </div>

                        <div class="col-md-12 make-space">
                            <label class="mr-sm-2 space_top" for="input-password-confirmation"><?php echo e(trans('admins_trans.confirm_password')); ?> :</label>
                            <input type="password" name="password_confirmation" id="input-password-confirmation" class="form-control" required>
                        </div>
                    <br><br>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary"
                        data-dismiss="modal"><?php echo e(trans('admins_trans.Close')); ?></button>
                    <button type="submit" class="btn btn-success"><?php echo e(trans('admins_trans.submit')); ?></button>
                </div>
            </form>

        </div>
    </div>
</div>

</div>

<!-- row closed -->
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
<?php echo toastr_js(); ?>
<?php echo app('toastr')->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/dbsc4c7x1fsq/a_raptors_egypt/resources/views/pages/admin/admins/index.blade.php ENDPATH**/ ?>