<?php $__env->startSection('css'); ?>
    <?php echo toastr_css(); ?>
<?php $__env->startSection('title'); ?>
    <?php echo e(trans('contactus_trans.messages')); ?>

<?php $__env->stopSection(); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('page-header'); ?>
<!-- breadcrumb -->
<?php $__env->startSection('PageTitle'); ?>
<?php echo e(trans('contactus_trans.messages')); ?>

<?php $__env->stopSection(); ?>
<!-- breadcrumb -->
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<!-- row -->
<div class="row">

<div class="col-xl-12 mb-30">
    <div class="card card-statistics h-100">
        <div class="card-body">

            <?php if($errors->any()): ?>
                <div class="alert alert-danger">
                    <ul>
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><?php echo e($error); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
            <?php endif; ?>



            <div class="table-responsive">
                <table id="datatable" class="table  table-hover table-sm table-bordered p-0" data-page-length="50"
                    style="text-align: center">
                    <thead>
                        <tr>
                            <th>#</th>
                            <th><?php echo e(trans('contactus_trans.Name')); ?></th>
                            <th><?php echo e(trans('contactus_trans.email')); ?></th>
                            <th><?php echo e(trans('contactus_trans.phone')); ?></th>
                            <th><?php echo e(trans('contactus_trans.subject')); ?></th>
                            <th><?php echo e(trans('contactus_trans.created_at')); ?></th>
                            <th><?php echo e(trans('contactus_trans.Processes')); ?></th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $i = 0; ?>
                        <?php $__currentLoopData = $messages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <?php $i++; ?>
                                <td><?php echo e($i); ?></td>
                                <td><?php echo e($message->name); ?></td>
                                <td><?php echo e($message->email); ?></td>
                                <td><?php echo e($message->mobile); ?></td>
                                <td><?php echo e($message->subject); ?></td>
                                <td><?php echo e($message->created_at->format('d-m-Y h:i a')); ?></td>
                                <td>

                                    <button type="button" class="btn btn-info btn-sm" data-toggle="modal"
                                    data-target="#show<?php echo e($message->id); ?>"
                                    title="<?php echo e(trans('contactus_trans.show')); ?>"><i
                                        class="fa fa-eye"></i></button>

                                    <?php if($message->status == '0'): ?>
                                        <button type="button" class="btn btn-info" data-toggle="modal"
                                        data-target="#read<?php echo e($message->id); ?>"
                                        title="<?php echo e(trans('contactus_trans.edit_contactus')); ?>"><i class="fa fa-check"></i> Read</button>
                                    <?php endif; ?>

                                    <button type="button" class="btn btn-danger btn-sm" data-toggle="modal"
                                        data-target="#delete<?php echo e($message->id); ?>"
                                        title="<?php echo e(trans('contactus_trans.Delete')); ?>"><i
                                            class="fa fa-trash"></i></button>
                                </td>
                            </tr>


                            <!-- Make Message Read -->
                            <div class="modal fade" id="read<?php echo e($message->id); ?>" tabindex="-1" role="dialog"
                                aria-labelledby="exampleModalLabel" aria-hidden="true">
                                <div class="modal-dialog" role="document">
                                    <div class="modal-content">
                                        <div class="modal-header">
                                            <h5 style="font-family: 'Cairo', sans-serif;" class="modal-title"
                                                id="exampleModalLabel">
                                                <?php echo e(trans('contactus_trans.edit_contactus')); ?>

                                            </h5>
                                            <button type="button" class="close" data-dismiss="modal"
                                                aria-label="Close">
                                                <span aria-hidden="true">&times;</span>
                                            </button>
                                        </div>
                                        <div class="modal-body">
                                            <!-- add_form -->
                                            <form action="<?php echo e(route('contactus/messages_read', 'test')); ?>" method="post">
                                                <?php echo e(method_field('post')); ?>

                                                <?php echo csrf_field(); ?>
                                                <input type="hidden" name="status" value="1" id="status">

                                                <input id="id" type="hidden" name="id" class="form-control"
                                                    value="<?php echo e($message->id); ?>">
                                                    <?php echo e(trans('contactus_trans.read')); ?>

                                                <div class="modal-footer">
                                                    <button type="button" class="btn btn-secondary"
                                                        data-dismiss="modal"><?php echo e(trans('contactus_trans.Close')); ?></button>
                                                    <button type="submit"
                                                        class="btn btn-danger"><?php echo e(trans('contactus_trans.submit')); ?></button>
                                                </div>
                                            </form>
                                        </div>
                                    </div>
                                </div>
                            </div>


                            <!-- show_modal_message-->
                            <div class="modal fade" id="show<?php echo e($message->id); ?>" tabindex="-1" role="dialog"
                                aria-labelledby="exampleModalLabel" aria-hidden="true">
                                <div class="modal-dialog" role="document">
                                    <div class="modal-content">
                                        <div class="modal-header">
                                            <h5 style="font-family: 'Cairo', sans-serif;" class="modal-title"
                                                id="exampleModalLabel">
                                                <?php echo e($message->name); ?>

                                            </h5>
                                            <button type="button" class="close" data-dismiss="modal"
                                                aria-label="Close">
                                                <span aria-hidden="true">&times;</span>
                                            </button>
                                        </div>
                                        <div class="modal-body">
                                            <!-- add_form -->
                                            <h4>
                                                <?php echo e($message->message); ?>

                                            </h4>

                                        </div>
                                    </div>
                                </div>
                            </div>


                            <!-- delete_modal_contactus -->
                            <div class="modal fade" id="delete<?php echo e($message->id); ?>" tabindex="-1" role="dialog"
                                aria-labelledby="exampleModalLabel" aria-hidden="true">
                                <div class="modal-dialog" role="document">
                                    <div class="modal-content">
                                        <div class="modal-header">
                                            <h5 style="font-family: 'Cairo', sans-serif;" class="modal-title"
                                                id="exampleModalLabel">
                                                <?php echo e(trans('contactus_trans.delete_contactus')); ?>

                                            </h5>
                                            <button type="button" class="close" data-dismiss="modal"
                                                aria-label="Close">
                                                <span aria-hidden="true">&times;</span>
                                            </button>
                                        </div>
                                        <div class="modal-body">
                                            <form action="<?php echo e(route('contactus/messages_delete', 'test')); ?>" method="post">
                                                <?php echo e(method_field('Post')); ?>

                                                <?php echo csrf_field(); ?>
                                                <?php echo e(trans('contactus_trans.Warning_contactus')); ?>

                                                <input id="id" type="hidden" name="id" class="form-control"
                                                    value="<?php echo e($message->id); ?>">
                                                <div class="modal-footer">
                                                    <button type="button" class="btn btn-secondary"
                                                        data-dismiss="modal"><?php echo e(trans('contactus_trans.Close')); ?></button>
                                                    <button type="submit"
                                                        class="btn btn-danger"><?php echo e(trans('contactus_trans.submit')); ?></button>
                                                </div>
                                            </form>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </table>
            </div>
        </div>
    </div>
</div>










            


<!-- row closed -->
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
<?php echo toastr_js(); ?>
<?php echo app('toastr')->render(); ?>


<script type="text/javascript">
    $(document).ready(function() {
                $('.summernote').summernote({
                    tabSize: 2,
                    height: 200,
                });
                $("#summernote").code()
                    .replace(/<\/p>/gi, "\n")
                    .replace(/<br\// ** end_phptag ** //gi, "\n")
                        .replace(/<\/?[^>]+(>|$)/g, "");
                    });

</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\4FARH\OneDrive\Desktop\World\resources\views/pages/admin/messages/index.blade.php ENDPATH**/ ?>