<!-- Footer opened -->

<!-- Footer closed -->
<?php /**PATH C:\Users\4FARH\OneDrive\Desktop\Real-Estate Last Version\resources\views/layouts/footer.blade.php ENDPATH**/ ?>