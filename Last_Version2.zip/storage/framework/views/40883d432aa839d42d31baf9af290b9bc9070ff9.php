<!DOCTYPE html>
<html lang="zxx" class="no-js">

<head>
    <?php echo $__env->make('layouts.partials.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</head>

<body>
    <?php echo $__env->make('layouts.partials.nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="row">
        <div class="col-12">
            <?php echo $__env->make('layouts.partials.flash', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
    </div>


    <!--start title-->
    <div class="title-nav py-4 text-right">
        <div class="container">
            <h2><?php echo e(trans('main_trans.Main_title')); ?></h2>
        </div>
    </div>
    <!--end title-->
    <!--start lines-->
    <div class="line">
        <div class="line2 line-2-about line-3-search line-4-images">
        </div>
    </div>
    <!--end lines-->




    <!--start image section-->
    <div class="image-latest-news py-4 text-center">
        <div class="container">
            <?php if($single_new->photo): ?>
                <img src="<?php echo e(url('image/news/'.$single_new->photo)); ?>" style="width: 100%;"  />
            <?php else: ?>
                <img src="<?php echo e(url('image/news/default.jpg')); ?>" style="width: 100%;"  />
            <?php endif; ?>
        </div>
    </div>
    <!--end image section-->
    <!--start deatails section-->
    <div class="newslatest-3 py-3 text-center">
        <div class="container">
            <h1 data-aos="fade-down"><?php echo e(trans('front_trans.last_news')); ?></h1>
            <div class="line-6 ">
            </div>
            <h5 data-aos="fade-down" style="margin-top: 20px;">
                <?php if(App::getLocale() == 'en'): ?>
                    <?php if($single_new->head_en !=''): ?>
                        <th><?php echo e(\Str::limit($single_new->head_en,100)); ?></th>
                    <?php else: ?>
                        <th><?php echo e(\Str::limit($single_new->head_ar,100)); ?></th>
                    <?php endif; ?>
                <?php else: ?>
                    <th><?php echo e(\Str::limit($single_new->head_ar,100)); ?></th>
                <?php endif; ?>
            </h5>
            <p data-aos="fade-down" style="margin-top: 20px;">
                <?php if(App::getLocale() == 'en'): ?>
                    <?php if($single_new->body_en !=''): ?>
                        <th><?php echo e(\Str::limit($single_new->body_en,180)); ?></th>
                    <?php else: ?>
                        <th><?php echo e(\Str::limit($single_new->body_ar,180)); ?></th>
                    <?php endif; ?>
                <?php else: ?>
                    <th><?php echo e(\Str::limit($single_new->body_ar,180)); ?></th>
                <?php endif; ?>
            </p>
        </div>
    </div>
    <!--end deatails section-->
    <!--start share links-->
    <div class="share-links text-center py-4">
        <div class="container">
            <h1 data-aos="fade-up">شارك رابط</h1>
            <div class="line-6">
            </div>
            <div class="row py-4 container-fluid">
                <div class="col-xs-12 col-sm-12 col-md-3 col-lg-3 py-3">
                    <button><a href="https://www.facebook.com/sharer/sharer.php?u=https%3A%2F%2Fparse.com" target="_blank">Facebook<i class="fab fa-facebook-f"></i></a></button>
                </div>
                <div class="col-xs-12 col-sm-12 col-md-3 col-lg-3 py-3">
                    <button><a href="https://twitter.com/intent/tweet?url=URL_HERE&via=getboldify&text=yourtext" target="_blank">Twitter<i class="fab fa-twitter"></i></a></button>
                </div>
                <div class="col-xs-12 col-sm-12 col-md-3 col-lg-3 py-3">
                    <button><a href="https://www.instagram.com/?url=https://www.drdrop.co/" target="_blank">Instagram<i class="fab fa-instagram"></i></a></button>
                </div>
                <div class="col-xs-12 col-sm-12 col-md-3 col-lg-3 py-3">
                    <button><a href="https://wa.me/?text=urlencodedtext" target="_blank"> Whatsapp<i class="fab fa-whatsapp"></i></a></button>
                </div>
            </div>
        </div>
    </div>
    <!--end share links-->








    <?php echo $__env->make('layouts.partials.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('layouts.partials.footer-scripts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

</body>

</html>
<?php /**PATH /home/dbsc4c7x1fsq/last_v/resources/views/includes/sitepages/news_details.blade.php ENDPATH**/ ?>