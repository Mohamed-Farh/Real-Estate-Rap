<!-- Footer opened -->

<!-- Footer closed -->
<?php /**PATH /home/dbsc4c7x1fsq/a_raptors_egypt/resources/views/layouts/footer.blade.php ENDPATH**/ ?>