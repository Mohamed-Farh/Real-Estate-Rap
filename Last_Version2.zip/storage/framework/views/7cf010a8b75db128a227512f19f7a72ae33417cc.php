<!-- jquery -->
<script src="<?php echo e(URL::asset('assets/js/jquery-3.3.1.min.js')); ?>"></script>
<!-- plugins-jquery -->
<script src="<?php echo e(URL::asset('assets/js/plugins-jquery.js')); ?>"></script>
<!-- plugin_path -->
<script type="text/javascript">var plugin_path = '<?php echo e(asset('assets/js')); ?>/';</script>

<!-- chart -->
<script src="<?php echo e(URL::asset('assets/js/chart-init.js')); ?>"></script>
<!-- calendar -->
<script src="<?php echo e(URL::asset('assets/js/calendar.init.js')); ?>"></script>
<!-- charts sparkline -->
<script src="<?php echo e(URL::asset('assets/js/sparkline.init.js')); ?>"></script>
<!-- charts morris -->
<script src="<?php echo e(URL::asset('assets/js/morris.init.js')); ?>"></script>
<!-- datepicker -->
<script src="<?php echo e(URL::asset('assets/js/datepicker.js')); ?>"></script>
<!-- sweetalert2 -->
<script src="<?php echo e(URL::asset('assets/js/sweetalert2.js')); ?>"></script>
<!-- toastr -->
<?php echo $__env->yieldContent('js'); ?>
<script src="<?php echo e(URL::asset('assets/js/toastr.js')); ?>"></script>
<!-- validation -->
<script src="<?php echo e(URL::asset('assets/js/validation.js')); ?>"></script>
<!-- lobilist -->
<script src="<?php echo e(URL::asset('assets/js/lobilist.js')); ?>"></script>
<!-- JavaScript Bundle with Popper -->

<!-- custom -->
<script src="<?php echo e(URL::asset('assets/js/custom.js')); ?>"></script>

<script src="<?php echo e(asset('vendor/bootstrap-fileinput/js/plugins/piexif.min.js')); ?>"></script>
<script src="<?php echo e(asset('vendor/bootstrap-fileinput/js/plugins/sortable.min.js')); ?>"></script>
<script src="<?php echo e(asset('vendor/bootstrap-fileinput/js/plugins/purify.min.js')); ?>"></script>

<script src="<?php echo e(asset('vendor/bootstrap-fileinput/js/fileinput.min.js')); ?>"></script>
<script src="<?php echo e(asset('vendor/bootstrap-fileinput/themes/fas/theme.min.js')); ?>"></script>
<script src="<?php echo e(asset('vendor/summernote/summernote-bs4.min.js')); ?>"></script>


<script>
    $(document).ready(function() {
        $('#datatable').DataTable();
    } );
</script>



<?php if(App::getLocale() == 'en'): ?>
    <script src="<?php echo e(URL::asset('assets/js/bootstrap-datatables/en/jquery.dataTables.min.js')); ?>"></script>
    <script src="<?php echo e(URL::asset('assets/js/bootstrap-datatables/en/dataTables.bootstrap4.min.js')); ?>"></script>
<?php else: ?>
    <script src="<?php echo e(URL::asset('assets/js/bootstrap-datatables/ar/jquery.dataTables.min.js')); ?>"></script>
    <script src="<?php echo e(URL::asset('assets/js/bootstrap-datatables/ar/dataTables.bootstrap4.min.js')); ?>"></script>
<?php endif; ?>



<script>
    function CheckAll(className, elem) {
        var elements = document.getElementsByClassName(className);
        var l = elements.length;

        if (elem.checked) {
            for (var i = 0; i < l; i++) {
                elements[i].checked = true;
            }
        } else {
            for (var i = 0; i < l; i++) {
                elements[i].checked = false;
            }
        }
    }
</script>

<?php /**PATH C:\Users\4FARH\OneDrive\Desktop\World\resources\views/layouts/footer-scripts.blade.php ENDPATH**/ ?>