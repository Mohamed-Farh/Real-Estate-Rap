<?php $__env->startSection('css'); ?>
    <?php echo toastr_css(); ?>
<?php $__env->startSection('title'); ?>
    <?php echo e(trans('property_trans.title_page')); ?>

<?php $__env->stopSection(); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('page-header'); ?>
<!-- breadcrumb -->
<?php $__env->startSection('PageTitle'); ?>
    <?php echo e(trans('main_trans.Property')); ?>

<?php $__env->stopSection(); ?>
<!-- breadcrumb -->
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

<?php
        $category_ar = App\Models\Category::orderBy('id', 'desc')->pluck('name_ar', 'id');
        $category_en = App\Models\Category::orderBy('id', 'desc')->pluck('name_en', 'id');

        $feature_ar = App\Models\Feature::orderBy('id', 'desc')->pluck('name_ar', 'id');
        $feature_en = App\Models\Feature::orderBy('id', 'desc')->pluck('name_en', 'id');
?>
<!-- row -->
<div class="row">
    <?php if($errors->any()): ?>
        <div class="error"><?php echo e($errors->first('Name')); ?></div>
    <?php endif; ?>

    <div class="col-xl-12 mb-30">
        <div class="card card-statistics h-100">
            <div class="card-body">

                <?php if($errors->any()): ?>
                    <div class="alert alert-danger">
                        <ul>
                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li><?php echo e($error); ?></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </div>
                <?php endif; ?>

                <button type="button" class="button x-small back_property">
                    <a href="<?php echo e(route('properties.index')); ?>"><?php echo e(trans('property_trans.return')); ?></a>
                </button>
                <br><br>

                <div class="card-body">

                    <?php echo Form::open(['route' => ['properties.update', $property->id], 'method' => 'patch', 'files' => true]); ?>

                    
                    <div class="row beauty_top">
                        <h2 class="help"><?php echo e(trans('property_trans.title')); ?></h2>
                        <div class="col-12">
                            <div class="form-group">
                                <?php echo Form::label('title_ar', trans('property_trans.title_ar') ); ?>

                                <?php echo Form::text('title_ar', old('title', $property->title_ar ), ['class' => 'form-control']); ?>

                                <?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><span class="text-danger"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                        <div class="col-12">
                            <div class="form-group">
                                <?php echo Form::label('title_en', trans('property_trans.title_en')); ?>

                                <?php echo Form::text('title_en', old('title', $property->title_en ), ['class' => 'form-control']); ?>

                                <?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><span class="text-danger"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                        <br><br><br><br>
                        <div class="col-12">
                            <?php echo Form::label('photo', trans('property_trans.photo'),['class' => 'control-label']); ?>

                            <?php echo Form::file('photo', ['class' => 'form-control'] ); ?>

                        </div>
                    </div>
                    
                    <div class="row beauty">
                        <h2 class="help"><?php echo e(trans('property_trans.Price')); ?></h2>
                        <div class="col">
                            <div class="form-group">
                                <?php echo Form::label('price', trans('property_trans.price') ); ?>

                                <?php echo Form::number('price', old('price', $property->price ), ['class' => 'form-control']); ?>

                                <?php $__errorArgs = ['price'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><span class="text-danger"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                        <div class="col">
                            <div class="form-group">
                                <?php echo Form::label('size', trans('property_trans.size') ); ?>

                                <?php echo Form::number('size', old('size', $property->size ), ['class' => 'form-control'] ); ?>

                                <?php $__errorArgs = ['size'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><span class="text-danger"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                        <div class="col">
                            <div class="form-group">
                                <?php echo Form::label('discount', trans('property_trans.discount') ); ?>

                                <?php echo Form::number('discount', old('discount', $property->discount ), ['class' => 'form-control'], ['min'=>5,'max'=>90]); ?>

                                <?php $__errorArgs = ['discount'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><span class="text-danger"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                        <div class="col">
                            <div class="form-group">
                                <?php echo Form::label('new_price', trans('property_trans.new_price') ); ?>

                                <?php echo Form::number('new_price', old('new_price', $property->new_price ), ['class' => 'form-control']); ?>

                                <?php $__errorArgs = ['new_price'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><span class="text-danger"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                    </div>

                    
                    <div class="row beauty">
                        <h2 class="help"><?php echo e(trans('main_trans.Property')); ?></h2>
                            <div class="col-3">
                            <div class="form-group">
                                <?php echo Form::label('floornumber', trans('property_trans.floornumber') ); ?>

                                <?php echo Form::number('floornumber', old('floornumber', $property->floornumber ), ['class' => 'form-control']); ?>

                                <?php $__errorArgs = ['floornumber'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><span class="text-danger"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                        <div class="col-3">
                            <div class="form-group">
                                <?php echo Form::label('bedroom', trans('property_trans.bedroom') ); ?>

                                <?php echo Form::number('bedroom', old('bedroom', $property->bedroom ), ['class' => 'form-control']); ?>

                                <?php $__errorArgs = ['bedroom'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><span class="text-danger"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                        <div class="col-3">
                            <div class="form-group">
                                <?php echo Form::label('bathroom', trans('property_trans.bathroom') ); ?>

                                <?php echo Form::number('bathroom', old('bathroom', $property->bathroom ), ['class' => 'form-control']); ?>

                                <?php $__errorArgs = ['bathroom'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><span class="text-danger"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                        <div class="col-3">
                            <div class="form-group">
                                <?php echo Form::label('no_of_floor', trans('property_trans.no_of_floor') ); ?>

                                <?php echo Form::number('no_of_floor', old('no_of_floor', $property->no_of_floor ), ['class' => 'form-control']); ?>

                                <?php $__errorArgs = ['no_of_floor'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><span class="text-danger"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                        <div class="col-6 small_space">
                            <?php echo Form::label('purpose', trans('property_trans.purpose') ); ?>

                            <?php echo Form::select('purpose', ['' =>trans('property_trans.-- Please Select --'), 'sale' => trans('property_trans.sale'), 'rent' => trans('property_trans.rent')], old('purpose', $property->purpose ), ['class' => 'form-control choose']); ?>

                            <?php $__errorArgs = ['purpose'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><span class="text-danger"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="col-6 small_space">
                            <?php echo Form::label('used', trans('property_trans.used') ); ?>

                            <?php echo Form::select('used', ['' =>trans('property_trans.-- Please Select --'), 'new' => trans('property_trans.new'), 'used' => trans('property_trans.used')], old('purpose', $property->used), ['class' => 'form-control choose']); ?>

                            <?php $__errorArgs = ['used'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><span class="text-danger"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="col-6 small_space">
                            <?php echo Form::label('category_id', trans('property_trans.category_id') ); ?>

                            <?php if(App::getLocale() == 'en'): ?>
                                <?php if($category_en !=''): ?>
                                        <?php echo Form::select('category_id', ['' => '---'] + $category_en->toArray(), old('category_id', $property->category_id ), ['class' => 'form-control choose']); ?>

                                <?php else: ?>
                                        <?php echo Form::select('category_id', ['' => '---'] + $category_ar->toArray(), old('category_id', $property->category_id ), ['class' => 'form-control choose']); ?>

                                <?php endif; ?>
                            <?php else: ?>
                                <?php if($category_ar !=''): ?>
                                    <?php echo Form::select('category_id', ['' => '---'] + $category_ar->toArray(), old('category_id', $property->category_id ), ['class' => 'form-control choose']); ?>

                                <?php else: ?>
                                    <?php echo Form::select('category_id', ['' => '---'] + $category_en->toArray(), old('category_id', $property->category_id ), ['class' => 'form-control choose']); ?>

                                <?php endif; ?>
                            <?php endif; ?>
                            <?php $__errorArgs = ['category_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><span class="text-danger"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="col-6 small_space">
                            <?php echo Form::label('status', trans('property_trans.status') ); ?>

                            <?php echo Form::select('status', ['' =>trans('property_trans.-- Please Select --'), 'for_sale' => trans('property_trans.for_sale'), 'sold' => trans('property_trans.sold')], old('status', $property->status ), ['class' => 'form-control choose']); ?>

                            <?php $__errorArgs = ['status'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><span class="text-danger"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>


                        <div class="col-6 small_space">
                            <?php echo Form::label('feature_id', trans('feature_trans.feature_id') ); ?>

                            <?php $features = \App\Models\Feature::get(); ?>
                            <?php $__currentLoopData = $features; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $feature_id): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="col">
                                    <?php if(App::getLocale() == 'en'): ?>
                                        <?php if($category_en !=''): ?>
                                            <?php echo Form::checkbox('feature_id[]', $feature_id->id, in_array($feature_id->id, $checkfeatures)?'checked':''  ); ?>

                                            <?php echo Form::label('feature_id', $feature_id->name_en); ?>

                                        <?php else: ?>
                                            <?php echo Form::checkbox('feature_id[]', $feature_id->id, in_array($feature_id->id, $checkfeatures)?'checked':'' ); ?>

                                            <?php echo Form::label('feature_id', $feature_id->name_ar); ?>

                                        <?php endif; ?>
                                    <?php else: ?>
                                        <?php if($category_ar !=''): ?>
                                            <?php echo Form::checkbox('feature_id[]', $feature_id->id, in_array($feature_id->id, $checkfeatures)?'checked':'' ); ?>

                                            <?php echo Form::label('feature_id', $feature_id->name_ar); ?>

                                        <?php else: ?>
                                            <?php echo Form::checkbox('feature_id[]', $feature_id->id, in_array($feature_id->id, $checkfeatures)?'checked':''  ); ?>

                                            <?php echo Form::label('feature_id', $feature_id->name_en); ?>

                                        <?php endif; ?>
                                    <?php endif; ?>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php $__errorArgs = ['feature_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><span class="text-danger"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>



                        
                    </div>


                    
                    <div class="row  beauty1">
                        <h2 class="help"><?php echo e(trans('property_trans.Location')); ?></h2>
                        <div class="col-6">
                            <div class="form-group">
                                <?php echo Form::label('city_ar', trans('property_trans.city_ar') ); ?>

                                <?php echo Form::text('city_ar', old('city_ar', $property->city_ar ), ['class' => 'form-control']); ?>

                                <?php $__errorArgs = ['city_ar'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><span class="text-danger"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                        <div class="col-6">
                            <div class="form-group">
                                <?php echo Form::label('city_en', trans('property_trans.city_en') ); ?>

                                <?php echo Form::text('city_en', old('city_en', $property->city_en ), ['class' => 'form-control']); ?>

                                <?php $__errorArgs = ['city_en'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><span class="text-danger"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                        <div class="col">
                            <div class="form-group">
                                <?php echo Form::label('address_ar', trans('property_trans.address_ar') ); ?>

                                <?php echo Form::text('address_ar', old('address_ar', $property->address_ar ), ['class' => 'form-control']); ?>

                                <?php $__errorArgs = ['address_ar'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><span class="text-danger"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                        <div class="col">
                            <div class="form-group">
                                <?php echo Form::label('address_en', trans('property_trans.address_en') ); ?>

                                <?php echo Form::text('address_en', old('address_en', $property->address_en ), ['class' => 'form-control']); ?>

                                <?php $__errorArgs = ['address_en'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><span class="text-danger"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                    </div>
                    <div class="row beauty1">
                        <div class="col">
                            <div class="form-group">
                                <?php echo Form::label('location_latitude', trans('property_trans.location_latitude') ); ?>

                                <?php echo Form::text('location_latitude', old('location_latitude', $property->location_latitude ), ['class' => 'form-control']); ?>

                                <?php $__errorArgs = ['location_latitude'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><span class="text-danger"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                        <div class="col">
                            <div class="form-group">
                                <?php echo Form::label('location_longitude', trans('property_trans.location_longitude') ); ?>

                                <?php echo Form::text('location_longitude', old('location_longitude', $property->location_longitude ), ['class' => 'form-control']); ?>

                                <?php $__errorArgs = ['location_longitude'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><span class="text-danger"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                    </div>
                    <div class="row beauty">
                        <div class="col-12">
                            <div class="form-group">
                                <?php echo Form::label('nearby_en', trans('property_trans.nearby_ar') ); ?>

                                <?php echo Form::textarea('nearby_en', old('nearby_en', $property->nearby_en ), ['class' => 'form-control summernote']); ?>

                                <?php $__errorArgs = ['nearby_en'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><span class="text-danger"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                        <div class="col-12">
                            <div class="form-group">
                                <?php echo Form::label('nearby_ar', trans('property_trans.nearby_en') ); ?>

                                <?php echo Form::textarea('nearby_ar', old('nearby_ar', $property->nearby_ar ), ['class' => 'form-control summernote']); ?>

                                <?php $__errorArgs = ['nearby_ar'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><span class="text-danger"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                    </div>
                    <div class="row beauty">
                        <div class="col-12">
                            <div class="form-group">
                                <?php echo Form::label('description_en', trans('property_trans.description_en') ); ?>

                                <?php echo Form::textarea('description_en', old('description_en', $property->description_en ), ['class' => 'form-control summernote']); ?>

                                <?php $__errorArgs = ['description_ar'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><span class="text-danger"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                        <div class="col-12">
                            <div class="form-group">
                                <?php echo Form::label('description_ar', trans('property_trans.description_ar') ); ?>

                                <?php echo Form::textarea('description_ar', old('description_ar', $property->description_ar ), ['class' => 'form-control summernote']); ?>

                                <?php $__errorArgs = ['description_ar'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><span class="text-danger"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                    </div>

                    
                    <div class="row beauty">
                        <h2 class="help"><?php echo e(trans('property_trans.video')); ?></h2>
                        <div class="col">
                            <div class="form-group">
                                <?php echo Form::label('video', trans('property_trans.video') ); ?>

                                <?php echo Form::text('video', old('video', $property->video ), ['class' => 'form-control']); ?>

                                <?php $__errorArgs = ['video'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><span class="text-danger"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                    </div>

                    <div class="row pt-4">
                        <div class="col-12">
                            <?php echo Form::label('Sliders', trans('property_trans.images') ); ?>

                            <br>
                            <div class="file-loading">
                                <?php echo Form::file('images[]', ['id' => 'post-images', 'class' => 'file-input-overview', 'multiple' => 'multiple']  ,array('multiple'=>true)); ?>

                                <span class="form-text text-muted">Image width should be 800px x 500px</span>
                                <?php $__errorArgs = ['images'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><span class="text-danger"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                    </div>

                    <div class="form-group pt-4">
                        <?php echo Form::submit( trans('property_trans.submit') , ['class' => 'btn btn-primary']); ?>

                    </div>
                    <?php echo Form::close(); ?>

                </div>
            </div>
        </div>
    </div>

</div>

<!-- row closed -->
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
<?php echo toastr_js(); ?>
<?php echo app('toastr')->render(); ?>
    <script>
        $(function () {
            $('#post-images').fileinput({
                theme: "fas",
                maxFileCount: 10 ,
                allowedFileTypes: ['image'],
                showCancel: true,
                showRemove: false,
                showUpload: false,
                overwriteInitial: false,
                initialPreview: [
                    <?php if( $property->images != ''): ?>
                        <?php $__currentLoopData = explode('|',$property->images); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            "<?php echo e(asset('image/' . $image)); ?>",
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
                ],
                initialPreviewAsData: true,
                initialPreviewFileType: 'image',
                initialPreviewConfig: [
                    <?php if( $property->images != ''): ?>
                        <?php $__currentLoopData = explode('|',$property->images); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            {caption: "<?php echo e($image); ?>", url: "<?php echo e(route('removeImage', [$image, '_token' => csrf_token()])); ?>", key: "<?php echo e($image); ?>,<?php echo e($property->id); ?>"},
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
                ],

            });

        });
    </script>
     <script type="text/javascript">
        $(document).ready(function() {
          $('.summernote').summernote({
                tabSize: 2,
                height: 200,
            });
        });
    </script>
<?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\4FARH\OneDrive\Desktop\World\resources\views/pages/admin/properties/edit.blade.php ENDPATH**/ ?>