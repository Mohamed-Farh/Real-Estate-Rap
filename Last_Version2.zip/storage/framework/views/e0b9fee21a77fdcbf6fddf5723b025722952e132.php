        <!--start firstbar-->
        <div class="firstbar  text-center ">
            <div class="container">
                <div class="row py-2">
                    <div class="col-xs-12 col-sm-12 col-md-3 col-lg-3 fbar">
                        <p><i class="fas fa-map-marker-alt"></i><?php echo e(trans('front_trans.raptors_location')); ?></p>
                    </div>



                    <?php $whatsapps = \App\Models\Social::where('type', 'What\'s App')->get(); ?>
                    <div class="col-xs-12 col-sm-12 col-md-2 col-lg-2 fbar">
                        <?php $__currentLoopData = $whatsapps; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $whatsapp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($whatsapp->status == '1'): ?>
                                <a href="https://api.whatsapp.com/send?phone=<?php echo e($whatsapp->name); ?>"
                                    class="btn-floating btn-large fixed_mainbut"><i class="fab fa-whatsapp"></i>
                                    <?php echo e($whatsapp->name); ?></a> <br>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>

                    

                    <div class="col-xs-12 col-sm-12 col-md-5 col-lg-5 fbar">
                        <div class="row">
                            <div class="col">
                                <a href="/job_seeker"><?php echo e(trans('front_trans.jobs')); ?></a>
                            </div>
                            <div class="col">
                                <?php $customers = \App\Models\Social::where('type', 'Customers Service')->get();
                                ?>
                                <?php $__currentLoopData = $customers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $customer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if($customer->status == '1'): ?>
                                        <p><i class="fas fa-phone"></i><?php echo e($customer->name); ?></p>
                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                            <div class="col">
                                <a class="nav-link link-pages dropdown-toggle link-page" href="#" id="navbarDropdown"
                                    role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"
                                    style="padding-top: 0px;">
                                    <?php if(App::getLocale() == 'ar'): ?>
                                        <?php echo e(LaravelLocalization::getCurrentLocaleName()); ?>

                                        <img src="<?php echo e(URL::asset('assets/images/flags/EG.png')); ?>" alt="">
                                    <?php else: ?>
                                        <?php echo e(LaravelLocalization::getCurrentLocaleName()); ?>

                                        <img src="<?php echo e(URL::asset('assets/images/flags/US.png')); ?>" alt="">
                                    <?php endif; ?>
                                </a>
                                <div class="dropdown-menu" aria-labelledby="navbarDropdown">
                                    <?php $__currentLoopData = LaravelLocalization::getSupportedLocales(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $localeCode => $properties): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <a class="dropdown-item" rel="alternate" hreflang="<?php echo e($localeCode); ?>"
                                            href="<?php echo e(LaravelLocalization::getLocalizedURL($localeCode, null, [], true)); ?>"
                                            style="color:black !important; ">
                                            <?php echo e($properties['native']); ?>

                                        </a>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>
                            </div>
                        </div>
                    </div>

                    <?php if(auth()->guard()->guest()): ?>
                        <div class="col-xs-12 col-sm-12 col-md-2 col-lg-2">
                            <a href='#' data-toggle="modal" data-target="#sign_in" style="color: orange">
                                <p><?php echo e(trans('front_trans.Sign In')); ?></p>
                            </a>
                        </div>
                    <?php endif; ?>
                    <?php if(auth()->guard()->check()): ?>
                        <div class="col-xs-12 col-sm-12 col-md-2 col-lg-2">
                            
                            <a href="<?php echo e(route('logout')); ?>"
                                onclick="event.preventDefault();document.getElementById('logout-form').submit();"><i
                                    class="text-danger ti-unlock"></i><?php echo e(trans('front_trans.logout')); ?></a>
                            <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                                <?php echo csrf_field(); ?>
                            </form>

                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>

        <!--end firstbar-->



        <!--start navbar-->
        <div class="header">

            <div class="header-bar">
                <nav class="navbar navbar-expand-lg navbar-light bg-light make_right_ar">
                    <a class="navbar-brand" href="/home"><img src="<?php echo e(asset('app-assets/images/logo.png')); ?>"></a>
                    <button class="navbar-toggler" type="button" data-toggle="collapse"
                        data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent"
                        aria-expanded="false" aria-label="Toggle navigation">
                        <span class="navbar-toggler-icon"></span>
                    </button>

                    <div class="collapse navbar-collapse headernav" id="navbarSupportedContent">
                        <ul class="navbar-nav">
                            <li class="nav-item active">
                                <a class="nav-link link-pages  current-page-active link-page"
                                    href="/home"><?php echo e(trans('front_trans.home')); ?>

                                    <span class="sr-only">(current)</span></a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link link-pages link-page"
                                    href="<?php echo e(route('front/aboutus')); ?>"><?php echo e(trans('front_trans.aboutus')); ?></a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link link-pages link-page"
                                    href="<?php echo e(route('all_properties')); ?>"><?php echo e(trans('front_trans.all_properties')); ?></a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link link-pages link-page"
                                    href="<?php echo e(route('available_projects')); ?>"><?php echo e(trans('front_trans.Available projects')); ?></a>
                            </li>

                            <li class="nav-item">
                                <a class="nav-link link-pages link-page"
                                    href="<?php echo e(route('news')); ?>"><?php echo e(trans('front_trans.last_news')); ?></a>
                            </li>

                            <li class="nav-item">
                                <a class="nav-link link-pages link-page"
                                    href="/home/gallery"><?php echo e(trans('front_trans.media')); ?></a>
                            </li>


                            <li class="nav-item">
                                <a class="nav-link link-pages link-page"
                                    href="<?php echo e(route('previous_projects')); ?>"><?php echo e(trans('front_trans.previous_projects')); ?></a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link link-pages link-page"
                                    href="<?php echo e(route('front/contactus')); ?>"><?php echo e(trans('front_trans.contactus')); ?></a>
                            </li>
                            <li class="nav-item searchicon">
                                <a class="nav-link link-pages iconsearch "
                                    href="/search_page"><?php echo e(trans('front_trans.property_search')); ?></a>
                            </li>
                        </ul>
                    </div>
                </nav>
            </div>
        </div>


        <?php if(auth()->guard()->guest()): ?>
            <a href="#" class="portf-btn fixed_action_btn_3" data-toggle="modal" data-target="#exampleModal">
                <p><?php echo e(trans('front_trans.Register Now')); ?></p>
            </a>
        <?php endif; ?>



        <?php   $whatsapps   = \App\Models\Social::where('type', 'What\'s App')->get();   ?>
        <?php $__currentLoopData = $whatsapps; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $whatsapp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <a href="https://api.whatsapp.com/send?phone=<?php echo e($whatsapp->name); ?>" class="btn-floating btn-large fixed_mainbut"><i class="fab fa-whatsapp whats "></i></a>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <!--end navbar-->



        <!-- User Registeration -->
        <div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
            aria-hidden="true">
            <div class="modal-dialog" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <div class="modal-body">
                        <!-- add_form -->
                        <form action="<?php echo e(route('sign_in')); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <h5 style="font-family: 'Cairo', sans-serif;" class="modal-title  make_right_ar" id="exampleModalLabel" >
                                <?php echo e(trans('front_trans.Register Now')); ?>

                            </h5>
                            <div class="row">
                                <div class="col-md-12 make-space">
                                    <input id="name" type="text" name="name" class="form-control" style=" height: calc(1.5em + 1.75rem + 2px); margin-top: 25px;"
                                        value="<?php echo e(old('name')); ?>" required autocomplete="name" autofocus placeholder="<?php echo e(trans('admins_trans.name')); ?>">
                                </div>

                                <div class="col-md-12 make-space">
                                    <input id="name_ar" type="text" name="name_ar" class="form-control" style=" height: calc(1.5em + 1.75rem + 2px); margin-top: 25px;"
                                        value="<?php echo e(old('name')); ?>" autocomplete="name" autofocus placeholder="<?php echo e(trans('admins_trans.name_ar')); ?>">
                                </div>

                                <div class="col-md-12 make-space">
                                    <input type="email" class="form-control" name="email" value="<?php echo e(old('email')); ?>"  style=" height: calc(1.5em + 1.75rem + 2px); margin-top: 25px;"
                                        required autocomplete="email"  placeholder="<?php echo e(trans('admins_trans.email')); ?>">
                                </div>

                                <div class="col-md-12 make-space">
                                    <input type="password" class="form-control" name="password" required style=" height: calc(1.5em + 1.75rem + 2px); margin-top: 25px;"
                                        autocomplete="new-password"  placeholder="<?php echo e(trans('admins_trans.password')); ?>">
                                </div>

                                <div class="col-md-12 make-space">
                                    <input type="password" name="password_confirmation" id="input-password-confirmation"  style=" height: calc(1.5em + 1.75rem + 2px); margin-top: 25px;"
                                        class="form-control" required  placeholder="<?php echo e(trans('admins_trans.confirm_password')); ?>">
                                </div>
                                <br><br>
                            </div>
                                <button type="submit" class="text-center" style="margin-left: 170px;padding: 10px 40px;margin-top: 33px;color: white;background-color: orange;border-style: none;">
                                    <?php echo e(trans('front_trans.Register')); ?></button>
                        </form>
                    </div>
                </div>
            </div>
        </div>



        <!-- User Sign In -->
        <div class="modal fade" id="sign_in" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
            aria-hidden="true">
            <div class="modal-dialog" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <div class="modal-body">
                        <!-- add_form -->
                        <form method="POST" action="<?php echo e(route('login')); ?>">
                            <?php echo csrf_field(); ?>
                            <h5 style="font-family: 'Cairo', sans-serif; margin-top=50px" class="modal-title make_right_ar" id="exampleModalLabel" >
                                <?php echo e(trans('front_trans.Sign In')); ?>

                            </h5>
                            <div class="col-md-12 make-space">
                                <input id="email" type="email"
                                    class="form-control <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="email" placeholder="<?php echo e(trans('contactus_trans.email')); ?>"
                                    value="<?php echo e(old('email')); ?>" required autocomplete="email" autofocus style=" height: calc(1.5em + 1.75rem + 2px); margin-top: 25px;">
                                <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                            <div class="col-md-12 make-space">
                                <input id="password" type="password"
                                    class="form-control <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="password" placeholder="<?php echo e(trans('contactus_trans.password')); ?>"
                                    required autocomplete="current-password" style=" height: calc(1.5em + 1.75rem + 2px); margin-top: 25px;">
                                <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <button type="submit" class="text-center" style="margin-left: 170px;padding: 10px 40px;margin-top: 33px;color: white;background-color: orange;border-style: none;">
                                <?php echo e(trans('front_trans.Sign In')); ?>

                            </button>
                        </form>
                    </div>
                </div>
            </div>
        </div>

<?php /**PATH C:\Users\4FARH\OneDrive\Desktop\(M-F) Real Estate\resources\views/layouts/partials/nav.blade.php ENDPATH**/ ?>