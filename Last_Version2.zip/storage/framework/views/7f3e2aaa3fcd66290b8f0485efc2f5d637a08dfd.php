<!DOCTYPE html>
<html lang="zxx" class="no-js">

<head>
    <?php echo $__env->make('layouts.partials.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</head>

<body>
    <?php echo $__env->make('layouts.partials.nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="row">
        <div class="col-12">
            <?php echo $__env->make('layouts.partials.flash', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
    </div>


    <!--start title-->
    <div class="title-nav py-4 make_right_ar">
        <div class="container">
            <h2><?php echo e(trans('main_trans.Main_title')); ?></h2>
        </div>
    </div>
    <!--end title-->
    <!--start lines-->
    <div class="line">
        <div class="line2 line-2-about line-3-search line-4-images">
        </div>
    </div>
    <!--end lines-->



    <!--start card section-->
    <div class="cards-section latest-news-cards py-4">
        <div class="container">
            <div class="row text-center py-4">

                <?php $__currentLoopData = $all_properties; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $all_property): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-xs-12 col-sm-12 col-md-4 col-lg-4" style="width: ">
                        <div class="card news-cards cards-right-side">
                            <div class="ui-card latest-ui-card">
                                    <?php if($all_property->photo): ?>
                                        <img src="<?php echo e(url('image/photo/'.$all_property->photo)); ?>" style="width: 100%;height: 310px !important;">
                                        <div class="description text-center" style="    bottom: 45%;">
                                            <a href="/show_properties/<?php echo e($all_property->title_en); ?>"><i class="fas fa-link"></i></a>
                                         </div>
                                         
                                    <?php else: ?>
                                        <img src="<?php echo e(url('image/photo/default.jpg')); ?>" style="width: 100%;height: 310px !important;">
                                        <div class="description text-center">
                                            <a href="/show_properties/<?php echo e($all_property->title_en); ?>"><i class="fas fa-link"></i></a>
                                         </div>
                                         <a href="/show_properties/<?php echo e($all_property->title_en); ?>"><i class="fas fa-link"></i></a>
                                    <?php endif; ?>
                            </div>
                            <div class="card-body card-text1">
                                <p class="calendar"><i class="fas fa-calendar-week"></i> <?php echo e($all_property->created_at->diffForHumans()); ?></p>
                                <h5 class="card-title">
                                    <?php if(App::getLocale() == 'en'): ?>
                                        <?php if($all_property->title_en !=''): ?>
                                            <?php echo e(\Str::limit($all_property->title_en, 25)); ?>

                                        <?php else: ?>
                                            <?php echo e(\Str::limit($all_property->title_ar, 25)); ?>

                                        <?php endif; ?>
                                    <?php else: ?>
                                        <?php echo e(\Str::limit($all_property->title_ar, 25)); ?>

                                    <?php endif; ?>
                                </h5>
                                <p class="card-text">
                                    <?php if(App::getLocale() == 'en'): ?>
                                        <?php if($all_property->description_en !=''): ?>
                                            <td><?php echo e(\Str::limit($all_property->description_en, 280)); ?></td>
                                        <?php else: ?>
                                            <td><?php echo e(\Str::limit($all_property->description_ar, 280)); ?></td>
                                        <?php endif; ?>
                                    <?php else: ?>
                                        <?php if($all_property->description_ar !=''): ?>
                                            <td><?php echo e(\Str::limit($all_property->description_ar, 280)); ?></td>
                                        <?php else: ?>
                                            <td><?php echo e(\Str::limit($all_property->description_en, 280)); ?></td>
                                        <?php endif; ?>
                                    <?php endif; ?>
                                </p>
                                <a href="/show_properties/<?php echo e($all_property->title_en); ?>" class="btn btn-primary"><?php echo e(trans('front_trans.show_details')); ?></a>
                            </div>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
        <div class="m-t-30 m-b-60 center" style="margin-right: 50%;">
            <?php echo e($all_properties->links()); ?>

        </div>

    </div>
    <!--end card section-->









    <?php echo $__env->make('layouts.partials.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('layouts.partials.footer-scripts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

</body>

</html>
<?php /**PATH C:\Users\4FARH\OneDrive\Desktop\(M-F) Real Estate\resources\views/includes/sitepages/all_properties.blade.php ENDPATH**/ ?>