<!DOCTYPE html>

<html lang="en">

 	<head>

   		<?php echo $__env->make('layouts.partials.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

 	</head>


 	<body>

		<?php echo $__env->make('layouts.partials.nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

            <div class="row">
                <div class="col-12">
                    <?php echo $__env->make('layouts.partials.flash', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                </div>
            </div>



		<?php echo $__env->yieldContent('content'); ?>

		<?php echo $__env->make('layouts.partials.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

		<?php echo $__env->make('layouts.partials.footer-scripts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

 	</body>


</html>
<?php /**PATH C:\Users\4FARH\OneDrive\Desktop\World\resources\views/layouts/mainlayout.blade.php ENDPATH**/ ?>