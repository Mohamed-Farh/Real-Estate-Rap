<!DOCTYPE html>
<html lang="zxx" class="no-js">

<head>
    <?php echo $__env->make('layouts.partials.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</head>

<body>
    <?php echo $__env->make('layouts.partials.nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="row">
        <div class="col-12">
            <?php echo $__env->make('layouts.partials.flash', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
    </div>

    <?php
        $sliders = \App\Models\Gallery::where('type', 1)->get();
    ?>

    <!--start title-->
    <div class="title-nav py-4 make_right_ar">
        <div class="container">
            <h2><?php echo e(trans('front_trans.aboutus')); ?></h2>
        </div>
    </div>
    <!--end title-->
    <!--start lines-->
    <div class="line">
        <div class="line2 line-2-about">
        </div>
    </div>
    <!--end lines-->


    <?php $__currentLoopData = $about_us; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $aboutus): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

    <!--start about us section-->
    <div class="about-us-section py-4">
        <div class="container">
            <div class="row ">
                <div class="col-xs-12 col-sm-12 col-md-8 col-lg-8 make_right_ar">
                    <h2><?php echo e(trans('main_trans.Main_title')); ?></h2>
                    <p>
                        <?php if(App::getLocale() == 'en'): ?>
                            <?php if($aboutus->aboutus_en != ''): ?>
                                <td><?php echo e($aboutus->aboutus_en); ?></td>
                            <?php else: ?>
                                <td><?php echo e($aboutus->aboutus_ar); ?></td>
                            <?php endif; ?>
                        <?php else: ?>
                            <?php if($aboutus->aboutus_ar != ''): ?>
                                <td><?php echo e($aboutus->aboutus_ar); ?></td>
                            <?php else: ?>
                                <td><?php echo e($aboutus->aboutus_en); ?></td>
                            <?php endif; ?>
                        <?php endif; ?>
                    </p>
                </div>
                <div class="col-xs-12 col-sm-12 col-md-4 col-lg-4 py-3">
                    <div class="card prevs-cards about-cards " style="width: 18rem;">
                        <div class="slider-about">
                            <div id="carouselExampleIndicators" class="carousel slide" data-ride="carousel">
                                <ol class="carousel-indicators">
                                    <li data-target="#carouselExampleIndicators" data-slide-to="0" class="active"></li>
                                    <li data-target="#carouselExampleIndicators" data-slide-to="1"></li>
                                </ol>
                                <div class="carousel-inner">
                                    <div class="carousel-item active">
                                        
                                        <img src="<?php echo e(asset('app-assets/images/Artboard – 2.png')); ?>" data-aos="zoom-in" class="d-block w-100" style="width: 100%; height:195px;">
                                    </div>
                                    <?php $__currentLoopData = $sliders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $slider): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php if($slider->type == '1'): ?>
                                            <div class="carousel-item">
                                                <img class="d-block w-100" src="<?php echo e(Url($slider->path)); ?>" alt="Second slide" style="width: 100%; height:195px;">
                                            </div>
                                        <?php endif; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>
                                <a class="carousel-control-prev" href="#carouselExampleIndicators" role="button"
                                    data-slide="prev">
                                    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                                    <span class="sr-only">Previous</span>
                                </a>
                                <a class="carousel-control-next" href="#carouselExampleIndicators" role="button"
                                    data-slide="next">
                                    <span class="carousel-control-next-icon" aria-hidden="true"></span>
                                    <span class="sr-only">Next</span>
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!--end about us section-->

    <!--start counter section-->
    <div class="counter-sec py-4 text-center">
        <div class="container">
            <div class="row">
                <div class="col-xs-6 col-sm-6 col-md-3 col-lg-3">
                    <i class="fas fa-clock text-9 text-color-light mb-3 mt-2"></i>
                    <div>
                        <span class="counter"><?php echo e($aboutus->experience_year); ?></span>
                    </div>
                    <div>
                        <p><?php echo e(trans('front_trans.experience_year')); ?></p>
                    </div>
                </div>
                <div class="col-xs-6 col-sm-6 col-md-3 col-lg-3">
                    <i class="fas fa-home text-9 text-color-light mb-3 mt-2"></i>
                    <div>
                        <span class="counter"><?php echo e($aboutus->previous_project); ?> </span>
                    </div>
                    <div>
                        <p><?php echo e(trans('front_trans.previous_project')); ?></p>

                    </div>

                </div>
                <div class="col-xs-6 col-sm-6 col-md-3 col-lg-3">
                    <i class="fas fas fa-hourglass-half text-9 text-color-light mb-3 mt-2"></i>
                    <div>
                        <span class="counter"><?php echo e($aboutus->under_construction); ?> </span>
                    </div>
                    <div>
                        <p><?php echo e(trans('front_trans.under_construction')); ?></p>
                    </div>
                </div>
                <div class="col-xs-6 col-sm-6 col-md-3 col-lg-3">
                    <i class="fas fa-users text-9 text-color-light mb-3 mt-2"></i>
                    <div>
                        <span class="counter"><?php echo e($aboutus->client); ?> </span>
                    </div>
                    <div>
                        <p><?php echo e(trans('front_trans.client')); ?></p>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!--end counter section-->


    <!--start last section-->
    <div class="last-section">
        <div class="container">
            <div class="row">
                <div class="col-xs-12 col-sm-12 col-md-4 col-lg-4">
                    <div class="card prevs-cards text-center last-card-1" style="width: 18rem;">

                        <div class="card-body  ">
                            <h5 class="card-title "><?php echo e(trans('front_trans.whyus')); ?></h5>
                            <p class="card-text ">
                                <?php if(App::getLocale() == 'en'): ?>
                                    <?php if($aboutus->whyus_en != ''): ?>
                                        <td><?php echo e($aboutus->whyus_en); ?></td>
                                    <?php else: ?>
                                        <td><?php echo e($aboutus->whyus_ar); ?></td>
                                    <?php endif; ?>
                                <?php else: ?>
                                    <?php if($aboutus->whyus_ar != ''): ?>
                                        <td><?php echo e($aboutus->whyus_ar); ?></td>
                                    <?php else: ?>
                                        <td><?php echo e($aboutus->whyus_en); ?></td>
                                    <?php endif; ?>
                                <?php endif; ?>
                            </p>
                        </div>
                    </div>
                </div>
                <div class="col-xs-12 col-sm-12 col-md-4 col-lg-4">
                    <div class="card prevs-cards text-center last-card-1" style="width: 18rem;">

                        <div class="card-body  ">
                            <h5 class="card-title "><?php echo e(trans('front_trans.vision')); ?></h5>
                            <p class="card-text ">
                                <?php if(App::getLocale() == 'en'): ?>
                                    <?php if($aboutus->vision_en != ''): ?>
                                        <td><?php echo e($aboutus->vision_en); ?></td>
                                    <?php else: ?>
                                        <td><?php echo e($aboutus->vision_ar); ?></td>
                                    <?php endif; ?>
                                <?php else: ?>
                                    <?php if($aboutus->vision_ar != ''): ?>
                                        <td><?php echo e($aboutus->vision_ar); ?></td>
                                    <?php else: ?>
                                        <td><?php echo e($aboutus->vision_en); ?></td>
                                    <?php endif; ?>
                                <?php endif; ?>
                            </p>
                        </div>
                    </div>

                </div>
                <div class="col-xs-12 col-sm-12 col-md-4 col-lg-4">
                    <div class="card prevs-cards text-center last-card-1" style="width: 18rem;">

                        <div class="card-body  ">
                            <h5 class="card-title "><?php echo e(trans('front_trans.message')); ?></h5>
                            <p class="card-text ">
                                <?php if(App::getLocale() == 'en'): ?>
                                    <?php if($aboutus->message_en != ''): ?>
                                        <td><?php echo e($aboutus->message_en); ?></td>
                                    <?php else: ?>
                                        <td><?php echo e($aboutus->message_ar); ?></td>
                                    <?php endif; ?>
                                <?php else: ?>
                                    <?php if($aboutus->message_ar != ''): ?>
                                        <td><?php echo e($aboutus->message_ar); ?></td>
                                    <?php else: ?>
                                        <td><?php echo e($aboutus->message_en); ?></td>
                                    <?php endif; ?>
                                <?php endif; ?>
                            </p>

                        </div>
                    </div>

                </div>

            </div>

        </div>

    </div>
    <!--end last section-->
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


    <?php echo $__env->make('layouts.partials.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('layouts.partials.footer-scripts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

</body>

</html>
<?php /**PATH /home/dbsc4c7x1fsq/last_v/resources/views/includes/sitepages/aboutus.blade.php ENDPATH**/ ?>