<?php $__env->startSection('css'); ?>
    <?php echo toastr_css(); ?>
<?php $__env->startSection('title'); ?>
    <?php echo e(trans('front_trans.news')); ?>

<?php $__env->stopSection(); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('page-header'); ?>
<!-- breadcrumb -->
<?php $__env->startSection('PageTitle'); ?>
    <?php echo e(trans('front_trans.news')); ?>

<?php $__env->stopSection(); ?>
<!-- breadcrumb -->
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

<!-- row -->
<div class="row">
    <?php if($errors->any()): ?>
        <div class="error"><?php echo e($errors->first('Name')); ?></div>
    <?php endif; ?>

    <div class="col-xl-12 mb-30">
        <div class="card card-statistics h-100">
            <div class="card-body">

                <?php if($errors->any()): ?>
                    <div class="alert alert-danger">
                        <ul>
                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li><?php echo e($error); ?></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </div>
                <?php endif; ?>

                <button type="button" class="button x-small back_property">
                    <a href="<?php echo e(route('news.index')); ?>"><?php echo e(trans('front_trans.return')); ?></a>
                </button>
                <br><br>


                <div class="card-body">

                    <?php echo Form::open(['route' => 'news.store', 'method' => 'post', 'files'=>true ]); ?>

                    
                    <div class="row beauty_top">
                        <h2 class="help"><?php echo e(trans('front_trans.news')); ?></h2>
                        <div class="col-12">
                            <div class="form-group">
                                <?php echo Form::label('head_ar', trans('front_trans.head_ar') ); ?>

                                <?php echo Form::textarea('head_ar', old('head_ar'), ['class' => 'form-control summernote']); ?>

                                <?php $__errorArgs = ['head_ar'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><span class="text-danger"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                        <div class="col-12">
                            <div class="form-group">
                                <?php echo Form::label('head_en', trans('front_trans.head_en') ); ?>

                                <?php echo Form::textarea('head_en', old('head_en'), ['class' => 'form-control summernote']); ?>

                                <?php $__errorArgs = ['head_en'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><span class="text-danger"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                        <br><br><br><br>
                    </div>

                    
                    <div class="row beauty">
                        <h2 class="help"><?php echo e(trans('front_trans.new_body')); ?></h2>
                        <div class="col-12">
                            <div class="form-group">
                                <?php echo Form::label('body_ar', trans('front_trans.body_ar') ); ?>

                                <?php echo Form::textarea('body_ar', old('body_ar'), ['class' => 'form-control summernote']); ?>

                                <?php $__errorArgs = ['body_ar'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><span class="text-danger"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                        <div class="col-12">
                            <div class="form-group">
                                <?php echo Form::label('body_en', trans('front_trans.body_en') ); ?>

                                <?php echo Form::textarea('body_en', old('body_en'), ['class' => 'form-control summernote']); ?>

                                <?php $__errorArgs = ['body_en'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><span class="text-danger"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                    </div>

                    <div class="row beauty">
                        <h2 class="help"><?php echo e(trans('front_trans.photo')); ?></h2>
                        <div class="col-12 small_space ">
                            <?php echo Form::label('photo', trans('property_trans.photo') ); ?>

                            <?php echo e(Form::file('photo', ['class' => 'form-control'] )); ?>

                        </div>
                            <?php $__errorArgs = ['photo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><span class="text-danger"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <div class="form-group pt-4">
                        <?php echo Form::submit( trans('front_trans.submit') , ['class' => 'btn btn-primary']); ?>

                    </div>
                    <?php echo Form::close(); ?>

                </div>
            </div>
        </div>
    </div>

</div>

<!-- row closed -->
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
<?php echo toastr_js(); ?>
<?php echo app('toastr')->render(); ?>
    <script>
        $(function () {
            // $('.summernote').summernote({
            //     tabSize: 2,
            //     height: 200,
            //     toolbar: [
            //         ['style', ['style']],
            //         ['font', ['bold', 'underline', 'clear']],
            //         ['color', ['color']],
            //         ['para', ['ul', 'ol', 'paragraph']],
            //         ['table', ['table']],
            //         ['insert', ['link', 'picture', 'video']],
            //         ['view', ['fullscreen', 'codeview', 'help']]
            //     ]
            // });
            $('#post-images').fileinput({
                theme: "fas",
                maxFileCount: 10,
                allowedFileTypes: ['image'],
                showCancel: true,
                showRemove: false,
                showUpload: false,
                overwriteInitial: false,

            });

        });
    </script>
     <script type="text/javascript">
        $(document).ready(function() {
          $('.summernote').summernote({
                tabSize: 2,
                height: 200,
            });
        });
    </script>
<?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/dbsc4c7x1fsq/last_v/resources/views/pages/admin/news/create.blade.php ENDPATH**/ ?>