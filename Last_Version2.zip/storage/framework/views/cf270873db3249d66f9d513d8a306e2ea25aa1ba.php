<?php $__env->startSection('css'); ?>
    <?php echo toastr_css(); ?>


<?php $__env->startSection('title'); ?>
    <?php echo e(trans('front_trans.work_time')); ?>

<?php $__env->stopSection(); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('page-header'); ?>
<!-- breadcrumb -->
<?php $__env->startSection('PageTitle'); ?>
<?php echo e(trans('front_trans.work_time')); ?>

<?php $__env->stopSection(); ?>
<!-- breadcrumb -->
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<!-- row -->
<div class="row">

<div class="col-xl-12 mb-30">
    <div class="card card-statistics h-100">
        <div class="card-body">

            <?php if($errors->any()): ?>
                <div class="alert alert-danger">
                    <ul>
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><?php echo e($error); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
            <?php endif; ?>

            <?php
                $work_times = \App\Models\Work_Time::all();
            ?>


            <button type="button" class="button x-small" data-toggle="modal" data-target="#exampleModal">
                <?php echo e(trans('front_trans.add')); ?>

            </button>
            <br><br>

            <!--start about us section-->
            <div class="table-responsive">
                <table id="datatable" class="table  table-hover table-sm table-bordered p-0" data-page-length="50"
                    style="text-align: center">
                    <thead>
                        <tr>
                            <th>#</th>
                            <th><?php echo e(trans('front_trans.start_day')); ?></th>
                            <th><?php echo e(trans('front_trans.end_day')); ?></th>
                            <th><?php echo e(trans('front_trans.start_time')); ?></th>
                            <th><?php echo e(trans('front_trans.end_time')); ?></th>
                            <th><?php echo e(trans('feature_trans.Processes')); ?></th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $i = 0; ?>
                            <tr>
                            <?php $__currentLoopData = $work_times; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $work): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php $i++; ?>
                                    <td><?php echo e($i); ?></td>
                                    <td><?php echo e(trans('front_trans.'.$work->start_day )); ?></td>
                                    <td><?php echo e(trans('front_trans.'.$work->end_day )); ?></td>
                                    <td><?php echo e($work->start_time); ?></td>
                                    <td><?php echo e($work->end_time); ?></td>

                                    <td>

                                        <button type="button" class="btn btn-danger btn-sm" data-toggle="modal"
                                        data-target="#delete<?php echo e($work->id); ?>"
                                        title="<?php echo e(trans('social_trans.Delete')); ?>"><i
                                            class="fa fa-trash"></i></button>

                                    </td>
                            </tr>

                            <!-- delete_modal_feature -->
                            <div class="modal fade" id="delete<?php echo e($work->id); ?>" tabindex="-1" role="dialog"
                                aria-labelledby="exampleModalLabel" aria-hidden="true">
                                <div class="modal-dialog" role="document">
                                    <div class="modal-content">
                                        <div class="modal-header">
                                            <h5 style="font-family: 'Cairo', sans-serif;" class="modal-title"
                                                id="exampleModalLabel">
                                                <?php echo e(trans('front_trans.Delete')); ?>

                                            </h5>
                                            <button type="button" class="close" data-dismiss="modal"
                                                aria-label="Close">
                                                <span aria-hidden="true">&times;</span>
                                            </button>
                                        </div>
                                        <div class="modal-body">
                                            <form action="<?php echo e(route('work_time.destroy', 'test')); ?>" method="post">
                                                <?php echo e(method_field('Delete')); ?>

                                                <?php echo csrf_field(); ?>
                                                <?php echo e(trans('social_trans.Warning_social')); ?>

                                                <input id="id" type="hidden" name="id" class="form-control"
                                                    value="<?php echo e($work->id); ?>">
                                                <div class="modal-footer">
                                                    <button type="button" class="btn btn-secondary"
                                                        data-dismiss="modal"><?php echo e(trans('front_trans.Close')); ?></button>
                                                    <button type="submit"
                                                        class="btn btn-danger"><?php echo e(trans('front_trans.Delete')); ?></button>
                                                </div>
                                            </form>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </table>
            </div>
        </div>
    </div>
</div>


<!-- add_modal_feature -->
<div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
    aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content" style="width: 120% !important; ">
            <div class="modal-header">
                <h5 style="font-family: 'Cairo', sans-serif;" class="modal-title" id="exampleModalLabel">
                    <?php echo e(trans('front_trans.add')); ?>

                </h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <!-- add_form -->
                <form action="<?php echo e(route('work_time.store')); ?>" method="POST">
                    <?php echo csrf_field(); ?>

                    <div class="row"  style="padding: 25px 0px 5px 0px;">
                        <div class="col">
                            <label for="start_day" class="mr-sm-2"><?php echo e(trans('front_trans.start_day')); ?>

                                :</label>
                                <select name="start_day" required class="form-control">
                                    <option value="0">              <?php echo e(trans('social_trans.0')); ?>          </option>
                                    <option value="Sunday">         <?php echo e(trans('front_trans.Sunday')); ?>      </option>
                                    <option value="Monday">         <?php echo e(trans('front_trans.Monday')); ?>      </option>
                                    <option value="Tuesday">        <?php echo e(trans('front_trans.Tuesday')); ?>     </option>
                                    <option value="Wednesday">      <?php echo e(trans('front_trans.Wednesday')); ?>   </option>
                                    <option value="Thursday">       <?php echo e(trans('front_trans.Thursday')); ?>    </option>
                                    <option value="Friday">         <?php echo e(trans('front_trans.Friday')); ?>      </option>
                                    <option value="Saturday">       <?php echo e(trans('front_trans.Saturday')); ?>    </option>
                                </select>
                        </div>
                        <div class="col">
                            <label for="end_day" class="mr-sm-2"><?php echo e(trans('front_trans.end_day')); ?>

                                :</label>
                                <select name="end_day" required class="form-control">
                                    <option value="0">              <?php echo e(trans('social_trans.0')); ?>          </option>
                                    <option value="Sunday">         <?php echo e(trans('front_trans.Sunday')); ?>      </option>
                                    <option value="Monday">         <?php echo e(trans('front_trans.Monday')); ?>      </option>
                                    <option value="Tuesday">        <?php echo e(trans('front_trans.Tuesday')); ?>     </option>
                                    <option value="Wednesday">      <?php echo e(trans('front_trans.Wednesday')); ?>   </option>
                                    <option value="Thursday">       <?php echo e(trans('front_trans.Thursday')); ?>    </option>
                                    <option value="Friday">         <?php echo e(trans('front_trans.Friday')); ?>      </option>
                                    <option value="Saturday">       <?php echo e(trans('front_trans.Saturday')); ?>    </option>
                                </select>
                        </div>
                    </div>

                    <div class="row"  style="padding: 25px 0px 5px 0px;">
                        <div class="col">
                            <label for="start_time" class="mr-sm-2"><?php echo e(trans('front_trans.start_time')); ?>

                                :</label>
                            <input type="time" class="form-control" name="start_time">
                        </div>
                        <div class="col">
                            <label for="end_time" class="mr-sm-2"><?php echo e(trans('front_trans.end_time')); ?>

                                :</label>
                            <input type="time" name="end_time" class="form-control">
                        </div>
                    </div>

                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary"
                            data-dismiss="modal"><?php echo e(trans('feature_trans.Close')); ?></button>
                        <button type="submit"
                            class="btn btn-success"><?php echo e(trans('feature_trans.submit')); ?></button>
                    </div>
                </form>

            </div>
        </div>
    </div>

</div>

<!-- row closed -->
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
<?php echo toastr_js(); ?>
<?php echo app('toastr')->render(); ?>

<script type="text/javascript">
    $(document).ready(function() {
      $('.summernote').summernote({
            tabSize: 2,
            height: 100,
        });
        $("#summernote").code()
                .replace(/<\/p>/gi, "\n")
                .replace(/<br\/?>/gi, "\n")
                .replace(/<\/?[^>]+(>|$)/g, "");
    });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\4FARH\OneDrive\Desktop\Real-Estate Last Version\resources\views/pages/admin/work_time/index.blade.php ENDPATH**/ ?>