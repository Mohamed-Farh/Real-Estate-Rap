<div class="card-body">
    <?php echo Form::open(['route' => 'home/search', 'method' => 'get']); ?>

    <div class="row">

        <div class="col-2">
            <div class="form-group">
                <?php echo Form::text('keyword', old('keyword', request()->input('keyword')), ['class' => 'form-control', 'placeholder' => trans('front_trans.type_word')]); ?>

            </div>
        </div>

        <?php
            $category_ar = \App\Models\Category::orderBy('id', 'desc')->pluck('name_ar', 'id');
            $category_en = \App\Models\Category::orderBy('id', 'desc')->pluck('name_en', 'id');
        ?>
        <div class="col-2">
            <div class="form-group">
                <?php if(App::getLocale() == 'en'): ?>
                    <?php if($category_en !=''): ?>
                        <?php echo Form::select('category_id', ['' => '---'] + $category_en->toArray(), old('category_id', request()->input('category_id')), ['class' => 'form-control choose_filter']); ?>

                    <?php else: ?>
                    <?php echo Form::select('category_id', ['' => '---'] + $category_ar->toArray(), old('category_id', request()->input('category_id')), ['class' => 'form-control choose_filter']); ?>

                    <?php endif; ?>
                <?php else: ?>
                    <?php if($category_ar !=''): ?>
                    <?php echo Form::select('category_id', ['' => '---'] + $category_en->toArray(), old('category_id', request()->input('category_id')), ['class' => 'form-control choose_filter']); ?>

                    <?php else: ?>
                    <?php echo Form::select('category_id', ['' => '---'] + $category_en->toArray(), old('category_id', request()->input('category_id')), ['class' => 'form-control choose_filter']); ?>

                    <?php endif; ?>
                <?php endif; ?>
            </div>
        </div>

         

        <div class="col-2">
            <div class="form-group">
                <?php if(App::getLocale() == 'en'): ?>
                    <?php echo Form::text('city_en', old('city_en', request()->input('city_en')), ['class' => 'form-control', 'placeholder' => 'Search City Here']); ?>

                <?php else: ?>
                    <?php echo Form::text('city_ar', old('city_ar', request()->input('city_ar')), ['class' => 'form-control', 'placeholder' => 'بحث بالمدينة']); ?>

                <?php endif; ?>
            </div>
        </div>

        <div class="col-2">
            <div class="form-group">
                <?php if(App::getLocale() == 'en'): ?>
                    <?php echo Form::text('address_en', old('address_en', request()->input('address_en')), ['class' => 'form-control', 'placeholder' => 'Search Address Here']); ?>

                <?php else: ?>
                    <?php echo Form::text('address_ar', old('address_ar', request()->input('address_ar')), ['class' => 'form-control', 'placeholder' => 'بحث بالحي']); ?>

                <?php endif; ?>
            </div>
        </div>


        <div class="col-2">
            <div class="form-group" style="padding-top: 7px">
                <?php echo Form::select('price', ['' => '---', 'less_expensive' =>trans('front_trans.less_expensive'), 'more_expensive' =>trans('front_trans.more_expensive')], old('price', request()->input('price')), ['class' => 'form-control choose_filter']); ?>

            </div>
        </div>

        <div class="col-2">
            <div class="form-group" style="padding-top: 7px">
                <?php echo Form::select('size', ['' => '---', 'less_size' =>trans('front_trans.less_size'), 'more_size' =>trans('front_trans.more_size')], old('price', request()->input('price')), ['class' => 'form-control choose_filter']); ?>

            </div>
        </div>

        <div class="col-2">
            <div class="form-group">
                <?php echo Form::label('price', trans('front_trans.price')); ?>

                <?php echo Form::text('min_price', old('min_price'), ['class' => 'form-control', 'placeholder' => trans('front_trans.min_price')]); ?> <br>
                <?php echo Form::text('max_price', old('max_price'), ['class' => 'form-control', 'placeholder' => trans('front_trans.max_price')]); ?>

            </div>
        </div>

        <div class="col-2">
            <div class="form-group">
                <?php echo Form::label('size', trans('front_trans.size')); ?>

                <?php echo Form::text('min_size', old('min_size'), ['class' => 'form-control', 'placeholder' => trans('front_trans.min_size')]); ?> <br>
                <?php echo Form::text('max_size', old('max_size'), ['class' => 'form-control', 'placeholder' => trans('front_trans.max_size')]); ?>

            </div>
        </div>


        <div class="col-2">
            <div class="form-group">
                <?php echo Form::button(trans('front_trans.search_here'), ['class' => 'btn btn-info property_search', 'type' => 'submit']); ?>

            </div>
        </div>
    </div>
    <?php echo Form::close(); ?>

</div>


 
<?php /**PATH C:\Users\4FARH\OneDrive\Desktop\World\resources\views/pages/admin/properties/filter.blade.php ENDPATH**/ ?>