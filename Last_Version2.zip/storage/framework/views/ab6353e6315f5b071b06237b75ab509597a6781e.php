<!DOCTYPE html>
<html lang="en">
<?php $__env->startSection('title'); ?>
<?php echo e(trans('main_trans.Main_title')); ?>

<?php $__env->stopSection(); ?>
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="keywords" content="HTML5 Template" />
    <meta name="description" content="Webmin - Bootstrap 4 & Angular 5 Admin Dashboard Template" />
    <meta name="author" content="potenzaglobalsolutions.com" />
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1" />
    <link rel="preconnect" href="https://fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css2?family=Cairo:wght@600&display=swap" rel="stylesheet">
    <?php echo $__env->make('layouts.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</head>

<?php
        $user_count    =\App\User::where('admin', 0)->count();
        $category_count =\App\Models\Category::all()->count();
        $property_count =\App\Models\Property::all()->count();
        $gallery_count  =\App\Models\Gallery::where('type', 0)->count();
?>

<?php
    $users      =App\User::orderBy('id', 'desc')->limit(5)->get();
    $properties =App\Models\Property::orderBy('id', 'desc')->limit(5)->get();
    $categories =App\Models\Category::orderBy('id', 'desc')->limit(5)->get();
?>

<body style="font-family: 'Cairo', sans-serif">

    <div class="wrapper" style="font-family: 'Cairo', sans-serif">

        <!--=================================
 preloader -->

 <div id="pre-loader">
     <img src="<?php echo e(URL::asset('assets/images/pre-loader/loader-01.svg')); ?>" alt="">
 </div>

        <!--=================================
 preloader -->

        <?php echo $__env->make('layouts.main-header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <?php echo $__env->make('layouts.main-sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <!--=================================
 Main content -->
        <!-- main-content -->
        <div class="content-wrapper">
            <div class="page-title" >
                <div class="row">
                    <div class="col-sm-6" >
                        <h4 class="mb-0" style="font-family: 'Cairo', sans-serif"><?php echo e(trans('main_trans.Dashboard_page')); ?></h4>
                    </div>
                    <div class="col-sm-6">
                        <ol class="breadcrumb pt-0 pr-0 float-left float-sm-right">
                        </ol>
                    </div>
                </div>
            </div>
            <!-- widgets -->
            <div class="row" >
                <div class="col-xl-3 col-lg-6 col-md-6 mb-30">
                    <div class="card card-statistics h-100">
                        <div class="card-body">
                            <div class="clearfix">
                                <div class="float-left">
                                    <span class="text-danger">
                                        <i class="fa fa-users highlight-icon" aria-hidden="true"></i>
                                    </span>
                                </div>
                                <div class="float-right text-right">
                                    <p class="card-text text-dark"><?php echo e(trans('main_trans.Users')); ?></p>
                                    <h4><?php echo e($user_count); ?></h4>
                                </div>
                            </div>
                            <p class="text-muted pt-3 mb-0 mt-2 border-top">
                                <i class="fa fa-bookmark-o mr-1" aria-hidden="true"></i><?php echo e($user_count); ?></p>
                        </div>
                    </div>
                </div>
                <div class="col-xl-3 col-lg-6 col-md-6 mb-30">
                    <div class="card card-statistics h-100">
                        <div class="card-body">
                            <div class="clearfix">
                                <div class="float-left">
                                    <span class="text-warning">
                                        <i class="fa fa-building highlight-icon" aria-hidden="true"></i>
                                    </span>
                                </div>
                                <div class="float-right text-right">
                                    <p class="card-text text-dark"><?php echo e(trans('main_trans.Property')); ?></p>
                                    <h4><?php echo e($property_count); ?></h4>
                                </div>
                            </div>
                            <p class="text-muted pt-3 mb-0 mt-2 border-top">
                                <i class="fa fa-bookmark-o mr-1" aria-hidden="true"></i><?php echo e($property_count); ?></p>
                        </div>
                    </div>
                </div>
                <div class="col-xl-3 col-lg-6 col-md-6 mb-30">
                    <div class="card card-statistics h-100">
                        <div class="card-body">
                            <div class="clearfix">
                                <div class="float-left">
                                    <span class="text-success">
                                        <i class="fad fa-hospitals highlight-icon" aria-hidden="true"></i>
                                    </span>
                                </div>
                                <div class="float-right text-right">
                                    <p class="card-text text-dark"><?php echo e(trans('main_trans.category')); ?></p>
                                    <h4><?php echo e($category_count); ?></h4>
                                </div>
                            </div>
                            <p class="text-muted pt-3 mb-0 mt-2 border-top">
                                <i class="fa fa-bookmark-o mr-1" aria-hidden="true"></i> <?php echo e($category_count); ?> </p>
                        </div>
                    </div>
                </div>
                <div class="col-xl-3 col-lg-6 col-md-6 mb-30">
                    <div class="card card-statistics h-100">
                        <div class="card-body">
                            <div class="clearfix">
                                <div class="float-left">
                                    <span class="text-primary">
                                        <i class="fad fa-images highlight-icon" aria-hidden="true"></i>
                                    </span>
                                </div>
                                <div class="float-right text-right">
                                    <p class="card-text text-dark"><?php echo e(trans('main_trans.gallery')); ?></p>
                                    <h4><?php echo e($gallery_count); ?></h4>
                                </div>
                            </div>
                            <p class="text-muted pt-3 mb-0 mt-2 border-top">
                                <i class="fa fa-bookmark-o mr-1" aria-hidden="true"></i> <?php echo e($gallery_count); ?></p>
                        </div>
                    </div>
                </div>
            </div>

            <div class="container-fluid mt--7">
                <div class="row">

                    <!------------- Users In Dashboard -------------------->
                    <div class="col-xl-6 mb-5 mb-xl-0">
                        <div class="card bg-gradient-default dashboard_track">
                            <div class="card-header border-0">
                                <div class="row align-items-center">
                                    <div class="col">
                                        <h3 class="mb-0"  style="font-size: x-large;"><?php echo e(trans('main_trans.latest-user')); ?></h3>
                                    </div>
                                    <div class="col text-right">
                                        <a href="<?php echo e(route('users.index')); ?>" class="btn btn-sm btn-primary"><?php echo e(trans('main_trans.see-all')); ?></a>
                                    </div>
                                </div>
                            </div>
                            <?php if(count($users)): ?>
                                <div class="table-responsive">
                                    <table class="table align-items-center table-flush">
                                        <thead class="thead-light">
                                            <tr>
                                                <th scope="col"><?php echo e(trans('contactus_trans.Name')); ?></th></th>
                                                <th scope="col"><?php echo e(trans('contactus_trans.email')); ?></th>
                                                <th scope="col"><?php echo e(trans('users_trans.created_at')); ?></th>
                                            </tr>
                                        </thead>
                                        <tbody>

                                            <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <tr>
                                                    <?php if(App::getLocale() == 'en'): ?>
                                                        <?php if($user->name !=''): ?>
                                                            <td><?php echo e($user->name); ?></td>
                                                        <?php else: ?>
                                                            <td><?php echo e($user->name_ar); ?></td>
                                                        <?php endif; ?>
                                                    <?php else: ?>
                                                        <?php if($user->name_ar !=''): ?>
                                                            <td><?php echo e($user->name_ar); ?></td>
                                                        <?php else: ?>
                                                            <td><?php echo e($user->name); ?></td>
                                                        <?php endif; ?>
                                                    <?php endif; ?>

                                                    <td><?php echo e($user->email); ?></td>
                                                    <td><?php echo e($user->created_at->diffForHumans()); ?></td>
                                                </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </tbody>
                                    </table>
                                </div>
                                <?php else: ?>
                                    <p class="lead text-center"> No Users Was Found </p>
                                <?php endif; ?>
                            </div>
                        </div>



                    <!------------- Category In Dashboard -------------------->
                    <div class="col-xl-6 mb-5 mb-xl-0">
                        <div class="card bg-gradient-default dashboard_track">
                            <div class="card-header border-0">
                                <div class="row align-items-center">
                                    <div class="col">
                                        <h3 class="mb-0" style="font-size: x-large;"><?php echo e(trans('main_trans.latest-category')); ?></h3>
                                    </div>
                                    <div class="col text-right">
                                        <a href="<?php echo e(route('categories.index')); ?>" class="btn btn-sm btn-primary"><?php echo e(trans('main_trans.see-all')); ?></a>
                                    </div>
                                </div>
                            </div>
                            <?php if(count($categories)): ?>
                                <div class="table-responsive">
                                    <table class="table align-items-center table-flush">
                                        <thead class="thead-light">
                                            <tr>
                                                <th scope="col"><?php echo e(trans('users_trans.Name')); ?></th></th>
                                                <th scope="col"><?php echo e(trans('main_trans.Property')); ?></th>
                                                <th scope="col"><?php echo e(trans('users_trans.created_at')); ?></th>
                                            </tr>
                                        </thead>
                                        <tbody>

                                            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <tr>
                                                    <?php if(App::getLocale() == 'en'): ?>
                                                        <td><?php echo e($category->name_en); ?></td>
                                                    <?php else: ?>
                                                        <td><?php echo e($category->name_ar); ?></td>
                                                    <?php endif; ?>

                                                    <td>( <?php echo e(count($category->properties)); ?>  ) <?php echo e(trans('main_trans.property')); ?></td>
                                                    <td><?php echo e($category->created_at->diffForHumans()); ?></td>
                                                </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                        </tbody>
                                    </table>
                                </div>

                            <?php else: ?>
                                <p class="lead text-center"> No Category Was Found </p>
                            <?php endif; ?>
                        </div>
                    </div>



                    <!------------- Courses In Dashboard -------------------->
                    <div class="col-xl-12" style="margin-top: 70px;">
                        <div class="card bg-gradient-default dashboard_course">

                            <div class="card-header border-0">
                                <div class="row align-items-center">
                                    <div class="col">
                                        <h3 class="mb-0"  style="font-size: x-large;"><?php echo e(trans('main_trans.latest-property')); ?></h3>
                                    </div>
                                    <div class="col text-right">
                                        <a href="<?php echo e(route('properties.index')); ?>" class="btn btn-sm btn-primary"><?php echo e(trans('main_trans.see-all')); ?></a>
                                    </div>
                                </div>
                            </div>

                            <?php if(count($properties)): ?>
                                <div class="table-responsive">
                                    <table class="table align-items-center table-flush">
                                        <thead class="thead-light">
                                            <tr>
                                                <th><?php echo e(trans('property_trans.photo')); ?></th>
                                                <th><?php echo e(trans('property_trans.title')); ?></th>
                                                <th><?php echo e(trans('property_trans.category_id')); ?></th>
                                                <th><?php echo e(trans('property_trans.price')); ?></th>
                                                <th><?php echo e(trans('property_trans.purpose')); ?></th>
                                                <th><?php echo e(trans('property_trans.status')); ?></th>
                                                <th><?php echo e(trans('property_trans.city')); ?></th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php $__currentLoopData = $properties; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $property): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <tr>

                                                    <?php if($property->photo): ?>
                                                        <td><img class="img-responsive thumbnail" src="<?php echo e(url('image/photo/'.$property->photo)); ?>" style="width: 70px; border-radius: 20px;    height: 56.01px;"></td>
                                                    <?php else: ?>
                                                        <td><img class="img-responsive thumbnail" src="<?php echo e(url('image/photo/default.jpg')); ?>" style="width: 70px; border-radius: 20px;    height: 56.01px;"></td>
                                                    <?php endif; ?>

                                                    <?php if(App::getLocale() == 'en'): ?>
                                                        <?php if($property->title_en !=''): ?>
                                                            <td><?php echo e($property->title_en); ?></td>
                                                        <?php else: ?>
                                                            <td><?php echo e($property->title_ar); ?></td>
                                                        <?php endif; ?>
                                                    <?php else: ?>
                                                        <td><?php echo e($property->title_ar); ?></td>
                                                    <?php endif; ?>

                                                    <?php if($property->category): ?>
                                                        <?php if(App::getLocale() == 'en'): ?>
                                                            <?php if($property->category->name_en !=''): ?>
                                                                <td><?php echo e(\Str::limit($property->category->name_en,25)); ?></td>
                                                            <?php else: ?>
                                                                <td><?php echo e(\Str::limit($property->category->name_ar,25)); ?></td>
                                                            <?php endif; ?>
                                                        <?php else: ?>
                                                            <td><?php echo e(\Str::limit($property->category->name_ar,25)); ?></td>
                                                        <?php endif; ?>
                                                    <?php else: ?>
                                                        <td> - </td>
                                                    <?php endif; ?>


                                                    <td><?php echo e($property->price); ?></td>
                                                    <td><?php echo e($property->purpose == 'rent' ? trans('property_trans.rent') : trans('property_trans.sale')); ?></td>
                                                    <td><?php echo e($property->status == 'sold' ? trans('property_trans.sold') : trans('property_trans.for_sale')); ?></td>

                                                    <?php if(App::getLocale() == 'en'): ?>
                                                        <?php if($property->city_en !=''): ?>
                                                            <td><?php echo e($property->city_en); ?></td>
                                                        <?php else: ?>
                                                            <td><?php echo e($property->city_ar); ?></td>
                                                        <?php endif; ?>
                                                    <?php else: ?>
                                                        <td><?php echo e($property->city_ar); ?></td>
                                                    <?php endif; ?>
                                                </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </table>
                                </div>

                            <?php else: ?>
                                <p class="lead text-center"> No Properties Was Found </p>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>


            <!--=================================
             wrapper -->

            <!--=================================
             footer -->

            <?php echo $__env->make('layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div><!-- main content wrapper end-->
    </div>
    </div>
    </div>

    <!--=================================
 footer -->

    <?php echo $__env->make('layouts.footer-scripts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

</body>

</html>
<?php /**PATH C:\Users\4FARH\OneDrive\Desktop\Real-Estate Last Version\resources\views/dashboard.blade.php ENDPATH**/ ?>