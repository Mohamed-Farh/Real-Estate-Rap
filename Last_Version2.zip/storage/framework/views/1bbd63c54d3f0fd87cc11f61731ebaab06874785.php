<?php $__env->startSection('css'); ?>
    <?php echo toastr_css(); ?>


<?php $__env->startSection('title'); ?>
    <?php echo e(trans('front_trans.company_location')); ?>

<?php $__env->stopSection(); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('page-header'); ?>
<!-- breadcrumb -->
<?php $__env->startSection('PageTitle'); ?>
<?php echo e(trans('front_trans.company_location')); ?>

<?php $__env->stopSection(); ?>
<!-- breadcrumb -->
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<!-- row -->
<div class="row">

<div class="col-xl-12 mb-30">
    <div class="card card-statistics h-100">
        <div class="card-body">

            <?php if($errors->any()): ?>
                <div class="alert alert-danger">
                    <ul>
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><?php echo e($error); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
            <?php endif; ?>

            <?php
                $company_locations = \App\Models\Company_Location::all();
            ?>


            <button type="button" class="button x-small" data-toggle="modal" data-target="#exampleModal">
                <?php echo e(trans('front_trans.add')); ?>

            </button>
            <br><br>

            <!--start about us section-->
            <div class="table-responsive">
                <table id="datatable" class="table  table-hover table-sm table-bordered p-0" data-page-length="50"
                    style="text-align: center">
                    <thead>
                        <tr>
                            <th>#</th>
                            <th><?php echo e(trans('front_trans.country')); ?></th>
                            <th><?php echo e(trans('front_trans.city')); ?></th>
                            <th><?php echo e(trans('front_trans.address')); ?></th>
                            <th><?php echo e(trans('front_trans.location_latitude')); ?></th>
                            <th><?php echo e(trans('front_trans.location_longitude')); ?></th>
                            <th><?php echo e(trans('feature_trans.Processes')); ?></th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $i = 0; ?>
                            <tr>
                            <?php $__currentLoopData = $company_locations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $location): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php $i++; ?>
                                    <td><?php echo e($i); ?></td>

                                    <?php if(App::getLocale() == 'en'): ?>
                                        <?php if($location->country_en !=''): ?>
                                            <td><?php echo e($location->country_en); ?></td>
                                        <?php else: ?>
                                            <td><?php echo e($location->country_ar); ?></td>
                                        <?php endif; ?>
                                    <?php else: ?>
                                        <?php if($location->country_ar !=''): ?>
                                            <td><?php echo e($location->country_ar); ?></td>
                                        <?php else: ?>
                                            <td><?php echo e($location->country_en); ?></td>
                                        <?php endif; ?>
                                    <?php endif; ?>

                                    <?php if(App::getLocale() == 'en'): ?>
                                        <?php if($location->city_en !=''): ?>
                                            <td><?php echo e($location->city_en); ?></td>
                                        <?php else: ?>
                                            <td><?php echo e($location->city_ar); ?></td>
                                        <?php endif; ?>
                                    <?php else: ?>
                                        <?php if($location->city_ar !=''): ?>
                                            <td><?php echo e($location->city_ar); ?></td>
                                        <?php else: ?>
                                            <td><?php echo e($location->city_en); ?></td>
                                        <?php endif; ?>
                                    <?php endif; ?>

                                    <?php if(App::getLocale() == 'en'): ?>
                                        <?php if($location->address_en !=''): ?>
                                            <td><?php echo e($location->address_en); ?></td>
                                        <?php else: ?>
                                            <td><?php echo e($location->address_ar); ?></td>
                                        <?php endif; ?>
                                    <?php else: ?>
                                        <?php if($location->address_ar !=''): ?>
                                            <td><?php echo e($location->address_ar); ?></td>
                                        <?php else: ?>
                                            <td><?php echo e($location->address_en); ?></td>
                                        <?php endif; ?>
                                    <?php endif; ?>


                                    <td><?php echo e($location->location_latitude); ?></td>
                                    <td><?php echo e($location->location_longitude); ?></td>

                                    <td>

                                        <button type="button" class="btn btn-success btn-sm">
                                            <a href="https://www.google.com/maps/search/?api=1&query=<?php echo e($location->location_latitude); ?>,<?php echo e($location->location_longitude); ?>" target="_blank">
                                            <i class="fa fa-eye"></i></a></button>

                                        <button type="button" class="btn btn-info btn-sm" data-toggle="modal"
                                            data-target="#edit<?php echo e($location->id); ?>"
                                            title="<?php echo e(trans('feature_trans.Edit')); ?>"><i
                                                class="fa fa-edit"></i></button>

                                        <button type="button" class="btn btn-danger btn-sm" data-toggle="modal"
                                            data-target="#delete<?php echo e($location->id); ?>"
                                            title="<?php echo e(trans('feature_trans.Delete')); ?>"><i
                                                class="fa fa-trash"></i></button>
                                    </td>
                            </tr>

                            <!-- edit_modal_feature -->
                            <div class="modal fade" id="edit<?php echo e($location->id); ?>" tabindex="-1" role="dialog"
                                aria-labelledby="exampleModalLabel" aria-hidden="true">
                                <div class="modal-dialog" role="document">
                                    <div class="modal-content"  style="width: 120% !important; ">
                                        <div class="modal-header">
                                            <h5 style="font-family: 'Cairo', sans-serif;" class="modal-title"
                                                id="exampleModalLabel">
                                                <?php echo e(trans('front_trans.edit')); ?>

                                            </h5>
                                            <button type="button" class="close" data-dismiss="modal"
                                                aria-label="Close">
                                                <span aria-hidden="true">&times;</span>
                                            </button>
                                        </div>
                                        <div class="modal-body">
                                            <!-- add_form -->
                                            <form action="<?php echo e(route('company_location.update', 'test')); ?>" method="post">
                                                <?php echo e(method_field('patch')); ?>

                                                <?php echo csrf_field(); ?>
                                                <input id="id" type="hidden" name="id" class="form-control"
                                                            value="<?php echo e($location->id); ?>">
                                                <div class="row"  style="padding: 25px 0px 5px 0px;">
                                                    <div class="col">
                                                        <label for="country_ar" class="mr-sm-2"><?php echo e(trans('front_trans.country_ar')); ?>

                                                            :</label>
                                                        <input type="text" class="form-control" name="country_ar" value="<?php echo e($location->country_ar); ?>">
                                                    </div>
                                                    <div class="col">
                                                        <label for="country_en" class="mr-sm-2"><?php echo e(trans('front_trans.country_en')); ?>

                                                            :</label>
                                                        <input type="text" name="country_en" class="form-control" value="<?php echo e($location->country_en); ?>">
                                                    </div>
                                                </div>

                                                <div class="row"  style="padding: 25px 0px 5px 0px;">
                                                    <div class="col">
                                                        <label for="city_ar" class="mr-sm-2"><?php echo e(trans('front_trans.city_ar')); ?>

                                                            :</label>
                                                        <input type="text" class="form-control" name="city_ar" value="<?php echo e($location->city_ar); ?>">
                                                    </div>
                                                    <div class="col">
                                                        <label for="city_en" class="mr-sm-2"><?php echo e(trans('front_trans.city_en')); ?>

                                                            :</label>
                                                        <input type="text" name="city_en" class="form-control" value="<?php echo e($location->city_en); ?>">
                                                    </div>
                                                </div>

                                                <div class="row"  style="padding: 25px 0px 5px 0px;">
                                                    <div class="col">
                                                        <label for="address_ar" class="mr-sm-2"><?php echo e(trans('front_trans.address_ar')); ?>

                                                            :</label>
                                                        <input type="text" class="form-control" name="address_ar" value="<?php echo e($location->address_ar); ?>">
                                                    </div>
                                                    <div class="col">
                                                        <label for="address_en" class="mr-sm-2"><?php echo e(trans('front_trans.address_en')); ?>

                                                            :</label>
                                                        <input type="text" name="address_en" class="form-control" value="<?php echo e($location->address_en); ?>">
                                                    </div>
                                                </div>

                                                <div class="row"  style="padding: 25px 0px 5px 0px;">
                                                    <div class="col">
                                                        <label for="location_latitude" class="mr-sm-2"><?php echo e(trans('front_trans.location_latitude')); ?>

                                                            :</label>
                                                        <input type="number" step="any" class="form-control" name="location_latitude" value="<?php echo e($location->location_latitude); ?>">
                                                    </div>
                                                    <div class="col">
                                                        <label for="location_longitude" class="mr-sm-2"><?php echo e(trans('front_trans.location_longitude')); ?>

                                                            :</label>
                                                        <input type="number" step="any" name="location_longitude" class="form-control" value="<?php echo e($location->location_longitude); ?>">
                                                    </div>
                                                </div>

                                                <div class="modal-footer">
                                                    <button type="button" class="btn btn-secondary"
                                                        data-dismiss="modal"><?php echo e(trans('feature_trans.Close')); ?></button>
                                                    <button type="submit"
                                                        class="btn btn-success"><?php echo e(trans('feature_trans.submit')); ?></button>
                                                </div>
                                            </form>

                                        </div>
                                    </div>
                                </div>
                            </div>

                            <!-- delete_modal_feature -->
                            <div class="modal fade" id="delete<?php echo e($location->id); ?>" tabindex="-1" role="dialog"
                                aria-labelledby="exampleModalLabel" aria-hidden="true">
                                <div class="modal-dialog" role="document">
                                    <div class="modal-content">
                                        <div class="modal-header">
                                            <h5 style="font-family: 'Cairo', sans-serif;" class="modal-title"
                                                id="exampleModalLabel">
                                                <?php echo e(trans('front_trans.Delete')); ?>

                                            </h5>
                                            <button type="button" class="close" data-dismiss="modal"
                                                aria-label="Close">
                                                <span aria-hidden="true">&times;</span>
                                            </button>
                                        </div>
                                        <div class="modal-body">
                                            <form action="<?php echo e(route('company_location.destroy', 'test')); ?>" method="post">
                                                <?php echo e(method_field('Delete')); ?>

                                                <?php echo csrf_field(); ?>
                                                <?php echo e(trans('social_trans.Warning_social')); ?>

                                                <input id="id" type="hidden" name="id" class="form-control"
                                                    value="<?php echo e($location->id); ?>">
                                                <div class="modal-footer">
                                                    <button type="button" class="btn btn-secondary"
                                                        data-dismiss="modal"><?php echo e(trans('front_trans.Close')); ?></button>
                                                    <button type="submit"
                                                        class="btn btn-danger"><?php echo e(trans('front_trans.Delete')); ?></button>
                                                </div>
                                            </form>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </table>
            </div>
        </div>
    </div>
</div>


<!-- add_modal_feature -->
<div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
    aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content" style="width: 120% !important; ">
            <div class="modal-header">
                <h5 style="font-family: 'Cairo', sans-serif;" class="modal-title" id="exampleModalLabel">
                    <?php echo e(trans('front_trans.add')); ?>

                </h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <!-- add_form -->
                <form action="<?php echo e(route('company_location.store')); ?>" method="POST">
                    <?php echo csrf_field(); ?>

                    <div class="row"  style="padding: 25px 0px 5px 0px;">
                        <div class="col">
                            <label for="country_ar" class="mr-sm-2"><?php echo e(trans('front_trans.country_ar')); ?>

                                :</label>
                            <input type="text" class="form-control" name="country_ar">
                        </div>
                        <div class="col">
                            <label for="country_en" class="mr-sm-2"><?php echo e(trans('front_trans.country_en')); ?>

                                :</label>
                            <input type="text" name="country_en" class="form-control">
                        </div>
                    </div>

                    <div class="row"  style="padding: 25px 0px 5px 0px;">
                        <div class="col">
                            <label for="city_ar" class="mr-sm-2"><?php echo e(trans('front_trans.city_ar')); ?>

                                :</label>
                            <input type="text" class="form-control" name="city_ar">
                        </div>
                        <div class="col">
                            <label for="city_en" class="mr-sm-2"><?php echo e(trans('front_trans.city_en')); ?>

                                :</label>
                            <input type="text" name="city_en" class="form-control">
                        </div>
                    </div>

                    <div class="row"  style="padding: 25px 0px 5px 0px;">
                        <div class="col">
                            <label for="address_ar" class="mr-sm-2"><?php echo e(trans('front_trans.address_ar')); ?>

                                :</label>
                            <input type="text" class="form-control" name="address_ar">
                        </div>
                        <div class="col">
                            <label for="address_en" class="mr-sm-2"><?php echo e(trans('front_trans.address_en')); ?>

                                :</label>
                            <input type="text" name="address_en" class="form-control">
                        </div>
                    </div>

                    <div class="row"  style="padding: 25px 0px 5px 0px;">
                        <div class="col">
                            <label for="location_latitude" class="mr-sm-2"><?php echo e(trans('front_trans.location_latitude')); ?>

                                :</label>
                            <input type="number" step="any" class="form-control" name="location_latitude">
                        </div>
                        <div class="col">
                            <label for="location_longitude" class="mr-sm-2"><?php echo e(trans('front_trans.location_longitude')); ?>

                                :</label>
                            <input type="number" step="any" name="location_longitude" class="form-control">
                        </div>
                    </div>

                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary"
                            data-dismiss="modal"><?php echo e(trans('feature_trans.Close')); ?></button>
                        <button type="submit"
                            class="btn btn-success"><?php echo e(trans('feature_trans.submit')); ?></button>
                    </div>
                </form>

            </div>
        </div>
    </div>

</div>

<!-- row closed -->
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
<?php echo toastr_js(); ?>
<?php echo app('toastr')->render(); ?>

<script type="text/javascript">
    $(document).ready(function() {
      $('.summernote').summernote({
            tabSize: 2,
            height: 100,
        });
        $("#summernote").code()
                .replace(/<\/p>/gi, "\n")
                .replace(/<br\/?>/gi, "\n")
                .replace(/<\/?[^>]+(>|$)/g, "");
    });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\4FARH\OneDrive\Desktop\Real-Estate Last Version\resources\views/pages/admin/company_location/index.blade.php ENDPATH**/ ?>