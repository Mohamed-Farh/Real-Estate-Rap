<?php $__env->startSection('css'); ?>
    <?php echo toastr_css(); ?>
<?php $__env->startSection('title'); ?>
    <?php echo e(trans('property_trans.title_page')); ?>

<?php $__env->stopSection(); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('page-header'); ?>
<!-- breadcrumb -->
<?php $__env->startSection('PageTitle'); ?>
    <?php echo e(trans('main_trans.Property')); ?>

<?php $__env->stopSection(); ?>
<!-- breadcrumb -->
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<!-- row -->
<div class="row">
    <?php if($errors->any()): ?>
        <div class="error"><?php echo e($errors->first('Name')); ?></div>
    <?php endif; ?>

    <div class="col-xl-12 mb-30">
        <div class="card card-statistics h-100">
            <div class="card-body">

                <?php if($errors->any()): ?>
                    <div class="alert alert-danger">
                        <ul>
                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li><?php echo e($error); ?></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </div>
                <?php endif; ?>

                <button type="button" class="button x-small">
                    <a href="<?php echo e(route('properties.create')); ?>"><?php echo e(trans('property_trans.add_property')); ?></a>
                </button>
                <br><br>

                <div class="table-responsive">
                    <table id="datatable" class="table  table-hover table-sm table-bordered p-0" data-page-length="50"
                        style="text-align: center">
                        <?php echo $__env->make('pages.admin.properties.filter', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        <thead>
                            <tr>
                                <th>#</th>
                                <th><?php echo e(trans('property_trans.photo')); ?></th>
                                <th><?php echo e(trans('property_trans.title')); ?></th>
                                <th><?php echo e(trans('property_trans.category_id')); ?></th>
                                <th><?php echo e(trans('property_trans.price')); ?></th>
                                <th><?php echo e(trans('property_trans.purpose')); ?></th>
                                <th><?php echo e(trans('property_trans.status')); ?></th>
                                <th><?php echo e(trans('property_trans.city')); ?></th>
                                <th><?php echo e(trans('property_trans.address')); ?></th>
                                <th><?php echo e(trans('property_trans.Processes')); ?></th>
                            </tr>
                        </thead>
                            <tbody>
                                <?php $i = 0; ?>
                                <?php $__empty_1 = true; $__currentLoopData = $properties; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $property): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                    <tr>
                                        <?php $i++; ?>
                                        
                                        <td><?php echo e($i); ?></td>

                                        <?php if($property->photo): ?>
                                            <td><img class="img-responsive thumbnail" src="<?php echo e(url('image/photo/'.$property->photo)); ?>" style="width: 70px; border-radius: 20px;    height: 56.01px;"></td>
                                        <?php else: ?>
                                            <td><img class="img-responsive thumbnail" src="<?php echo e(url('image/photo/default.jpg')); ?>" style="width: 70px; border-radius: 20px;    height: 56.01px;"></td>
                                        <?php endif; ?>

                                        <?php if(App::getLocale() == 'en'): ?>
                                            <?php if($property->title_en !=''): ?>
                                                <td><?php echo e(\Str::limit($property->title_en,25 )); ?></td>
                                            <?php else: ?>
                                                <td><?php echo e(\Str::limit($property->title_ar,25 )); ?></td>
                                            <?php endif; ?>
                                        <?php else: ?>
                                            <td><?php echo e(\Str::limit($property->title_ar,25 )); ?></td>
                                        <?php endif; ?>

                                        <?php if($property->category): ?>
                                            <?php if(App::getLocale() == 'en'): ?>
                                                <?php if($property->category->name_en !=''): ?>
                                                    <td><?php echo e(\Str::limit($property->category->name_en,25 )); ?></td>
                                                <?php else: ?>
                                                    <td><?php echo e(\Str::limit($property->category->name_ar,25 )); ?></td>
                                                <?php endif; ?>
                                            <?php else: ?>
                                                <td><?php echo e(\Str::limit($property->category->name_ar,25 )); ?></td>
                                            <?php endif; ?>
                                        <?php else: ?>
                                            <td> - </td>
                                        <?php endif; ?>


                                        <td><?php echo e($property->price); ?></td>
                                        <td><?php echo e($property->purpose == 'rent' ? trans('property_trans.rent') : trans('property_trans.sale')); ?></td>
                                        <td><?php echo e($property->status == 'sold' ? trans('property_trans.sold') : trans('property_trans.for_sale')); ?></td>

                                        <?php if(App::getLocale() == 'en'): ?>
                                            <?php if($property->city_en !=''): ?>
                                                <td><?php echo e($property->city_en); ?></td>
                                            <?php else: ?>
                                                <td><?php echo e($property->city_ar); ?></td>
                                            <?php endif; ?>
                                        <?php else: ?>
                                            <td><?php echo e($property->city_ar); ?></td>
                                        <?php endif; ?>

                                        <?php if(App::getLocale() == 'en'): ?>
                                            <?php if($property->address_en !=''): ?>
                                                <td><?php echo e($property->address_en); ?></td>
                                            <?php else: ?>
                                                <td><?php echo e($property->address_ar); ?></td>
                                            <?php endif; ?>
                                        <?php else: ?>
                                            <td><?php echo e($property->address_ar); ?></td>
                                        <?php endif; ?>

                                        <td class="property-td">
                                            
                                            <a href="<?php echo e(route('properties.show', $property)); ?>"><button type="button" class="btn btn-info btn-sm"><i class="fa fa-eye"></i></button></a>
                                            <a href="<?php echo e(route('properties.edit', $property)); ?>"><button type="button" class="btn btn-info btn-sm"><i class="fa fa-edit"></i></button></a>
                                            <button type="button" class="btn btn-danger btn-sm" data-toggle="modal"
                                                data-target="#delete<?php echo e($property->id); ?>"
                                                title="<?php echo e(trans('Grades_trans.Delete')); ?>"><i
                                                    class="fa fa-trash"></i></button>
                                        </td>
                                    </tr>



                                    <!-- delete_modal_Property -->
                                    <div class="modal fade" id="delete<?php echo e($property->id); ?>" tabindex="-1" role="dialog"
                                        aria-labelledby="exampleModalLabel" aria-hidden="true">
                                        <div class="modal-dialog" role="document">
                                            <div class="modal-content">
                                                <div class="modal-header">
                                                    <h5 style="font-family: 'Cairo', sans-serif;" class="modal-title"
                                                        id="exampleModalLabel">
                                                        <?php echo e(trans('property_trans.delete_property')); ?>

                                                    </h5>
                                                    <button type="button" class="close" data-dismiss="modal"
                                                        aria-label="Close">
                                                        <span aria-hidden="true">&times;</span>
                                                    </button>
                                                </div>
                                                <div class="modal-body">
                                                    <form action="<?php echo e(route('properties.destroy', 'test')); ?>" method="post">
                                                        <?php echo e(method_field('Delete')); ?>

                                                        <?php echo csrf_field(); ?>
                                                        <?php echo e(trans('Grades_trans.Warning_Grade')); ?>

                                                        <input id="id" type="hidden" name="id" class="form-control"
                                                            value="<?php echo e($property->id); ?>">
                                                        <div class="modal-footer">
                                                            <button type="button" class="btn btn-secondary"
                                                                data-dismiss="modal"><?php echo e(trans('Grades_trans.Close')); ?></button>
                                                            <button type="submit"
                                                                class="btn btn-danger"><?php echo e(trans('front_trans.Delete')); ?></button>
                                                        </div>
                                                    </form>
                                                </div>
                                            </div>
                                        </div>
                                    </div>


                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                    <tr>
                                        <td colspan="7" class="text-center">No posts found</td>
                                    </tr>
                                <?php endif; ?>
                            </table>
                        </div>
                    </div>
                </div>
            </div>

<!-- row closed -->
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
<?php echo toastr_js(); ?>
<?php echo app('toastr')->render(); ?>
<?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/dbsc4c7x1fsq/a_raptors_egypt/resources/views/pages/admin/properties/index.blade.php ENDPATH**/ ?>