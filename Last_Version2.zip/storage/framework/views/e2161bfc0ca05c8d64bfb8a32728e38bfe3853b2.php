<?php $__env->startSection('content'); ?>

    <?php $sliders = \App\Models\Gallery::where('type', 1)->get(); ?>

    <div id="carouselExampleIndicators" class="carousel slide" data-ride="carousel">
        <ol class="carousel-indicators">
            <li data-target="#carouselExampleIndicators" data-slide-to="0" class="active"></li>
            <li data-target="#carouselExampleIndicators" data-slide-to="1"></li>
            <li data-target="#carouselExampleIndicators" data-slide-to="2"></li>
        </ol>
        <div class="carousel-inner">
            <div class="carousel-item active">
                <img src="<?php echo e(asset('image/gallery/slider/slider.jpg')); ?>" data-aos="zoom-in" class="d-block w-100"
                    style="width: 100%; height:650px;">
            </div>
            <?php $__currentLoopData = $sliders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $slider): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if($slider->type == '1' && $slider->status == '0'): ?>
                    <div class="carousel-item">
                        <img class="d-block w-100" src="<?php echo e(Url($slider->path)); ?>" alt="Second slide"
                            style="width: 100%; height:650px;">
                    </div>
                <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        <a class="carousel-control-prev" href="#carouselExampleIndicators" role="button" data-slide="prev">
            <span class="carousel-control-prev-icon" aria-hidden="true"></span>
            <span class="sr-only">Previous</span>
        </a>
        <a class="carousel-control-next" href="#carouselExampleIndicators" role="button" data-slide="next">
            <span class="carousel-control-next-icon" aria-hidden="true"></span>
            <span class="sr-only">Next</span>
        </a>
    </div>
    <!--end background-->




    <!--start about us-->
    <div class="about-us py-4">
        <div class="container">
            <h2 class="make_right_ar make_left_en"><?php echo e(trans('front_trans.aboutus')); ?></h2>
            <?php $bout_us = \App\Models\Front\Aboutus::all(); ?>
            <?php $__currentLoopData = $bout_us; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $aboutus): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="row">
                    <div class="col-sx-12 col-sm-12 col-md-6 col-md-6 text-right">
                        <h1 data-aos="fade-up" class=" make_left_en" style="color:black !important;" ><?php echo e(trans('main_trans.Main_title')); ?></h1>
                        <p data-aos="fade-up" class=" make_left_en"
                            style="color:black !important; font-size: 18px !important; padding-top: 16px;">
                            <?php if(App::getLocale() == 'en'): ?>
                                <?php if($aboutus->aboutus_en != ''): ?>
                                    <td><?php echo e($aboutus->aboutus_en); ?></td>
                                <?php else: ?>
                                    <td><?php echo e($aboutus->aboutus_ar); ?></td>
                                <?php endif; ?>
                            <?php else: ?>
                                <?php if($aboutus->aboutus_ar != ''): ?>
                                    <td><?php echo e($aboutus->aboutus_ar); ?></td>
                                <?php else: ?>
                                    <td><?php echo e($aboutus->aboutus_en); ?></td>
                                <?php endif; ?>
                            <?php endif; ?>
                        </p>
                        <button class="button-about"><a
                                href="front/aboutus"><?php echo e(trans('front_trans.show_more')); ?></a></button>
                    </div>

                    <div class="col-sx-12 col-sm-12 col-md-6 col-md-6 dania " data-aos="fade-up">
                        <div class="col-12">
                            <div class="row">
                                <div class=" col-xs-12 col-sm-12 col-md-4 col-lg-4  order-1 img-about" data-aos="flip-left"
                                    data-aos-easing="ease-out-cubic" data-aos-duration="2000">
                                    <img src="<?php echo e(asset('image/about2.jpg')); ?>"
                                        class="img-fluid appear-animation animated fadeInLeftShorter appear-animation-visible"
                                        data-apper-animation="fadeInLeftShorter" data-apper-animation-delay="3000" alt
                                        style="animation-delay: 3000ms; width:100%;">
                                </div>
                                <div class="col-xs-12 col-sm-12 col-md-4 col-lg-4 order-3 order-xl-2">
                                    <div
                                        class="h-100 d-flex align-items-center position-relative px-4 py-4 py-xl-0 mt-4 mt-xl-0">
                                        <svg class="custom-square-1 custom-square-top-right z-index-0" width="80"
                                            height="80">
                                            <rect
                                                class="lineProgressFrom appear-animation animated lineProgressTo appear-animation-visible"
                                                data-apper-animation="lineProgressTo" data-apper-animation-duration="3s"
                                                width="80" height="80" fill="none" stroke-width="13" stroke="#000"
                                                style="animation-duration: 3s; animation-delay: 100ms;">

                                            </rect>

                                        </svg>
                                        <svg class="custom-square-1 custom-square-1-no-pos z-index-0" width="100%"
                                            height="100%">
                                            <rect
                                                class="lineProgressAndFillFrom appear-animation animated lineProgressAndFillTo appear-animation-visible"
                                                data-apper-animation="lineProgressAndFillTo"
                                                data-apper-animation-duration="3s" width="100%" height="100%" fill="none"
                                                stroke-width="13" stroke="#000"
                                                style="animation-duration: 3s; animation-delay: 100ms;">

                                            </rect>
                                        </svg>
                                        <p
                                            class="Font_01 text-color-light line-height-9 text-center text-4  custom-responsive-text-size-1 mb-0 px-2 para-square">
                                            <?php echo e($aboutus->experience_year); ?> <?php echo e(trans('front_trans.about1')); ?>

                                            <?php echo e($aboutus->previous_project); ?> <?php echo e(trans('front_trans.about2')); ?>

                                            <?php echo e($aboutus->client); ?> <?php echo e(trans('front_trans.clients')); ?>

                                        </p>
                                    </div>
                                </div>

                                <div class="col-xs-12 col-sm-12 col-md-4 col-lg-4 order-2 order-xl-3 img-about"
                                    data-aos="flip-left" data-aos-easing="ease-out-cubic" data-aos-duration="2000">
                                    <img src="<?php echo e(asset('image/about2.jpg')); ?>"
                                        class="img-fluid appear-animation animated fadeInRightShorter appear-animation-visible"
                                        data-apper-animation="fadeInRightShorter" data-apper-animation-delay="3000" alt
                                        style="animation-delay: 3000ms;  width:100%;">
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
    <!--end about us-->


    <!--start our progects-->
    <div class="ourprojects text-center">
        <div class="container py-4">
            <h3 data-aos="fade-up"><?php echo e(trans('front_trans.our projects')); ?></h3>
            <p data-aos="fade-up"><?php echo e(trans('front_trans.Available projects')); ?></p>
            <div class="row mt-3 mb-5">

                <?php $latest_properties = App\Models\Property::where('status', 'for_sale')
                ->orderBy('id', 'desc')
                ->limit(3)
                ->get(); ?>

                <?php $__currentLoopData = $latest_properties; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $latest_property): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-xs-12 col-sm-12 col-md-4 col-lg-4">
                        <a>
                            <div class="ui-card">
                                <img src="<?php echo e(url('/image/photo/' . $latest_property->photo)); ?>"
                                    style="width: 100%; height:215.45px;">
                                <span class="thumb-info-title">
                                    <span class="Font_01 Font_Clean thumb-info-inner pb-3">
                                        <?php if(App::getLocale() == 'en'): ?>
                                            <?php if($latest_property->title_en != ''): ?>
                                                <td><?php echo e(\Str::limit($latest_property->title_en, 25)); ?></td>
                                            <?php else: ?>
                                                <td><?php echo e(\Str::limit($latest_property->title_ar, 25)); ?></td>
                                            <?php endif; ?>
                                        <?php else: ?>
                                            <?php if($latest_property->title_ar != ''): ?>
                                                <td><?php echo e(\Str::limit($latest_property->title_ar, 25)); ?></td>
                                            <?php else: ?>
                                                <td><?php echo e(\Str::limit($latest_property->title_en, 25)); ?></td>
                                            <?php endif; ?>
                                        <?php endif; ?>
                                    </span>
                                </span>
                                <div class="description text-center">
                                    <a href="/show_properties/<?php echo e($latest_property->title_en); ?>"><i
                                            class="fas fa-plus"></i></a>
                                </div>
                            </div>
                        </a>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            <button class="button-about"><a
                    href="<?php echo e(route('available_projects')); ?>"><?php echo e(trans('front_trans.show_more')); ?></a></button>
        </div>
    </div>
    <!--end our projects-->


    <!--start prev projects-->
    <div class="prev-project py-4 text-center">
        <h4 data-aos="fade-down"><?php echo e(trans('front_trans.previous_projects')); ?></h4>
        <h1 data-aos="fade-down"  style="color:black !important;"><?php echo e(trans('front_trans.Our previous work')); ?></h1>

        <div class="prev-card  py-4">
            <div class="container py-4">
                <div class="row">
                    <?php $previous_projects = \App\Models\Property::where('status', 'sold')
                    ->orderBy('id', 'desc')
                    ->paginate(3); ?>
                    <?php $__currentLoopData = $previous_projects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $previous_project): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-md-4">
                            <div class="ui-card text-center">
                                <img src="<?php echo e(url('/image/photo/' . $previous_project->photo)); ?>"
                                    style="width: 100%; height:330px; ">
                                <div class="description text-center">
                                    <a href="/show_properties/<?php echo e($previous_project->title_en); ?>" class="text-center">
                                        <h3 style="text-align: center">
                                            <?php if(App::getLocale() == 'en'): ?>
                                                <?php if($previous_project->title_en != ''): ?>
                                                    <td><?php echo e(\Str::limit($previous_project->title_en, 28)); ?></td>
                                                <?php else: ?>
                                                    <td><?php echo e(\Str::limit($previous_project->title_ar, 28)); ?></td>
                                                <?php endif; ?>
                                            <?php else: ?>
                                                <?php if($previous_project->title_ar != ''): ?>
                                                    <td><?php echo e(\Str::limit($previous_project->title_ar, 28)); ?></td>
                                                <?php else: ?>
                                                    <td><?php echo e(\Str::limit($previous_project->title_en, 25)); ?></td>
                                                <?php endif; ?>
                                            <?php endif; ?>
                                        </h3>
                                    </a>
                                    <p class="text-center">
                                        <?php if(App::getLocale() == 'en'): ?>
                                            <?php if($previous_project->description_en != ''): ?>
                                                <td><?php echo e(\Str::limit($previous_project->description_en, 280)); ?></td>
                                            <?php else: ?>
                                                <td><?php echo e(\Str::limit($previous_project->description_ar, 280)); ?></td>
                                            <?php endif; ?>
                                        <?php else: ?>
                                            <?php if($previous_project->description_ar != ''): ?>
                                                <td><?php echo e(\Str::limit($previous_project->description_ar, 280)); ?></td>
                                            <?php else: ?>
                                                <td><?php echo e(\Str::limit($previous_project->description_en, 280)); ?></td>
                                            <?php endif; ?>
                                        <?php endif; ?>
                                    </p>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
                <div class="m-t-30 m-b-60 center" style="margin-right: 50%;">
                    <?php echo e($previous_projects->links()); ?>

                </div>
            </div>
        </div>
        <button class="text-center"><a href="<?php echo e(route('previous_projects')); ?>"
                style="color: #D19200 !important; text-decoration: none;"><?php echo e(trans('front_trans.show_more')); ?></a></button>
    </div>
    <!--end prev projects-->



    <!-- start   why choose us-->
    <div class="choose-us py-4 text-center">
        <?php $about_us = \App\Models\Front\Aboutus::all(); ?>
        <?php $__currentLoopData = $about_us; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $aboutus): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="container py-4">
                <h3 data-aos="fade-up"><?php echo e(trans('front_trans.what distinguishes us')); ?></h3>
                <h1 data-aos="fade-up"><?php echo e(trans('front_trans.whyus')); ?></h1>
                <p>
                    <?php if(App::getLocale() == 'en'): ?>
                        <?php if($aboutus->aboutus_en != ''): ?>
                            <td><?php echo e($aboutus->aboutus_en); ?></td>
                        <?php else: ?>
                            <td><?php echo e($aboutus->aboutus_ar); ?></td>
                        <?php endif; ?>
                    <?php else: ?>
                        <?php if($aboutus->aboutus_ar != ''): ?>
                            <td><?php echo e($aboutus->aboutus_ar); ?></td>
                        <?php else: ?>
                            <td><?php echo e($aboutus->aboutus_en); ?></td>
                        <?php endif; ?>
                    <?php endif; ?>
                </p>
            </div>
            <div class="choose-us-content">
                <div class="container">
                    <div class="row justify-content-center align-items-center">
                        <div class="  col-sm-6 col-sm-6 col-lg-3 col-xl-2 order-2 order-xl-1 mb-4 mb-lg-0">
                            <div class="choose-us-box">
                                <ul class="chooseimg1" data-target="li" data-interval="2500" data-speed="1000">
                                    <?php $__currentLoopData = $sliders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $slider): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php if($slider->type == '1'): ?>
                                            <li class="active">
                                                <div class="choose-pic"
                                                    style="background-image: url('<?php echo e(Url($slider->path)); ?>');">
                                                </div>
                                            </li>
                                        <?php endif; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>
                            </div>
                        </div>

                        <div class="   col-sm-6 col-lg-3 col-xl-2 order-3 order-xl-2 mb-4 mb-lg-0">
                            <div class="choose-us-box">
                                <ul class="chooseimg2" data-target="li" data-interval="2500" data-speed="1000">
                                    <?php $__currentLoopData = $sliders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $slider): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php if($slider->type == '1'): ?>
                                            <li class="active">
                                                <div class="choose-pic"
                                                    style="background-image: url('<?php echo e(Url($slider->path)); ?>');">
                                                </div>
                                            </li>
                                        <?php endif; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>
                            </div>
                        </div>

                        <div class="  col-lg-8 col-xl-4 order-1 order-xl-3 mx-lg-5 mx-xl-0 mb-5">
                            <div class="choose-us-box choose-center">
                                <div class="swiper-container choose-swiper">
                                    <div class="swiper-wrapper">
                                        <div class="swiper-slide">
                                            <div class="contents text-center">
                                                <h4 class="text-center"><?php echo e($aboutus->experience_year); ?></h4>
                                                <h5><?php echo e(trans('front_trans.experience_year')); ?></h5>
                                            </div>
                                        </div>
                                        <div class="swiper-slide">
                                            <h4 class="text-center"><?php echo e($aboutus->previous_project); ?></h4>
                                            <h5><?php echo e(trans('front_trans.previous_project')); ?></h5>
                                        </div>
                                        <div class="swiper-slide">
                                            <h4 class="text-center"><?php echo e($aboutus->under_construction); ?></h4>
                                            <h5><?php echo e(trans('front_trans.under_construction')); ?></h5>
                                        </div>
                                        <div class="swiper-slide">
                                            <h4 class="text-center"><?php echo e($aboutus->client); ?></h4>
                                            <h5><?php echo e(trans('front_trans.client')); ?></h5>
                                        </div>
                                    </div>
                                    <button><a href="<?php echo e(route('front/aboutus')); ?>"
                                            style="color: black; text-decoration: none;"><?php echo e(trans('front_trans.show_more')); ?></a></button>
                                    <div class="swiper-pagination"></div>
                                    <div class="swiper-button-prev"></div>
                                    <div class="swiper-button-next"></div>
                                </div>
                            </div>
                        </div>
                        <div class="col-sm-6 col-lg-3 col-xl-2 order-4 order-xl-4 mb-4 mb-sm-0">
                            <div class="choose-us-box">
                                <ul class="chooseimg3" data-target="li" data-interval="2500" data-speed="1000">
                                    <?php $__currentLoopData = $sliders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $slider): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php if($slider->type == '1'): ?>
                                            <li class="active">
                                                <div class="choose-pic"
                                                    style="background-image: url('<?php echo e(Url($slider->path)); ?>');">
                                                </div>
                                            </li>
                                        <?php endif; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>
                            </div>
                        </div>
                        <div class="   col-sm-6 col-lg-3 col-xl-2 order-5 order-xl-5 mb-4 mb-sm-0">
                            <div class="choose-us-box">
                                <ul class="chooseimg4" data-target="li" data-interval="2500" data-speed="1000">
                                    <?php $__currentLoopData = $sliders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $slider): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php if($slider->type == '1'): ?>
                                            <li class="active">
                                                <div class="choose-pic"
                                                    style="background-image: url('<?php echo e(Url($slider->path)); ?>');">
                                                </div>
                                            </li>
                                        <?php endif; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
    <!-- end  why choose us-->


    <?php $news = \App\Models\News::paginate(3); ?>
    <!--start latest news-->
    <div class="latest-news py-4 text-center">
        <h3 class=" text-center" data-aos="fade-up"><?php echo e(trans('front_trans.company_news')); ?></h3>
        
        <div class="container py-4">
            <div class="row py-4 text-right">
                <?php $__currentLoopData = $news; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $new): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-md-4 py-4 make_left_en">
                        <div class="card-body card" data-aos="flip-left" data-aos-easing="ease-out-cubic"
                            data-aos-duration="2000">
                            <h4>
                                <a href="/show_news/<?php echo e($new->head_en); ?>" style="color: orange">
                                    <?php if(App::getLocale() == 'en'): ?>
                                        <?php if($new->head_en != ''): ?>
                                            <th><?php echo e(\Str::limit($new->head_en, 100)); ?></th>
                                        <?php else: ?>
                                            <th><?php echo e(\Str::limit($new->head_ar, 100)); ?></th>
                                        <?php endif; ?>
                                    <?php else: ?>
                                        <th><?php echo e(\Str::limit($new->head_ar, 100)); ?></th>
                                    <?php endif; ?>
                                </a>
                            </h4>
                            <p>
                                <?php if(App::getLocale() == 'en'): ?>
                                    <?php if($new->body_en != ''): ?>
                                        <th><?php echo e(\Str::limit($new->body_en, 200)); ?></th>
                                    <?php else: ?>
                                        <th><?php echo e(\Str::limit($new->body_ar, 200)); ?></th>
                                    <?php endif; ?>
                                <?php else: ?>
                                    <th><?php echo e(\Str::limit($new->body_ar, 200)); ?></th>
                                <?php endif; ?>
                            </p>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                
            </div>
        </div>
        <button class="text-center"><a href="<?php echo e(route('news')); ?>"
                style="color: #D19200; text-decoration: none;"><?php echo e(trans('front_trans.show_more')); ?></a></button>
    </div>
    <!--end latest news-->

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.mainlayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\4FARH\OneDrive\Desktop\(M-F) Real Estate\resources\views/home.blade.php ENDPATH**/ ?>