<!-- Footer opened -->

<!-- Footer closed -->
<?php /**PATH C:\Users\4FARH\OneDrive\Desktop\World\resources\views/layouts/footer.blade.php ENDPATH**/ ?>