<!DOCTYPE html>
<html lang="zxx" class="no-js">

<head>
    <?php echo $__env->make('layouts.partials.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</head>

<body>
    <?php echo $__env->make('layouts.partials.nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="row">
        <div class="col-12">
            <?php echo $__env->make('layouts.partials.flash', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
    </div>




    <!--start title-->
    <div class="title-nav py-4 make_right_ar">
        <div class="container">
            <h2><?php echo e(trans('front_trans.Available projects')); ?></h2>
        </div>
    </div>
    <!--end title-->
    <!--start lines-->
    <div class="line">
        <div class="line2">
        </div>
    </div>
    <!--end lines-->

    <!--start our projects section-->
    <!--start card section-->
    <div class="cards-section latest-news-cards py-4">
        <div class="container">
            <div class="row text-center py-4">

                <?php $__currentLoopData = $available_projects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $available_project): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-xs-12 col-sm-12 col-md-4 col-lg-4" style="width: ">
                        <div class="card news-cards cards-right-side">
                            <div class="ui-card latest-ui-card">
                                <img src="<?php echo e(url('/image/photo/'.$available_project->photo)); ?>">
                                <div class="description text-center">
                                    <a href="/show_properties/<?php echo e($available_project->title_en); ?>"><i class="fas fa-link"></i></a>
                                </div>
                            </div>
                            <div class="card-body card-text1">
                                <p class="calendar"><i class="fas fa-calendar-week"></i> <?php echo e($available_project->created_at->diffForHumans()); ?></p>
                                <h5 class="card-title">
                                    <?php if(App::getLocale() == 'en'): ?>
                                        <?php if($available_project->title_en !=''): ?>
                                            <td><?php echo e(\Str::limit($available_project->title_en, 25)); ?></td>
                                        <?php else: ?>
                                            <td><?php echo e(\Str::limit($available_project->title_ar, 25)); ?></td>
                                        <?php endif; ?>
                                    <?php else: ?>
                                        <?php if($available_project->title_ar !=''): ?>
                                            <td><?php echo e(\Str::limit($available_project->title_ar, 25)); ?></td>
                                        <?php else: ?>
                                            <td><?php echo e(\Str::limit($available_project->title_en, 25)); ?></td>
                                        <?php endif; ?>
                                    <?php endif; ?>
                                </h5>
                                <p class="card-text">
                                    <?php if(App::getLocale() == 'en'): ?>
                                        <?php if($available_project->description_en !=''): ?>
                                            <td><?php echo e(\Str::limit($available_project->description_en, 280)); ?></td>
                                        <?php else: ?>
                                            <td><?php echo e(\Str::limit($available_project->description_ar, 280)); ?></td>
                                        <?php endif; ?>
                                    <?php else: ?>
                                        <?php if($available_project->description_ar !=''): ?>
                                            <td><?php echo e(\Str::limit($available_project->description_ar, 280)); ?></td>
                                        <?php else: ?>
                                            <td><?php echo e(\Str::limit($available_project->description_en, 280)); ?></td>
                                        <?php endif; ?>
                                    <?php endif; ?>
                                </p>
                                <a href="/show_properties/<?php echo e($available_project->title_en); ?>" class="btn btn-primary"><?php echo e(trans('front_trans.show_details')); ?></a>
                            </div>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            <div class="m-t-30 m-b-60 center" style="margin-right: 50%;">
                <?php echo e($available_projects->links()); ?>

            </div>
        </div>
    </div>
    <!--end card section-->
    <!--end our projects section-->








    <?php echo $__env->make('layouts.partials.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('layouts.partials.footer-scripts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

</body>

</html>
<?php /**PATH /home/dbsc4c7x1fsq/a_raptors_egypt/resources/views/includes/sitepages/available_projects.blade.php ENDPATH**/ ?>