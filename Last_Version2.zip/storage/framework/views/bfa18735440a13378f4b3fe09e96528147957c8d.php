<!DOCTYPE html>
<html lang="zxx" class="no-js">

<head>
    <?php echo $__env->make('layouts.partials.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</head>

<body>
    <?php echo $__env->make('layouts.partials.nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="row">
        <div class="col-12">
            <?php echo $__env->make('layouts.partials.flash', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
    </div>


    <!--start title-->
    <div class="title-nav py-4 make_right_ar">
        <div class="container">
            <h2><?php echo e(trans('front_trans.company_jobs')); ?></h2>
        </div>
    </div>
    <!--end title-->
    <!--start lines-->
    <div class="line">
        <div class="line2 line-2-about line-3-search line-4-images">
        </div>
    </div>
    <!--end lines-->




    <?php
        $annoncements = \App\Models\Company_Job::where('type', 'Annoncement')->get();
        $job_titles   = \App\Models\Company_Job::where('type', 'Job Title')->get();
        $job_emails   = \App\Models\Company_Job::where('type', 'Job E-Mail')->get();
    ?>




    <!-- start jops section -->
    <div class="jops-section py-4">
        <div class="container">
            <div class="row py-4">
                <div class="col-xs-12 col-sm-12 col-md-6 col-lg-6 make_right_ar">
                    <h1><?php echo e(trans('front_trans.jobs')); ?></h1>

                        <?php $__currentLoopData = $annoncements; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $annoncement): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($annoncement->status =='0'): ?>
                                <div class="line line-4"></div>
                                <p>
                                    <?php if(App::getLocale() == 'en'): ?>
                                        <?php if($annoncement->title_en !=''): ?>
                                            <th><?php echo e(\Str::limit($annoncement->title_en,100)); ?></th>
                                        <?php else: ?>
                                            <th><?php echo e(\Str::limit($annoncement->title_ar,100)); ?></th>
                                        <?php endif; ?>
                                    <?php else: ?>
                                        <th><?php echo e(\Str::limit($annoncement->title_ar,100)); ?></th>
                                    <?php endif; ?>
                                </p>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>



                    <h1 class="py-4"><?php echo e(trans('front_trans.available_jobs')); ?></h1>
                        <div class="line line-4"></div>
                         <?php $__currentLoopData = $job_titles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $job_title): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($job_title->status =='0'): ?>
                                
                                <p>
                                    <?php if(App::getLocale() == 'en'): ?>
                                        <?php if($job_title->title_en !=''): ?>
                                            <th><?php echo e(\Str::limit($job_title->title_en,100)); ?></th>
                                        <?php else: ?>
                                            <th><?php echo e(\Str::limit($job_title->title_ar,100)); ?></th>
                                        <?php endif; ?>
                                    <?php else: ?>
                                        <th><?php echo e(\Str::limit($job_title->title_ar,100)); ?></th>
                                    <?php endif; ?>
                                </p>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>






                    <h1 class="py-4"><?php echo e(trans('front_trans.job_email')); ?></h1>
                        <div class="line line-4"></div>
                        <?php $__currentLoopData = $job_emails; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $job_email): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($job_email->status =='0'): ?>
                                
                                <p>
                                    <?php if(App::getLocale() == 'en'): ?>
                                        <?php if($job_email->title_en !=''): ?>
                                            <th><?php echo e(\Str::limit($job_email->title_en,100)); ?></th>
                                        <?php else: ?>
                                            <th><?php echo e(\Str::limit($job_email->title_ar,100)); ?></th>
                                        <?php endif; ?>
                                    <?php else: ?>
                                        <th><?php echo e(\Str::limit($job_email->title_ar,100)); ?></th>
                                    <?php endif; ?>
                                </p>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </div>
                <div class="col-xs-12 col-sm-12 col-md-6 col-lg-6">
                    <h1 class="make_right_ar"><?php echo e(trans('front_trans.join')); ?></h1>
                    <div class="line line-4"></div>

                        <?php echo Form::open(['route' => 'jobs/send_cv', 'method' => 'post', 'files'=>true ]); ?>

                            <div class="contact-form-text">
                                <?php echo Form::text('name', old('name'), ['placeholder' => trans('contactus_trans.Name')]); ?>


                                <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><span class="text-danger"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="contact-form-text">
                                <?php echo Form::email('email', old('email'), ['placeholder' => trans('contactus_trans.email')]); ?>

                                <?php echo Form::text('mobile', old('mobile'), ['placeholder' => trans('front_trans.mobile')]); ?>

                            </div>
                            <div class="contact-form-text">
                                <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><span class="text-danger"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                <?php $__errorArgs = ['mobile'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><span class="text-danger"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="contact-form-text">
                                <?php echo Form::text('job_title', old('job_title'), ['placeholder' => trans('contactus_trans.subject')]); ?>

                                <?php $__errorArgs = ['job_title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><span class="text-danger"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="contact-form-text">
                                <?php echo Form::file('file',['placeholder' => trans('contactus_trans.message')]); ?>

                                <?php $__errorArgs = ['file'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><span class="text-danger"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            
                            <div class="text-center">
                                <?php echo Form::button(trans('contactus_trans.send_message'), ['type' => 'submit']); ?>

                            </div>
                        <?php echo Form::close(); ?>

                    </form>
                </div>
            </div>
        </div>
    </div>
    <!-- end jops section -->








    <?php echo $__env->make('layouts.partials.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('layouts.partials.footer-scripts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

</body>

</html>
<?php /**PATH /home/dbsc4c7x1fsq/a_raptors_egypt/resources/views/includes/sitepages/job_seeker.blade.php ENDPATH**/ ?>