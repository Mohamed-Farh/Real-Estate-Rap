<!DOCTYPE html>
<html lang="zxx" class="no-js">

<head>
    <?php echo $__env->make('layouts.partials.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</head>

<body>
    <?php echo $__env->make('layouts.partials.nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="row">
        <div class="col-12">
            <?php echo $__env->make('layouts.partials.flash', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
    </div>

    <!--start title-->
    <div class="title-nav py-4  make_right_ar">
        <div class="container">
            <h2><?php echo e(trans('front_trans.look_for_property')); ?></h2>
        </div>
    </div>
    <!--end title-->

    <!--start lines-->
    <div class="line">
        <div class="line2 line-2-about line-3-search">
        </div>
    </div>
    <!--end lines-->

    <!--start paragraph section-->
    <div class="paragraph-search py-4 text-right">
        <div class="container">
        </div>
    </div>
    <!--end paragraph section-->



    <!--start search info-->
    <div class="search-info py-4">
        <div class="container">
            <div class="row">
                <div class="colxs-12 col-sm-12 col-md-6 col-lg-6">
                    <img src="<?php echo e(asset('app-assets/images/home-inspection.jpg')); ?>" />
                </div>

                



                <div class="colxs-12 col-sm-12 col-md-6 col-lg-6">
                    <?php echo Form::open(['route' => '/home/search', 'method' => 'get'], ['class' => 'search-form'] ); ?>


                        <div class="form-group">
                            <?php echo Form::text('keyword', old('keyword', request()->input('keyword')), ['class' => 'contact-form-text', 'placeholder' => trans('front_trans.type_word')]); ?>

                        </div>

                        <?php
                            $category_ar = \App\Models\Category::orderBy('id', 'desc')->pluck('name_ar', 'id');
                            $category_en = \App\Models\Category::orderBy('id', 'desc')->pluck('name_en', 'id');
                        ?>

                        <div class="form-group">
                            <?php if(App::getLocale() == 'en'): ?>
                                <?php echo Form::text('city_en', old('city_en', request()->input('city_en')), ['class' => 'contact-form-text', 'placeholder' => 'Search City Here']); ?>

                            <?php else: ?>
                                <?php echo Form::text('city_ar', old('city_ar', request()->input('city_ar')), ['class' => 'contact-form-text', 'placeholder' => 'بحث بالمدينة']); ?>

                            <?php endif; ?>
                        </div>

                        <div class="form-group">
                            <?php if(App::getLocale() == 'en'): ?>
                                <?php echo Form::text('address_en', old('address_en', request()->input('address_en')), ['class' => 'contact-form-text', 'placeholder' => 'Search Address Here']); ?>

                            <?php else: ?>
                                <?php echo Form::text('address_ar', old('address_ar', request()->input('address_ar')), ['class' => 'contact-form-text', 'placeholder' => 'بحث بالحي']); ?>

                            <?php endif; ?>
                        </div><br>


                        <div class="form-group">
                            <?php echo Form::hidden('price', trans('front_trans.price')); ?>

                            <?php echo Form::text('min_price', old('min_price'), ['class' => 'contact-form-text', 'placeholder' => trans('front_trans.min_price')]); ?>

                            <?php echo Form::text('max_price', old('max_price'), ['class' => 'contact-form-text', 'placeholder' => trans('front_trans.max_price')]); ?>

                        </div><br>

                        <div class="form-group">
                            <?php echo Form::hidden('size', trans('front_trans.size')); ?>

                            <?php echo Form::text('min_size', old('min_size'), ['class' => 'contact-form-text', 'placeholder' => trans('front_trans.min_size')]); ?>

                            <?php echo Form::text('max_size', old('max_size'), ['class' => 'contact-form-text', 'placeholder' => trans('front_trans.max_size')]); ?>

                        </div>

                        

                        <div class="form-group">
                            <?php echo Form::button(trans('front_trans.search_here'), ['class' => 'text-center', 'type' => 'submit']); ?>

                        </div>

                    <?php echo Form::close(); ?>

                </div>



            </div>
            <div class="emails-section py-4  make_right_ar">
                <?php $Facebooks = \App\Models\Social::where('type', 'Facebook')->get(); ?>
                <h1 class="py-4"><?php echo e(trans('contactus_trans.email')); ?></h1>
                <div class="line line-4"></div>
                <p>sales@raptorsegypt.com</p>
                <p>hr@raptorsegypt.com</p>
                <p>info@raptorsegypt.com</p>

                
            </div>
        </div>
    </div>
    <!--end search info-->









    <?php echo $__env->make('layouts.partials.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('layouts.partials.footer-scripts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

</body>

</html>
<?php /**PATH /home/dbsc4c7x1fsq/a_raptors_egypt/resources/views/includes/sitepages/home_search.blade.php ENDPATH**/ ?>