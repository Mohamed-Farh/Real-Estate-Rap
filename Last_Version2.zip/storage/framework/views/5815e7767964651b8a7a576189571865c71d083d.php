<?php $__env->startSection('css'); ?>
    <?php echo toastr_css(); ?>

<?php $__env->startSection('title'); ?>
    <?php echo e(trans('front_trans.aboutus')); ?>

<?php $__env->stopSection(); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('page-header'); ?>
<!-- breadcrumb -->
<?php $__env->startSection('PageTitle'); ?>
<?php echo e(trans('front_trans.aboutus')); ?>

<?php $__env->stopSection(); ?>
<!-- breadcrumb -->
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<!-- row -->
<div class="row">

<div class="col-xl-12 mb-30">
    <div class="card card-statistics h-100">
        <div class="card-body">

            <?php if($errors->any()): ?>
                <div class="alert alert-danger">
                    <ul>
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><?php echo e($error); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
            <?php endif; ?>


            <?php
            $about_us = \App\Models\Front\Aboutus::all();
            $aboutus_count = \App\Models\Front\Aboutus::all()->count();
            ?>


            <?php if($aboutus_count == '0'): ?>
                <button type="button" class="button x-small">
                    <a href="<?php echo e(route('aboutus.create')); ?>"><?php echo e(trans('front_trans.add')); ?></a>
                </button>
                <br><br>
            <?php endif; ?>

            <!--start about us section-->
            <?php $__currentLoopData = $about_us; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $aboutus): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if($aboutus_count != '0'): ?>
                    <button type="button" class="button x-small">
                        <a href="<?php echo e(route('aboutus.edit', $aboutus->id)); ?>"><?php echo e(trans('front_trans.Edit')); ?></a>
                    </button>
                <?php endif; ?>


                <br><br>
                <div class="row ">
                    <div class="col-12">
                        <h2 data-aos="fade-left" class="about-head"><?php echo e(trans('front_trans.aboutus')); ?></h2>
                        <p data-aos="fade-left" class="about-parag">
                            <?php if(App::getLocale() == 'en'): ?>
                                <?php if($aboutus->aboutus_en != ''): ?>
                                    <td><?php echo e($aboutus->aboutus_en); ?></td>
                                <?php else: ?>
                                    <td><?php echo e($aboutus->aboutus_ar); ?></td>
                                <?php endif; ?>
                            <?php else: ?>
                                <?php if($aboutus->aboutus_ar != ''): ?>
                                    <td><?php echo e($aboutus->aboutus_ar); ?></td>
                                <?php else: ?>
                                    <td><?php echo e($aboutus->aboutus_en); ?></td>
                                <?php endif; ?>
                            <?php endif; ?>
                        </p>
                    </div>
                </div>

                <!--end about us section-->
                <!--start counter section-->
                <div class="counter-sec py-4 text-center">
                    <div class="container">
                        <div class="row about-counting">
                            <div class="col-xs-12 col-sm-12 col-md-6 col-lg-3">
                                <i class="fas fa-clock text-9 text-color-light mb-3 mt-2"></i>
                                <div>
                                    <span class="counter"><?php echo e($aboutus->experience_year); ?></span>
                                </div>
                                <div>
                                    <p><?php echo e(trans('front_trans.experience_year')); ?></p>
                                </div>
                            </div>
                            <div class="col-xs-12 col-sm-12 col-md-6 col-lg-3">
                                <i class="fas fa-home text-9 text-color-light mb-3 mt-2"></i>
                                <div>
                                    <span class="counter"><?php echo e($aboutus->previous_project); ?></span>
                                </div>
                                <div>
                                    <p><?php echo e(trans('front_trans.previous_project')); ?></p>
                                </div>
                            </div>
                            <div class="col-xs-12 col-sm-12 col-md-6 col-lg-3">
                                <i class="fas fas fa-hourglass-half text-9 text-color-light mb-3 mt-2"></i>
                                <div>
                                    <span class="counter"><?php echo e($aboutus->under_construction); ?></span>
                                </div>
                                <div>
                                    <p><?php echo e(trans('front_trans.under_construction')); ?></p>
                                </div>
                            </div>
                            <div class="col-xs-12 col-sm-12 col-md-6 col-lg-3">
                                <i class="fas fa-users text-9 text-color-light mb-3 mt-2"></i>
                                <div>
                                    <span class="counter"><?php echo e($aboutus->client); ?></span>
                                </div>
                                <div>
                                    <p><?php echo e(trans('front_trans.client')); ?></p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <!--end counter section-->
                <!--start last section-->
                <div class="row">
                    <div class="col-xs-12 col-sm-12 col-md-4 col-lg-4">
                        <div class="card prevs-cards text-center last-card-1">
                            <div class="card-body  ">
                                <h5 class="card-title about-head"><?php echo e(trans('front_trans.whyus')); ?></h5>
                                <p class="card-text about-parag1">
                                    <?php if(App::getLocale() == 'en'): ?>
                                        <?php if($aboutus->whyus_en != ''): ?>
                                            <td><?php echo e($aboutus->whyus_en); ?></td>
                                        <?php else: ?>
                                            <td><?php echo e($aboutus->whyus_ar); ?></td>
                                        <?php endif; ?>
                                    <?php else: ?>
                                        <?php if($aboutus->whyus_ar != ''): ?>
                                            <td><?php echo e($aboutus->whyus_ar); ?></td>
                                        <?php else: ?>
                                            <td><?php echo e($aboutus->whyus_en); ?></td>
                                        <?php endif; ?>
                                    <?php endif; ?>
                                </p>
                            </div>
                        </div>
                    </div>
                    <div class="col-xs-12 col-sm-12 col-md-4 col-lg-4">
                        <div class="card prevs-cards text-center last-card-1">
                            <div class="card-body  ">
                                <h5 class="card-title about-head"><?php echo e(trans('front_trans.vision')); ?></h5>
                                <p class="card-text about-parag1">
                                    <?php if(App::getLocale() == 'en'): ?>
                                        <?php if($aboutus->vision_en != ''): ?>
                                            <td><?php echo e($aboutus->vision_en); ?></td>
                                        <?php else: ?>
                                            <td><?php echo e($aboutus->vision_ar); ?></td>
                                        <?php endif; ?>
                                    <?php else: ?>
                                        <?php if($aboutus->vision_ar != ''): ?>
                                            <td><?php echo e($aboutus->vision_ar); ?></td>
                                        <?php else: ?>
                                            <td><?php echo e($aboutus->vision_en); ?></td>
                                        <?php endif; ?>
                                    <?php endif; ?>
                                </p>
                            </div>
                        </div>
                    </div>
                    <div class="col-xs-12 col-sm-12 col-md-4 col-lg-4">
                        <div class="card prevs-cards text-center last-card-1">

                            <div class="card-body  ">
                                <h6 class="card-title about-head2"><?php echo e(trans('front_trans.message')); ?></h6>
                                <p class="card-text about-parag1">
                                    <?php if(App::getLocale() == 'en'): ?>
                                        <?php if($aboutus->message_en != ''): ?>
                                            <td><?php echo e($aboutus->message_en); ?></td>
                                        <?php else: ?>
                                            <td><?php echo e($aboutus->message_ar); ?></td>
                                        <?php endif; ?>
                                    <?php else: ?>
                                        <?php if($aboutus->message_ar != ''): ?>
                                            <td><?php echo e($aboutus->message_ar); ?></td>
                                        <?php else: ?>
                                            <td><?php echo e($aboutus->message_en); ?></td>
                                        <?php endif; ?>
                                    <?php endif; ?>
                                </p>
                            </div>
                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <!--end last section-->
        </div>
    </div>
</div>


<!-- row closed -->
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
<?php echo toastr_js(); ?>
<?php echo app('toastr')->render(); ?>

<script type="text/javascript">
    $(document).ready(function() {
        $('.summernote').summernote({
            tabSize: 2,
            height: 100,
        });
        $("#summernote").code()
            .replace(/<\/p>/gi, "\n")
            .replace(/<br\/?>/gi, "\n")
            .replace(/<\/?[^>]+(>|$)/g, "");
    });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/dbsc4c7x1fsq/a_raptors_egypt/resources/views/pages/admin/aboutus/index.blade.php ENDPATH**/ ?>