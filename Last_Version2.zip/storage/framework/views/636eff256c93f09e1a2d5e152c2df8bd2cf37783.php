<?php $__env->startSection('css'); ?>
    <?php echo toastr_css(); ?>

    <style type="text/css">

        /*body {margin:2rem;}*/
        .modal-dialog {
              max-width: 800px;
              margin: 30px auto;
          }
        .modal-body {
          position:relative;
          padding:0px;
        }
        .close {
          position:absolute;
          right:-30px;
          top:0;
          z-index:999;
          font-size:2rem;
          font-weight: normal;
          color:#fff;
          opacity:1;
        }
    </style>
<?php $__env->startSection('title'); ?>
    <?php echo e(trans('property_trans.title_page')); ?>

<?php $__env->stopSection(); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('page-header'); ?>
<!-- breadcrumb -->
<?php $__env->startSection('PageTitle'); ?>
<?php echo e(trans('main_trans.Property')); ?>

<?php $__env->stopSection(); ?>
<!-- breadcrumb -->
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<!-- row -->
<div class="row">
<?php if($errors->any()): ?>
    <div class="error"><?php echo e($errors->first('Name')); ?></div>
<?php endif; ?>

<style type="text/css">

    /*body {margin:2rem;}*/
    .modal-dialog {
          max-width: 800px;
          margin: 30px auto;
      }
    .modal-body {
      position:relative;
      padding:0px;
    }
    .close {
      position:absolute;
      right:-30px;
      top:0;
      z-index:999;
      font-size:2rem;
      font-weight: normal;
      color:#fff;
      opacity:1;
    }
</style>

<div class="col-xl-12 mb-30">
    <div class="card card-statistics h-100">
        <div class="card-body">

            <?php if($errors->any()): ?>
                <div class="alert alert-danger">
                    <ul>
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><?php echo e($error); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
            <?php endif; ?>

            <div id="carouselExampleIndicators" class="carousel slide" data-ride="carousel">
                <ol class="carousel-indicators">
                    <li data-target="#carouselExampleIndicators" data-slide-to="0" class="active"></li>
                    <li data-target="#carouselExampleIndicators" data-slide-to="1"></li>
                    <li data-target="#carouselExampleIndicators" data-slide-to="2"></li>
                </ol>
                <div class="carousel-inner">
                    <div class="carousel-item active">
                        <img class="d-block w-100" src="<?php echo e(url('image/photo/' . $property->photo)); ?>" alt="first slide" style="width: 690px; height:600px;">
                    </div>
                    <?php $__currentLoopData = explode('|', $property->images); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="carousel-item">
                            <img class="d-block w-100" src="<?php echo e(url('image/' . $image)); ?>" alt="Second slide" style="width: 690px; height:600px;">
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
                <a class="carousel-control-prev" href="#carouselExampleIndicators" role="button" data-slide="prev">
                    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                    <span class="sr-only">Previous</span>
                </a>
                <a class="carousel-control-next" href="#carouselExampleIndicators" role="button" data-slide="next">
                    <span class="carousel-control-next-icon" aria-hidden="true"></span>
                    <span class="sr-only">Next</span>
                </a>
            </div>


            <div class="title_design">
                <?php if(App::getLocale() == 'en'): ?>
                    <?php if($property->title_en != ''): ?>
                        <h1 class="h1-space" style="color: white"><?php echo e($property->title_en); ?></h1>
                    <?php else: ?>
                        <h1 class="h1-space" style="color: white"><?php echo e($property->title_ar); ?></h1>
                    <?php endif; ?>
                <?php else: ?>
                    <h1 class="h1-space" style="color: white"><?php echo e($property->title_ar); ?></h1>
                <?php endif; ?>
            </div>

            <div class="row">
                <div class="col-8">
                    <img class="single_photo" src="<?php echo e(url('image/' . $image)); ?>" alt="Property Photo" style="width: 670px; height:540px;">
                </div>

                <div class="col-4">
                    <table class="table table-striped" style="padding-top: 20px;">
                        <tbody>
                            <tr>
                                <th></th>
                                <th><?php echo e(trans('property_trans.price')); ?></th>
                                <th><?php echo e($property->price); ?></th>
                            </tr>
                            <tr>
                                <th scope="row"></th>
                                <th><?php echo e(trans('property_trans.size')); ?></th>
                                <th><?php echo e($property->size); ?></th>
                            </tr>
                            <tr>
                                <th scope="row"></th>
                                <th><?php echo e(trans('property_trans.discount')); ?></th>
                                <th><?php echo e($property->discount); ?></th>
                            </tr>
                            <tr>
                                <th scope="row"></th>
                                <th><?php echo e(trans('property_trans.new_price')); ?></th>
                                <th><?php echo e($property->new_price); ?></th>
                            </tr>
                        </tbody>
                    </table>
                    <br>
                    <table class="table table-striped" style="padding-top: 20px;">
                        <tbody>
                            <tr>
                                <th></th>
                                <th><?php echo e(trans('property_trans.Used')); ?></th>
                                <th><?php echo e($property->used == 'used' ? trans('property_trans.used') : trans('property_trans.new')); ?>

                                </th>
                            </tr>
                            <tr>
                                <th></th>
                                <th><?php echo e(trans('property_trans.purpose')); ?></th>
                                <th><?php echo e($property->used == 'rent' ? trans('property_trans.rent') : trans('property_trans.sale')); ?>

                                </th>
                            </tr>
                            <tr>
                                <th scope="row"></th>
                                <th><?php echo e(trans('property_trans.floornumber')); ?></th>
                                <th><?php echo e($property->floornumber); ?></th>
                            </tr>
                            <tr>
                                <th scope="row"></th>
                                <th><?php echo e(trans('property_trans.bedroom')); ?></th>
                                <th><?php echo e($property->bedroom); ?></th>
                            </tr>
                            <tr>
                                <th scope="row"></th>
                                <th><?php echo e(trans('property_trans.bathroom')); ?></th>
                                <th><?php echo e($property->bathroom); ?></th>
                            </tr>
                            <tr>
                                <th scope="row"></th>
                                <th><?php echo e(trans('property_trans.no_of_floor')); ?></th>
                                <th><?php echo e($property->no_of_floor); ?></th>
                            </tr>
                        </tbody>
                    </table>
                    <br>
                    <table class="table table-striped" style="padding-top: 20px;">
                        <tbody>

                            <tr>
                                <th></th>
                                <th><?php echo e(trans('property_trans.category_id')); ?></th>
                                <?php if(App::getLocale() == 'en'): ?>
                                    <?php if($property->category->name_en !=''): ?>
                                        <th><?php echo e(\Str::limit($property->category->name_en,25)); ?></th>
                                    <?php else: ?>
                                        <th><?php echo e(\Str::limit($property->category->name_ar,25)); ?></th>
                                    <?php endif; ?>
                                <?php else: ?>
                                    <th><?php echo e(\Str::limit($property->category->name_ar,25)); ?></th>
                                <?php endif; ?>

                            <tr>

                            <tr>
                                <th></th>
                                <th><?php echo e(trans('property_trans.city')); ?></th>
                                <?php if(App::getLocale() == 'en'): ?>
                                    <?php if($property->city_en != ''): ?>
                                        <th><?php echo e($property->city_en); ?></th>
                                    <?php else: ?>
                                        <th><?php echo e($property->city_ar); ?></th>
                                    <?php endif; ?>
                                <?php else: ?>
                                    <th><?php echo e($property->city_ar); ?></th>
                                <?php endif; ?>
                            </tr>
                            <tr>
                                <th></th>
                                <th><?php echo e(trans('property_trans.address')); ?></th>
                                <?php if(App::getLocale() == 'en'): ?>
                                    <?php if($property->address_en != ''): ?>
                                        <th><?php echo e($property->address_en); ?></th>
                                    <?php else: ?>
                                        <th><?php echo e($property->address_ar); ?></th>
                                    <?php endif; ?>
                                <?php else: ?>
                                    <th><?php echo e($property->address_ar); ?></th>
                                <?php endif; ?>
                            </tr>
                        </tbody>
                    </table>

                    <?php if($property->video): ?>
                        <div class="col" style="text-align: center">
                            <!-- Button trigger modal -->
                            <button type="button" class="btn btn-primary video-btn primary-btn text-uppercase" data-toggle="modal" data-src="<?php echo e($property->video); ?>" data-target="#myModal">
                                <i class="fa fa-youtube"></i> Watch Video Of Property
                            </button>
                        </div>
                    <?php endif; ?>

            </div>



            <table class="table align-items-center table-flush small_space">
                <thead class="thead-dark">
                    <tr>
                        <th scope="col"><?php echo e(trans('property_trans.description')); ?></th>
                    </tr>
                </thead>
                <tbody>
                    <?php if(App::getLocale() == 'en'): ?>
                        <?php if($property->description_en != ''): ?>
                            <th><?php echo e($property->description_en); ?></th>
                        <?php else: ?>
                            <th><?php echo e($property->description_ar); ?></th>
                        <?php endif; ?>
                    <?php else: ?>
                        <th><?php echo e($property->description_ar); ?></th>
                    <?php endif; ?>
                </tbody>
            </table>

            <table class="table align-items-center table-flush space">
                <thead class="thead-dark">
                    <tr>
                        <th scope="col"><?php echo e(trans('property_trans.nearby')); ?></th>
                    </tr>
                </thead>
                <tbody>
                    <?php if(App::getLocale() == 'en'): ?>
                        <?php if($property->nearby_en != ''): ?>
                            <th><?php echo e($property->nearby_en); ?></th>
                        <?php else: ?>
                            <th><?php echo e($property->nearby_ar); ?></th>
                        <?php endif; ?>
                    <?php else: ?>
                        <th><?php echo e($property->nearby_ar); ?></th>
                    <?php endif; ?>
                </tbody>
            </table>


            <div class="container space">
                

                <div id="map-canvas"></div>
            </div>



            <div class="container video">
                <!-- Modal -->
                <div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                    <div class="modal-dialog" role="document">
                        <div class="modal-content">
                            <div class="modal-body">

                                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                    <span aria-hidden="true">&times;</span>
                                </button>

                                <!-- 16:9 aspect ratio -->
                                <div class="embed-responsive embed-responsive-16by9">
                                    <iframe class="embed-responsive-item" src="<?php echo e($property->video); ?>" id="video"  allowscriptaccess="always" allow="autoplay"></iframe>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>







        </div>
    </div>
</div>
<!-- row closed -->
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>

<style>
    #map-canvas {
        width: 1110px;
        height: 400px;
    }

</style>


<script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyCyB6K1CFUQ1RwVJ-nyXxd6W0rfiIBe12Q"
    type="text/javascript">
</script>

<script>
    var lat = <?php echo e($property->location_latitude); ?>;
    var lng = <?php echo e($property->location_longitude); ?>;
    var map = new google.maps.Map(document.getElementById('map-canvas'), {
        center: {
            lat: lat,
            lng: lng
        },
        zoom: 15
    });
    var marker = new google.maps.Marker({
        position: {
            lat: lat,
            lng: lng
        },
        map: map
    });
    //thanks for watching..................
    //subscribe, share, like, comment............................

</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\4FARH\OneDrive\Desktop\World\resources\views/pages/admin/properties/show.blade.php ENDPATH**/ ?>