-- phpMyAdmin SQL Dump
-- version 4.9.4
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Jul 05, 2021 at 03:15 AM
-- Server version: 5.7.33-log-cll-lve
-- PHP Version: 7.3.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `raptors2`
--

-- --------------------------------------------------------

--
-- Table structure for table `aboutus`
--

CREATE TABLE `aboutus` (
  `id` int(10) UNSIGNED NOT NULL,
  `aboutus_ar` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `aboutus_en` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `client` int(11) DEFAULT NULL,
  `experience_year` int(11) DEFAULT NULL,
  `previous_project` int(11) DEFAULT NULL,
  `under_construction` int(11) DEFAULT NULL,
  `message_ar` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `message_en` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `vision_ar` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `vision_en` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `whyus_ar` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `whyus_en` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `aboutus`
--

INSERT INTO `aboutus` (`id`, `aboutus_ar`, `aboutus_en`, `client`, `experience_year`, `previous_project`, `under_construction`, `message_ar`, `message_en`, `vision_ar`, `vision_en`, `whyus_ar`, `whyus_en`, `created_at`, `updated_at`) VALUES
(1, 'هذا النص هو مثال لنص يمكن أن يستبدل في نفس المساحة، لقد تم توليد هذا النص من مولد النص العربى، حيث يمكنك أن تولد مثل هذا النص أو العديد من النصوص الأخرى إضافة إلى زيادة عدد الحروف .', 'This text is an example that can be replaced in the same space, where you can create this text from the Arabic text generator.', 34544, 50, 117, 122, 'هذا النص هو مثال لنص يمكن أن يستبدل في نفس المساحة، لقد تم توليد هذا النص من مولد النص العربى، حيث يمكنك أن تولد مثل هذا النص أو العديد من النصوص الأخرى إضافة إلى زيادة عدد الحروف التى يولدها التطبيق.111111', 'This text is an example that can be replaced in the same space, where you can create this text from the Arabic text generator.', 'هذا النص هو مثال لنص يمكن أن يستبدل في نفس المساحة، لقد تم توليد هذا النص من مولد النص العربى، حيث يمكنك أن تولد مثل هذا النص أو العديد من النصوص الأخرى إضافة إلى زيادة عدد الحروف التى يولدها التطبيق.', 'This text is an example that can be replaced in the same space, where you can create this text from the Arabic text generator.', 'هذا النص هو مثال لنص يمكن أن يستبدل في نفس المساحة، لقد تم توليد هذا النص من مولد النص العربى، حيث يمكنك أن تولد مثل هذا النص أو العديد من النصوص الأخرى إضافة إلى زيادة عدد الحروف التى يولدها التطبيق.', 'This text is an example that can be replaced in the same space, where you can create this text from the Arabic text generator.', '2021-06-25 00:10:38', '2021-07-03 01:00:38');

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

CREATE TABLE `categories` (
  `id` int(10) UNSIGNED NOT NULL,
  `name_ar` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name_en` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Notes` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `categories`
--

INSERT INTO `categories` (`id`, `name_ar`, `name_en`, `Notes`, `created_at`, `updated_at`) VALUES
(1, 'مطعم', 'Resturant', NULL, '2021-06-24 23:43:40', '2021-06-24 23:43:40'),
(2, 'سـوبـر مــاركــت', 'SuperMarket', NULL, '2021-06-24 23:44:01', '2021-06-24 23:44:01'),
(3, 'فندق', 'Hotel', NULL, '2021-06-24 23:44:23', '2021-06-24 23:44:23'),
(4, 'مصنع', 'Factory', NULL, '2021-06-24 23:44:50', '2021-06-24 23:44:50'),
(5, 'مـحـل', 'Shop', 'No Comment Edit', '2021-07-01 00:23:32', '2021-07-01 00:23:55'),
(6, 'غــرفــه', 'Room', '', '2021-07-02 00:34:56', '2021-07-02 00:35:16');

-- --------------------------------------------------------

--
-- Table structure for table `classrooms`
--

CREATE TABLE `classrooms` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `Name_Class` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Grade_id` bigint(20) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `company_jobs`
--

CREATE TABLE `company_jobs` (
  `id` int(10) UNSIGNED NOT NULL,
  `title_ar` longtext COLLATE utf8mb4_unicode_ci,
  `title_en` longtext COLLATE utf8mb4_unicode_ci,
  `type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` tinyint(3) UNSIGNED NOT NULL DEFAULT '0',
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `company_jobs`
--

INSERT INTO `company_jobs` (`id`, `title_ar`, `title_en`, `type`, `status`, `created_at`, `updated_at`) VALUES
(2, 'مصمم برامج', 'Web Design', 'Job Title', 0, '2021-06-30 11:13:12', '2021-07-01 17:42:23'),
(3, 'اعلان وظيفة ', 'Company Advertising', 'Annoncement', 0, '2021-06-30 13:03:11', '2021-07-01 17:42:26'),
(4, 'مبرمج', 'Backend', 'Job Title', 0, '2021-06-30 18:36:12', '2021-07-01 17:47:01'),
(5, 'sales@raptorsegypt.com', 'sales@raptorsegypt.com', 'Job E-Mail', 0, '2021-07-01 17:46:20', '2021-07-01 17:46:20'),
(6, 'تلاااال', 'lfvl[', 'Job Title', 0, '2021-07-02 00:32:01', '2021-07-02 00:32:56'),
(7, 'شـبـكـات', 'Network', 'Job Title', 0, '2021-07-04 20:57:17', '2021-07-04 20:58:36');

-- --------------------------------------------------------

--
-- Table structure for table `contactus_messages`
--

CREATE TABLE `contactus_messages` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `mobile` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `subject` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `message` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` tinyint(3) UNSIGNED NOT NULL DEFAULT '0',
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `contactus_messages`
--

INSERT INTO `contactus_messages` (`id`, `name`, `email`, `mobile`, `subject`, `message`, `status`, `created_at`, `updated_at`) VALUES
(1, 'Mohamed', 'Mohamed@Yahoo.Com', '+11111111', 'subject', 'هذا النص هو مثال لنص يمكن أن يستبدل في نفس المساحة', 1, '2021-06-25 02:11:45', '2021-06-25 23:15:41'),
(2, 'mohamed saber', 'mohamed@saber.com', '011111111233', 'subject', 'هذا النص هو مثال لنص يمكن أن يستبدل في نفس المساحة', 1, '2021-06-25 23:13:20', '2021-06-25 23:15:56'),
(3, 'mohamed', 'mohamed@yahoo.com', '0112222222', 'zxzvzvzv', 'zvzvzxvzvzxvv', 1, '2021-07-02 23:52:41', '2021-07-02 23:53:21'),
(4, 'ismail', 'ismail@gmail.com', '01100986753', 'hi there', 'welcome there how are u', 0, '2021-07-04 20:55:11', '2021-07-04 20:55:11');

-- --------------------------------------------------------

--
-- Table structure for table `failed_jobs`
--

CREATE TABLE `failed_jobs` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `connection` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `queue` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `exception` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `features`
--

CREATE TABLE `features` (
  `id` int(10) UNSIGNED NOT NULL,
  `name_ar` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name_en` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Notes` text COLLATE utf8mb4_unicode_ci,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `features`
--

INSERT INTO `features` (`id`, `name_ar`, `name_en`, `Notes`, `created_at`, `updated_at`) VALUES
(1, 'حمام سباحة', 'Swimming Pool', 'No Comment', '2021-06-25 01:42:15', '2021-06-25 01:42:15'),
(2, 'جراج', 'Garage', NULL, '2021-06-25 01:42:48', '2021-06-25 01:42:48'),
(3, 'حديقة', 'Garden', 'no', '2021-06-25 01:43:12', '2021-06-25 01:43:12'),
(4, 'غـاز', 'Gas', NULL, '2021-06-30 17:24:38', '2021-06-30 17:24:38'),
(5, 'جيم', 'GYM', '', '2021-07-01 17:36:17', '2021-07-01 17:36:28');

-- --------------------------------------------------------

--
-- Table structure for table `feature_property`
--

CREATE TABLE `feature_property` (
  `id` int(10) UNSIGNED NOT NULL,
  `property_id` int(10) UNSIGNED NOT NULL,
  `feature_id` int(10) UNSIGNED NOT NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `feature_property`
--

INSERT INTO `feature_property` (`id`, `property_id`, `feature_id`, `created_at`, `updated_at`) VALUES
(1, 1, 3, '2021-06-25 03:49:57', '2021-06-25 03:49:57'),
(2, 1, 2, '2021-06-25 03:49:57', '2021-06-25 03:49:57'),
(3, 1, 1, '2021-06-25 03:49:57', '2021-06-25 03:49:57'),
(4, 2, 3, '2021-06-25 03:51:05', '2021-06-25 03:51:05'),
(5, 2, 2, '2021-06-25 03:51:05', '2021-06-25 03:51:05'),
(6, 2, 1, '2021-06-25 03:51:05', '2021-06-25 03:51:05'),
(7, 3, 2, '2021-06-26 01:07:12', '2021-06-26 01:07:12'),
(8, 3, 1, '2021-06-26 01:07:12', '2021-06-26 01:07:12'),
(11, 6, 3, '2021-06-26 03:56:15', '2021-06-26 03:56:15'),
(12, 7, 1, '2021-06-30 11:51:18', '2021-06-30 11:51:18'),
(13, 7, 3, '2021-06-30 11:51:18', '2021-06-30 11:51:18'),
(14, 7, 4, '2021-06-30 11:51:18', '2021-06-30 11:51:18'),
(15, 8, 1, '2021-07-01 11:40:50', '2021-07-01 11:40:50'),
(16, 8, 3, '2021-07-01 11:40:50', '2021-07-01 11:40:50'),
(17, 8, 4, '2021-07-01 11:40:50', '2021-07-01 11:40:50');

-- --------------------------------------------------------

--
-- Table structure for table `galleries`
--

CREATE TABLE `galleries` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `type` int(11) NOT NULL DEFAULT '0',
  `path` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` int(11) NOT NULL DEFAULT '0',
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `galleries`
--

INSERT INTO `galleries` (`id`, `name`, `type`, `path`, `status`, `created_at`, `updated_at`) VALUES
(1, '1624585959_2ef479391726aa3798d22886e0085443_.jpg', 0, 'image/gallery/blog/1624585959_2ef479391726aa3798d22886e0085443_.jpg', 0, '2021-06-25 01:52:39', '2021-06-30 17:59:10'),
(2, '1624585959_867_.jpg', 0, 'image/gallery/blog/1624585959_867_.jpg', 0, '2021-06-25 01:52:39', '2021-06-30 17:59:14'),
(3, '1624585959_adae7ee1e68a7df76cf7f12b41ebee20_.jpg', 0, 'image/gallery/blog/1624585959_adae7ee1e68a7df76cf7f12b41ebee20_.jpg', 0, '2021-06-25 01:52:39', '2021-06-25 01:52:39'),
(4, '1624585959_home-inspection_.jpg', 0, 'image/gallery/blog/1624585959_home-inspection_.jpg', 0, '2021-06-25 01:52:39', '2021-06-25 01:52:39'),
(5, '1624585959_images (1)_.jpg', 0, 'image/gallery/blog/1624585959_images (1)_.jpg', 0, '2021-06-25 01:52:39', '2021-06-25 01:52:39'),
(6, '1624586508_2ef479391726aa3798d22886e0085443_.jpg', 1, 'image/gallery/slider/1624586508_2ef479391726aa3798d22886e0085443_.jpg', 0, '2021-06-25 02:01:48', '2021-06-25 02:01:48'),
(7, '1624586508_home-inspection_.jpg', 1, 'image/gallery/slider/1624586508_home-inspection_.jpg', 0, '2021-06-25 02:01:48', '2021-06-25 02:01:48'),
(8, '1624586508_images (1)_.jpg', 1, 'image/gallery/slider/1624586508_images (1)_.jpg', 0, '2021-06-25 02:01:48', '2021-06-25 02:01:48'),
(9, '1624586508_images (2)_.jpg', 1, 'image/gallery/slider/1624586508_images (2)_.jpg', 0, '2021-06-25 02:01:48', '2021-06-25 02:01:48'),
(10, '1624586508_photo_2021-06-09_10-26-00_.jpg', 1, 'image/gallery/slider/1624586508_photo_2021-06-09_10-26-00_.jpg', 0, '2021-06-25 02:01:48', '2021-06-25 02:01:48'),
(11, '1625077039_images (2)_.jpg', 0, 'image/gallery/blog/1625077039_images (2)_.jpg', 0, '2021-06-30 18:17:19', '2021-06-30 18:17:19'),
(12, '1625161020_photo_2021-06-09_10-25-45_.jpg', 0, 'image/gallery/blog/1625161020_photo_2021-06-09_10-25-45_.jpg', 0, '2021-07-01 17:37:00', '2021-07-01 17:37:00'),
(14, '1625161055_images (1)_.jpg', 1, 'image/gallery/slider/1625161055_images (1)_.jpg', 0, '2021-07-01 17:37:35', '2021-07-01 17:37:35'),
(15, '1625269431_2ef479391726aa3798d22886e0085443_.jpg', 0, 'image/gallery/blog/1625269431_2ef479391726aa3798d22886e0085443_.jpg', 0, '2021-07-02 23:43:51', '2021-07-02 23:43:51'),
(16, '1625269431_867_.jpg', 0, 'image/gallery/blog/1625269431_867_.jpg', 1, '2021-07-02 23:43:51', '2021-07-02 23:44:11'),
(17, '1625269431_home-inspection_.jpg', 0, 'image/gallery/blog/1625269431_home-inspection_.jpg', 0, '2021-07-02 23:43:51', '2021-07-02 23:43:51'),
(18, '1625269481_867_.jpg', 1, 'image/gallery/slider/1625269481_867_.jpg', 0, '2021-07-02 23:44:41', '2021-07-02 23:44:41');

-- --------------------------------------------------------

--
-- Table structure for table `grades`
--

CREATE TABLE `grades` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `Name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Notes` text COLLATE utf8mb4_unicode_ci
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `job_seekers`
--

CREATE TABLE `job_seekers` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `mobile` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `job_title` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `file` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `message` longtext COLLATE utf8mb4_unicode_ci,
  `status` tinyint(3) UNSIGNED NOT NULL DEFAULT '0',
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `job_seekers`
--

INSERT INTO `job_seekers` (`id`, `name`, `email`, `mobile`, `job_title`, `file`, `message`, `status`, `created_at`, `updated_at`) VALUES
(9, 'job', 'job@job.com', '121321331', 'Title', '1625040513.pdf', NULL, 1, '2021-06-30 08:08:33', '2021-06-30 12:38:42'),
(12, 'Mohamed', 'Mohamed@Yahoo.Com', '01147451963', 'Title', '1625056842.pdf', NULL, 1, '2021-06-30 12:40:42', '2021-07-02 23:50:48'),
(14, 'Mohamed Farh', 'Mohamedfarh987@gmail.com', '+201147451963', 'رسالة من لبصفحة الرئيسية', '1625162378.pdf', NULL, 0, '2021-07-01 17:59:38', '2021-07-01 17:59:38'),
(15, 'ثسبثفثق', 'amelgded@gmail.com', '2222222', 'ارعب فى العميل', '1625186034.png', NULL, 0, '2021-07-02 00:33:54', '2021-07-02 00:33:54'),
(16, 'Test', 'test@hmail.com', '000000000', NULL, '1625314628.pdf', NULL, 0, '2021-07-03 12:17:08', '2021-07-03 12:17:08'),
(17, 'ismail', 'ismail@gmail.com', '01100986753', 'dears', '1625432356.pdf', NULL, 0, '2021-07-04 20:59:16', '2021-07-04 20:59:16');

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(1, '2014_10_12_000000_create_users_table', 1),
(2, '2014_10_12_100000_create_password_resets_table', 1),
(3, '2019_08_19_000000_create_failed_jobs_table', 1),
(4, '2021_01_15_184804_create_Grades_table', 1),
(5, '2021_01_23_181414_create_Classrooms_table', 1),
(6, '2021_01_23_181424_create_foreign_keys', 1),
(7, '2021_06_13_145244_create_categories_table', 1),
(8, '2021_06_13_145245_create_properties_table', 1),
(9, '2021_06_19_110645_create_features_table', 1),
(10, '2021_06_19_110901_create_feature_property_table', 1),
(11, '2021_06_19_180642_create_galleries_table', 1),
(12, '2021_06_20_175605_create_social_table', 1),
(13, '2021_06_21_011728_create_contactus_messages_table', 1),
(14, '2021_06_24_134033_create_aboutus_table', 1),
(17, '2021_06_27_082912_create_news_table', 2),
(20, '2021_06_30_001748_create_job_seekers_table', 3),
(22, '2021_06_30_084751_create_company_jobs_table', 4);

-- --------------------------------------------------------

--
-- Table structure for table `news`
--

CREATE TABLE `news` (
  `id` int(10) UNSIGNED NOT NULL,
  `head_ar` longtext COLLATE utf8mb4_unicode_ci,
  `head_en` longtext COLLATE utf8mb4_unicode_ci,
  `body_ar` longtext COLLATE utf8mb4_unicode_ci,
  `body_en` longtext COLLATE utf8mb4_unicode_ci,
  `photo` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `vision` enum('0','1') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `news`
--

INSERT INTO `news` (`id`, `head_ar`, `head_en`, `body_ar`, `body_en`, `photo`, `vision`, `created_at`, `updated_at`) VALUES
(1, 'هذا النص هو مثال لنص يمكن أن يستبدل في نفس المساحة، لقد تم توليد هذا النص من مولد النص العربى', 'This text is an example of a text that can be replaced in the same space. This text was generated from the English text generator', 'هذا النص هو مثال لنص يمكن أن يستبدل في نفس المساحة، لقد تم توليد هذا النص من مولد النص العربى، حيث يمكنك أن تولد مثل هذا النص أو العديد من النصوص الأخرى إضافة إلى زيادة عدد الحروف التى يولدها التطبيق.', 'This text is an example of a text that can be replaced in the same space. This text was generated from the Arabic text generator, where you can generate such text or many other texts in addition to increasing the number of characters generated by the application.\n', '1624882286.jpg', '1', '2021-06-27 10:16:23', '2021-06-28 10:11:26'),
(2, 'هذا النص هو مثال لنص يمكن أن يستبدل في نفس المساحة، لقد تم توليد هذا النص من مولد النص العربى', 'This text is an example of a text that can be replaced in the same space. This text was generated from the English text generator', 'هذا النص هو مثال لنص يمكن أن يستبدل في نفس المساحة، لقد تم توليد هذا النص من مولد النص العربى، حيث يمكنك أن تولد مثل هذا النص أو العديد من النصوص الأخرى إضافة إلى زيادة عدد الحروف التى يولدها التطبيق.', 'This text is an example of a text that can be replaced in the same space. This text was generated from the English text generator', '1625077687.jpg', '1', '2021-06-27 11:33:23', '2021-07-01 01:33:25'),
(3, 'هذا النص هو مثال لنص يمكن أن يستبدل في نفس المساحة، لقد تم توليد هذا النص من مولد النص العربى', 'This text is an example of a text that can be replaced in the same space. This text was generated from the English text generator', 'هذا النص هو مثال لنص يمكن أن يستبدل في نفس المساحة، لقد تم توليد هذا النص من مولد النص العربى، حيث يمكنك أن تولد مثل هذا النص أو العديد من النصوص الأخرى إضافة إلى زيادة عدد الحروف التى يولدها التطبيق.', 'This text is an example of a text that can be replaced in the same space. This text was generated from the Arabic text generator, where you can generate such text or many other texts in addition to increasing the number of characters generated by the application.\n', '1624882333.png', '1', '2021-06-27 22:41:59', '2021-06-28 10:12:13'),
(5, 'تم  شراء قصر الملك ', 'ssssssssss', ' تم  شراء قصر الملك  تم  شراء قصر الملك  تم  شراء قصر الملك  تم  شراء قصر الملك  تم  شراء قصر الملك  تم  شراء قصر الملك  تم  شراء قصر الملك  تم  شراء قصر الملك  تم  شراء قصر الملك  تم  شراء قصر الملك  تم  شراء قصر الملك  تم  شراء قصر الملك  تم  شراء قصر الملك  تم  شراء قصر الملك  تم  شراء قصر الملك  ', 'fdjbkjg gfdskdsjfkdsjf jgikjdfk dsup[odjsalkdn;les saoifodsnbfds lkifdoewnflj', '1625185823.jpg', '1', '2021-07-02 07:28:30', '2021-07-02 07:30:23');

-- --------------------------------------------------------

--
-- Table structure for table `password_resets`
--

CREATE TABLE `password_resets` (
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `properties`
--

CREATE TABLE `properties` (
  `id` int(10) UNSIGNED NOT NULL,
  `title_ar` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `title_en` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `photo` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `price` double DEFAULT NULL,
  `discount` double DEFAULT NULL,
  `new_price` double DEFAULT NULL,
  `size` double DEFAULT NULL,
  `purpose` enum('sale','rent') COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` enum('for_sale','sold') COLLATE utf8mb4_unicode_ci DEFAULT 'for_sale',
  `used` enum('new','used') COLLATE utf8mb4_unicode_ci NOT NULL,
  `images` varchar(3000) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `video` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `floornumber` int(11) DEFAULT NULL,
  `no_of_floor` int(11) DEFAULT NULL,
  `bedroom` int(11) NOT NULL,
  `bathroom` int(11) NOT NULL,
  `city_ar` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `city_en` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `address_ar` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `address_en` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `nearby_ar` text COLLATE utf8mb4_unicode_ci,
  `nearby_en` text COLLATE utf8mb4_unicode_ci,
  `description_ar` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `description_en` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `location_latitude` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `location_longitude` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `category_id` int(10) UNSIGNED DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `properties`
--

INSERT INTO `properties` (`id`, `title_ar`, `title_en`, `photo`, `price`, `discount`, `new_price`, `size`, `purpose`, `status`, `used`, `images`, `video`, `floornumber`, `no_of_floor`, `bedroom`, `bathroom`, `city_ar`, `city_en`, `address_ar`, `address_en`, `nearby_ar`, `nearby_en`, `description_ar`, `description_en`, `location_latitude`, `location_longitude`, `category_id`, `created_at`, `updated_at`) VALUES
(1, 'هذا النص هو مثال يمكن أن يستبدل في نفس المساحة ، حيث يمكنك إنشاء هذا النص من مولد النص العربى.', 'property number one', '1624585797.jpg', 1331313, 1233, 12312313, 12313, 'sale', 'for_sale', 'new', '1625267257_867_.jpg|1625267257_adae7ee1e68a7df76cf7f12b41ebee20_.jpg', 'https://www.youtube.com/embed/p4Z63z0cmpc', 12, NULL, 12, 12, 'Egypt', 'Egypt', 'Cairo', 'Cairo', 'هذا النص هو مثال لنص يمكن أن يستبدل في نفس المساحة، لقد تم توليد هذا النص من مولد النص العربى، حيث يمكنك أن تولد مثل هذا النص أو العديد من النصوص الأخرى إضافة إلى زيادة عدد الحروف التى يولدها التطبيق. إذا كنت تحتاج إلى عدد أكبر من الفقرات يتيح لك مولد النص العربى زيادة عدد الفقرات كما تريد', 'This text is an example of a text that can be replaced in the same space. This text was generated from the Arabic text generator, where you can generate such text or many other texts in addition to increasing the number of characters generated by the application. If you need a larger number of paragraphs, the Arabic text generator allows you to increase the number of paragraphs as you want', 'هذا النص هو مثال لنص يمكن أن يستبدل في نفس المساحة، لقد تم توليد هذا النص من مولد النص العربى، حيث يمكنك أن تولد مثل هذا النص أو العديد من النصوص الأخرى إضافة إلى زيادة عدد الحروف التى يولدها التطبيق. إذا كنت تحتاج إلى عدد أكبر من الفقرات يتيح لك مولد النص العربى زيادة عدد الفقرات كما تريد', 'هذا النص هو مثال لنص يمكن أن يستبدل في نفس المساحة، لقد تم توليد هذا النص من مولد النص العربى، حيث يمكنك أن تولد مثل هذا النص أو العديد من النصوص الأخرى إضافة إلى زيادة عدد الحروف التى يولدها التطبيق. إذا كنت تحتاج إلى عدد أكبر من الفقرات يتيح لك مولد النص العربى زيادة عدد الفقرات كما تريد', '1313', '1313', 3, '2021-06-25 01:49:57', '2021-07-02 23:07:37'),
(2, 'هذا النص هو مثال يمكن أن يستبدل في نفس المساحة ، حيث يمكنك إنشاء هذا النص من مولد النص العربى.', 'Property Number Two', '1624656645.jpg', 1331313, 1233, 12312313, 12313, 'sale', 'for_sale', 'new', '1624661371_home-inspection_.jpg|1624661371_images (1)_.jpg', 'https://www.youtube.com/embed/p4Z63z0cmpc', 12, NULL, 12, 12, 'مصر', 'Egypt', 'الاسكندرية', 'Cairo', 'هذا النص هو مثال لنص يمكن أن يستبدل في نفس المساحة، لقد تم توليد هذا النص من مولد النص العربى، حيث يمكنك أن تولد مثل هذا النص أو العديد من النصوص الأخرى إضافة إلى زيادة عدد الحروف التى يولدها التطبيق. إذا كنت تحتاج إلى عدد أكبر من الفقرات يتيح لك مولد النص العربى زيادة عدد الفقرات كما تريد', 'This text is an example of a text that can be replaced in the same space. This text was generated from the Arabic text generator, where you can generate such text or many other texts in addition to increasing the number of characters generated by the application. If you need a larger number of paragraphs, the Arabic text generator allows you to increase the number of paragraphs as you want', 'هذا النص هو مثال لنص يمكن أن يستبدل في نفس المساحة، لقد تم توليد هذا النص من مولد النص العربى، حيث يمكنك أن تولد مثل هذا النص أو العديد من النصوص الأخرى إضافة إلى زيادة عدد الحروف التى يولدها التطبيق. إذا كنت تحتاج إلى عدد أكبر من الفقرات يتيح لك مولد النص العربى زيادة عدد الفقرات كما تريد', 'This text is an example of a text that can be replaced in the same space. This text was generated from the Arabic text generator, where you can generate such text or many other texts in addition to increasing the number of characters generated by the application. If you need a larger number of paragraphs, the Arabic text generator allows you to increase the number of paragraphs as you want', '31.388455949999997', '31.038822000000003', 3, '2021-06-25 01:51:05', '2021-06-25 22:49:31'),
(3, 'هذا النص هو مثال يمكن أن يستبدل في نفس المساحة ، حيث يمكنك إنشاء هذا النص من مولد النص العربى.', 'Property Number Three', '1624662432.png', 123123, 123, 123, 12321, 'rent', 'sold', 'new', '1624662432_Artboard – 2_.png|1624662432_home-inspection_.jpg|1624662432_images (1)_.jpg|1624662479_home-inspection_.jpg', 'https://www.youtube.com/watch?v=uJJccULSUMc&list=PLvNu8E-aj20njrvWNIutPOb8ip1xoLjW2&index=65&ab_channel=MindsCMS', 123, NULL, 123, 123, 'مصر', 'Egypt', 'المنصورة', 'mansoura', 'هذا النص هو مثال لنص يمكن أن يستبدل في نفس المساحة، لقد تم توليد هذا النص من مولد النص العربى، حيث يمكنك أن تولد مثل هذا النص أو العديد من النصوص الأخرى إضافة إلى زيادة عدد الحروف التى يولدها التطبيق. إذا كنت تحتاج إلى عدد أكبر من الفقرات يتيح لك مولد النص العربى زيادة عدد الفقرات كما تريد', 'This text is an example of a text that can be replaced in the same space. This text was generated from the Arabic text generator, where you can generate such text or many other texts in addition to increasing the number of characters generated by the application. If you need a larger number of paragraphs, the Arabic text generator allows you to increase the number of paragraphs as you want', 'هذا النص هو مثال لنص يمكن أن يستبدل في نفس المساحة، لقد تم توليد هذا النص من مولد النص العربى، حيث يمكنك أن تولد مثل هذا النص أو العديد من النصوص الأخرى إضافة إلى زيادة عدد الحروف التى يولدها التطبيق. إذا كنت تحتاج إلى عدد أكبر من الفقرات يتيح لك مولد النص العربى زيادة عدد الفقرات كما تريد', 'This text is an example of a text that can be replaced in the same space. This text was generated from the Arabic text generator, where you can generate such text or many other texts in addition to increasing the number of characters generated by the application. If you need a larger number of paragraphs, the Arabic text generator allows you to increase the number of paragraphs as you want', '213213213', '1231313', 4, '2021-06-25 23:07:12', '2021-06-25 23:07:59'),
(4, 'هذا النص هو مثال يمكن أن يستبدل في نفس المساحة ، حيث يمكنك إنشاء هذا النص من مولد النص العربى.', 'Property Number Four', '1624667954.jpg', 3114, 424242, 242424, 432432, 'rent', 'sold', 'new', '1624667954_2ef479391726aa3798d22886e0085443_.jpg|1624667954_867_.jpg|1624667954_adae7ee1e68a7df76cf7f12b41ebee20_.jpg', 'https://www.youtube.com/watch?v=uJJccULSUMc&list=PLvNu8E-aj20njrvWNIutPOb8ip1xoLjW2&index=65&ab_channel=MindsCMS', 242, 242, 242, 24, 'مصر', 'Egypt', 'طنطا', 'tanta', 'هذا النص هو مثال لنص يمكن أن يستبدل في نفس المساحة، لقد تم توليد هذا النص من مولد النص العربى، حيث يمكنك أن تولد مثل هذا النص أو العديد من النصوص الأخرى إضافة إلى زيادة عدد الحروف التى يولدها التطبيق. إذا كنت تحتاج إلى عدد أكبر من الفقرات يتيح لك مولد النص العربى زيادة عدد الفقرات كما تريد', 'This text is an example of a text that can be replaced in the same space. This text was generated from the Arabic text generator, where you can generate such text or many other texts in addition to increasing the number of characters generated by the application. If you need a larger number of paragraphs, the Arabic text generator allows you to increase the number of paragraphs as you want', 'هذا النص هو مثال لنص يمكن أن يستبدل في نفس المساحة، لقد تم توليد هذا النص من مولد النص العربى، حيث يمكنك أن تولد مثل هذا النص أو العديد من النصوص الأخرى إضافة إلى زيادة عدد الحروف التى يولدها التطبيق. إذا كنت تحتاج إلى عدد أكبر من الفقرات يتيح لك مولد النص العربى زيادة عدد الفقرات كما تريد', 'This text is an example of a text that can be replaced in the same space. This text was generated from the Arabic text generator, where you can generate such text or many other texts in addition to increasing the number of characters generated by the application. If you need a larger number of paragraphs, the Arabic text generator allows you to increase the number of paragraphs as you want', '1313', '1313', 3, '2021-06-26 00:39:14', '2021-06-26 00:39:14'),
(5, 'هذا النص هو مثال يمكن أن يستبدل في نفس المساحة ، حيث يمكنك إنشاء هذا النص من مولد النص العربى.', 'Property Number Five', '1624668228.jpg', 123123, 123, 123, 123, 'sale', 'for_sale', 'new', '1624668228_home-inspection_.jpg|1624668228_images (1)_.jpg', 'https://www.youtube.com/watch?v=uJJccULSUMc&list=PLvNu8E-aj20njrvWNIutPOb8ip1xoLjW2&index=65&ab_channel=MindsCMS', 123, 123, 123, 123, 'مصر', 'Egypt', 'البحيرة', 'behira', 'هذا النص هو مثال لنص يمكن أن يستبدل في نفس المساحة، لقد تم توليد هذا النص من مولد النص العربى، حيث يمكنك أن تولد مثل هذا النص أو العديد من النصوص الأخرى إضافة إلى زيادة عدد الحروف التى يولدها التطبيق. إذا كنت تحتاج إلى عدد أكبر من الفقرات يتيح لك مولد النص العربى زيادة عدد الفقرات كما تريد', 'This text is an example of a text that can be replaced in the same space. This text was generated from the Arabic text generator, where you can generate such text or many other texts in addition to increasing the number of characters generated by the application. If you need a larger number of paragraphs, the Arabic text generator allows you to increase the number of paragraphs as you want', 'هذا النص هو مثال لنص يمكن أن يستبدل في نفس المساحة، لقد تم توليد هذا النص من مولد النص العربى، حيث يمكنك أن تولد مثل هذا النص أو العديد من النصوص الأخرى إضافة إلى زيادة عدد الحروف التى يولدها التطبيق. إذا كنت تحتاج إلى عدد أكبر من الفقرات يتيح لك مولد النص العربى زيادة عدد الفقرات كما تريد', 'This text is an example of a text that can be replaced in the same space. This text was generated from the Arabic text generator, where you can generate such text or many other texts in addition to increasing the number of characters generated by the application. If you need a larger number of paragraphs, the Arabic text generator allows you to increase the number of paragraphs as you want', '23', '23', 1, '2021-06-26 00:43:48', '2021-06-26 00:43:48'),
(6, 'هذا النص هو مثال يمكن أن يستبدل في نفس المساحة ، حيث يمكنك إنشاء هذا النص من مولد النص العربى.', 'Property Number seven', '1625079166.jpg', 12311, 1231, 23, 23, 'sale', 'sold', 'new', '1624668396_home-inspection_.jpg|1624668396_images (1)_.jpg|1625079166_photo_2021-06-09_10-25-45_.jpg', 'https://www.youtube.com/watch?v=uJJccULSUMc&list=PLvNu8E-aj20njrvWNIutPOb8ip1xoLjW2&index=65&ab_channel=MindsCMS', 123, NULL, 123, 123, 'مصر', 'Egypt', 'القاهره', 'cairo', 'هذا النص هو مثال لنص يمكن أن يستبدل في نفس المساحة، لقد تم توليد هذا النص من مولد النص العربى، حيث يمكنك أن تولد مثل هذا النص أو العديد من النصوص الأخرى إضافة إلى زيادة عدد الحروف التى يولدها التطبيق. إذا كنت تحتاج إلى عدد أكبر من الفقرات يتيح لك مولد النص العربى زيادة عدد الفقرات كما تريد', 'This text is an example of a text that can be replaced in the same space. This text was generated from the Arabic text generator, where you can generate such text or many other texts in addition to increasing the number of characters generated by the application. If you need a larger number of paragraphs, the Arabic text generator allows you to increase the number of paragraphs as you want', 'هذا النص هو مثال لنص يمكن أن يستبدل في نفس المساحة، لقد تم توليد هذا النص من مولد النص العربى، حيث يمكنك أن تولد مثل هذا النص أو العديد من النصوص الأخرى إضافة إلى زيادة عدد الحروف التى يولدها التطبيق. إذا كنت تحتاج إلى عدد أكبر من الفقرات يتيح لك مولد النص العربى زيادة عدد الفقرات كما تريد', 'This text is an example of a text that can be replaced in the same space. This text was generated from the Arabic text generator, where you can generate such text or many other texts in addition to increasing the number of characters generated by the application. If you need a larger number of paragraphs, the Arabic text generator allows you to increase the number of paragraphs as you want', '50', '1212', 3, '2021-06-26 00:46:36', '2021-06-30 18:52:46'),
(7, 'هذا النص هو مثال لنص يمكن أن يستبدل في نفس المساحة،', 'Property Number eight', '1625079078.jpg', 1000000, 5, 200000, 300, 'sale', 'for_sale', 'new', '1625079078_2ef479391726aa3798d22886e0085443_.jpg|1625079078_adae7ee1e68a7df76cf7f12b41ebee20_.jpg|1625079078_images (1)_.jpg|1625079078_images (2)_.jpg', 'https://www.youtube.com/embed/p4Z63z0cmpc', 1, 12, 8, 4, 'Zefta, Gharbia', 'Zefta, Gharbia', 'Shershabah', 'Shershabah', 'هذا النص هو مثال لنص يمكن أن يستبدل في نفس المساحة، لقد تم توليد هذا النص من مولد النص العربى، حيث يمكنك أن تولد مثل هذا النص أو العديد من النصوص الأخرى إضافة إلى زيادة عدد الحروف التى يولدها التطبيق. إذا كنت تحتاج إلى عدد أكبر من الفقرات يتيح لك مولد النص العربى زيادة عدد الفقرات كما تريد', 'This text is an example of a text that can be replaced in the same space. This text was generated from the Arabic text generator, where you can generate such text or many other texts in addition to increasing the number of characters generated by the application. If you need a larger number of paragraphs, the Arabic text generator allows you to increase the number of paragraphs as you want', 'هذا النص هو مثال لنص يمكن أن يستبدل في نفس المساحة، لقد تم توليد هذا النص من مولد النص العربى، حيث يمكنك أن تولد مثل هذا النص أو العديد من النصوص الأخرى إضافة إلى زيادة عدد الحروف التى يولدها التطبيق. إذا كنت تحتاج إلى عدد أكبر من الفقرات يتيح لك مولد النص العربى زيادة عدد الفقرات كما تريد', 'This text is an example of a text that can be replaced in the same space. This text was generated from the Arabic text generator, where you can generate such text or many other texts in addition to increasing the number of characters generated by the application. If you need a larger number of paragraphs, the Arabic text generator allows you to increase the number of paragraphs as you want', '31.388455949999997', '31.038822000000003', 3, '2021-06-30 18:51:18', '2021-06-30 18:51:18'),
(8, 'هذا النص هو مثال لنص يمكن أن يستبدل في نفس المساحة، لقد تم توليد هذا النص من مولد النص العربى، حيث يمكنك أن تولد مثل هذا النص أو العديد من النصوص الأخرى إضافة إلى زيادة عدد الحروف التى يولدها', 'Property Number nine', '1625164850.jpg', 900000, 6, 100000, 250, 'sale', 'for_sale', 'new', '1625164850_2ef479391726aa3798d22886e0085443_.jpg|1625164850_867_.jpg|1625164850_adae7ee1e68a7df76cf7f12b41ebee20_.jpg|1625164850_images (1)_.jpg|1625269287_logo_.png', 'https://www.youtube.com/embed/p4Z63z0cmpc', 12, NULL, 4, 5, 'الغربية', 'Zefta, Gharbia', 'طنطا', 'Shershabah', 'This text is an example of a text that can be replaced in the same space. This text was generated from the Arabic text generator, where you can generate such text or many other texts in addition to increasing the number of characters generated by the application. If you need a larger number of paragraphs, the Arabic text generator allows you to increase the number of paragraphs as you want', 'هذا النص هو مثال لنص يمكن أن يستبدل في نفس المساحة، لقد تم توليد هذا النص من مولد النص العربى، حيث يمكنك أن تولد مثل هذا النص أو العديد من النصوص الأخرى إضافة إلى زيادة عدد الحروف التى يولدها التطبيق. إذا كنت تحتاج إلى عدد أكبر من الفقرات يتيح لك مولد النص العربى زيادة عدد الفقرات كما تريد', 'هذا النص هو مثال لنص يمكن أن يستبدل في نفس المساحة، لقد تم توليد هذا النص من مولد النص العربى، حيث يمكنك أن تولد مثل هذا النص أو العديد من النصوص الأخرى إضافة إلى زيادة عدد الحروف التى يولدها التطبيق. إذا كنت تحتاج إلى عدد أكبر من الفقرات يتيح لك مولد النص العربى زيادة عدد الفقرات كما تريد', 'هذا النص هو مثال لنص يمكن أن يستبدل في نفس المساحة، لقد تم توليد هذا النص من مولد النص العربى، حيث يمكنك أن تولد مثل هذا النص أو العديد من النصوص الأخرى إضافة إلى زيادة عدد الحروف التى يولدها التطبيق. إذا كنت تحتاج إلى عدد أكبر من الفقرات يتيح لك مولد النص العربى زيادة عدد الفقرات كما تريد', '31.038822000000003', '31.388455949999997', 6, '2021-07-01 18:40:50', '2021-07-02 23:41:27');

-- --------------------------------------------------------

--
-- Table structure for table `social`
--

CREATE TABLE `social` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `type` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` enum('0','1') COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `contact` enum('0','1') COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `social`
--

INSERT INTO `social` (`id`, `name`, `type`, `status`, `contact`, `created_at`, `updated_at`) VALUES
(1, '19533', 'Customers Service', '1', '1', '2021-06-25 03:00:10', '2021-07-05 08:16:02'),
(2, '011111111111', 'Inquiries', '1', '1', '2021-06-25 03:01:27', '2021-06-25 03:01:27'),
(3, '011111111115', 'Inquiries', '1', '1', '2021-06-25 03:01:55', '2021-06-25 03:01:55'),
(4, '011111111144', 'Accounts', '1', '1', '2021-06-25 03:02:29', '2021-06-30 18:34:33'),
(5, 'sales@raptorsegypt.com', 'Recruitment', '1', '1', '2021-06-25 03:03:18', '2021-06-25 03:03:18'),
(6, 'hr@raptorsegypt.com', 'Recruitment', '1', '1', '2021-06-25 03:03:34', '2021-06-25 03:03:34'),
(7, 'info@raptorsegypt.com', 'Recruitment', '0', '1', '2021-06-25 03:03:49', '2021-06-25 03:03:49'),
(8, '0122589554', 'What\'s App', '1', '0', '2021-06-29 12:03:49', '2021-07-01 17:38:10'),
(9, '01111111111', 'What\'s App', '0', '0', '2021-06-29 12:17:24', '2021-07-01 11:07:55'),
(10, 'https://www.facebook.com/', 'Facebook', '0', '0', '2021-06-29 13:03:10', '2021-07-01 12:57:32'),
(11, 'https://www.instagram.com/', 'Instagram', '1', '0', '2021-06-29 13:04:46', '2021-07-01 13:04:44'),
(12, 'https://www.twitter.com/', 'Twitter', '1', '0', '2021-06-29 13:05:16', '2021-07-01 13:04:39'),
(13, 'Facebook', 'Facebook', '1', '0', '2021-06-30 18:07:37', '2021-07-01 12:57:48'),
(14, '011111567898', 'Inquiries', '1', '1', '2021-06-30 18:35:08', '2021-06-30 18:35:08'),
(15, 'Telegram', 'Telegarm', '1', '0', '2021-07-02 17:44:24', '2021-07-02 17:44:24'),
(16, 'test@test.com', 'Recruitment', '0', '1', '2021-07-02 17:45:23', '2021-07-02 23:46:08');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name_ar` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `admin` int(11) NOT NULL DEFAULT '0',
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `name_ar`, `admin`, `email`, `email_verified_at`, `password`, `remember_token`, `created_at`, `updated_at`) VALUES
(1, 'Admin Admin', NULL, 1, 'admin@admin.com', NULL, '$2y$10$8TZuGywFJraiq3D0t1bGoeydGToKbOjGVwIuFtXrcCeQb/kq3N0me', NULL, '2021-06-24 23:32:48', '2021-06-24 23:32:48'),
(2, 'Mohamed Farh', 'محمد فرح', 0, 'Mohamed@Yahoo.Com', NULL, '$2y$10$zCo5BMg4Bl6UujuvpDukgelPgH4K19pAgPDeE4Y1CWlaRueCLKPNG', NULL, '2021-06-24 23:46:07', '2021-06-24 23:46:07'),
(3, 'User Front', 'تسجيل من الرئيسية', 0, 'userfront@user.com', NULL, '$2y$10$US6xLLwde53hav1zbJ5PmOxXONjHh2d/xY0Qq1NtcMMViPLQphPim', NULL, '2021-06-29 07:21:44', '2021-06-29 07:21:44'),
(4, 'Mohamed', 'محمد فرح', 1, 'mohamed@admin.com', NULL, '$2y$10$KdnaBbOO1oTfCXa4nczah.13XgS5JU6ZSwTS38iFGyc.83S8iNOGi', NULL, '2021-07-01 00:13:42', '2021-07-01 00:14:14'),
(5, 'Mohamed', 'فرح', 0, 'mohamed@user.com', NULL, '$2y$10$MAVfEHu2taBLc1NXWRNVU.XZ9wsiaR5Y8VF5wcsv/75ao7V8nutY2', NULL, '2021-07-01 00:15:16', '2021-07-01 00:15:42'),
(8, 'dsfdsfds', 'يؤءررؤءرءؤ', 0, 'amelgded@gmail.com', NULL, '$2y$10$CYgOvl6dR159cLtVUXTeJONmUXvSB76d7RmfWVEw6WjpL2fIM4vK.', NULL, '2021-07-02 07:18:23', '2021-07-02 07:18:23');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `aboutus`
--
ALTER TABLE `aboutus`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `classrooms`
--
ALTER TABLE `classrooms`
  ADD PRIMARY KEY (`id`),
  ADD KEY `classrooms_grade_id_foreign` (`Grade_id`);

--
-- Indexes for table `company_jobs`
--
ALTER TABLE `company_jobs`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `contactus_messages`
--
ALTER TABLE `contactus_messages`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `failed_jobs`
--
ALTER TABLE `failed_jobs`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `features`
--
ALTER TABLE `features`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `feature_property`
--
ALTER TABLE `feature_property`
  ADD PRIMARY KEY (`id`),
  ADD KEY `feature_property_property_id_foreign` (`property_id`),
  ADD KEY `feature_property_feature_id_foreign` (`feature_id`);

--
-- Indexes for table `galleries`
--
ALTER TABLE `galleries`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `grades`
--
ALTER TABLE `grades`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `job_seekers`
--
ALTER TABLE `job_seekers`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `news`
--
ALTER TABLE `news`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `password_resets`
--
ALTER TABLE `password_resets`
  ADD KEY `password_resets_email_index` (`email`);

--
-- Indexes for table `properties`
--
ALTER TABLE `properties`
  ADD PRIMARY KEY (`id`),
  ADD KEY `properties_category_id_foreign` (`category_id`);

--
-- Indexes for table `social`
--
ALTER TABLE `social`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `users_email_unique` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `aboutus`
--
ALTER TABLE `aboutus`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `categories`
--
ALTER TABLE `categories`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `classrooms`
--
ALTER TABLE `classrooms`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `company_jobs`
--
ALTER TABLE `company_jobs`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `contactus_messages`
--
ALTER TABLE `contactus_messages`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `failed_jobs`
--
ALTER TABLE `failed_jobs`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `features`
--
ALTER TABLE `features`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `feature_property`
--
ALTER TABLE `feature_property`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- AUTO_INCREMENT for table `galleries`
--
ALTER TABLE `galleries`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;

--
-- AUTO_INCREMENT for table `grades`
--
ALTER TABLE `grades`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `job_seekers`
--
ALTER TABLE `job_seekers`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- AUTO_INCREMENT for table `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;

--
-- AUTO_INCREMENT for table `news`
--
ALTER TABLE `news`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `properties`
--
ALTER TABLE `properties`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `social`
--
ALTER TABLE `social`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `classrooms`
--
ALTER TABLE `classrooms`
  ADD CONSTRAINT `classrooms_grade_id_foreign` FOREIGN KEY (`Grade_id`) REFERENCES `grades` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `feature_property`
--
ALTER TABLE `feature_property`
  ADD CONSTRAINT `feature_property_feature_id_foreign` FOREIGN KEY (`feature_id`) REFERENCES `features` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `feature_property_property_id_foreign` FOREIGN KEY (`property_id`) REFERENCES `properties` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `properties`
--
ALTER TABLE `properties`
  ADD CONSTRAINT `properties_category_id_foreign` FOREIGN KEY (`category_id`) REFERENCES `categories` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
